function IEcancel()
{
	PFcancel( event );
}

function PFcancel( event )
{
	if( window.event ) { // Internet Explorer
		event        = window.event;
		eventType    = window.event.type;
		eventKeyCode = window.event.keyCode;
	} else { // other browsers
		eventType    = event.type;
		eventKeyCode = event.which;
	}

	if (eventType == 'keypress') {
		if (eventKeyCode == 27) {
			if (document.forms[0] != null) 
				pressKey('@KEY:CANCEL');
		}
	}

	if (eventType == 'keydown') {
		// The following line puts entry fields in 'over type' mode.
		if (navigator.appName.indexOf('Internet Explorer') != -1)
			document.execCommand('OverWrite', false, true);
		else
			; // not supported in other browsers

		preventDefault = function() {
			if (navigator.appName.indexOf('Internet Explorer') != -1) {
				try { event.keyCode = 0; } catch (e) { } 
				event.returnValue = false; // Internet Explorer
				event.cancelBubble = true; // ==> new
			} else {
				if (event.stopPropagation) // Other browsers
					event.stopPropagation();
				if (event.preventDefault)
					event.preventDefault();
			}
		}

		if (document.forms[0] != null) {
			if (eventKeyCode == 27) {
				preventDefault();
				pressKey('@KEY:CANCEL');
			} else if (eventKeyCode == 13) { //enter
				var cancel = document.forms[0].elements[ "CANCEL" ];
				if( (cancel != null) && cancel.hasFocus ) { //MANTIS-BUTTONS.xsl
					preventDefault();
					pressKey('@KEY:CANCEL');
				} else {
					var element = document.forms[0].elements[ "ENTER" ];
					if( element != null ) {
						preventDefault();
						if( ! element.disabled ) {
							element.focus(); // Runs onChange handlers PRN
							pressKey('@KEY:ENTER');
						}
					}
				}
			} else if (event.shiftKey){ 
				PFshift(eventKeyCode);
			} 
			  else if (event.altKey && eventKeyCode != 17){
					if (eventKeyCode == 46) {
						//document.forms[0].reset(); // not working
						var form=document.forms[0];
						for (i = 0; i < form.elements.length; i++) {
							//alert ("name="+ i+" " + form.elements[i].id + " " + form.elements[i].type )
							if (form.elements[i].type == "text" 
								|| form.elements[i]=="password") // password + textarea 
								form.elements[i].value = ""; 
						}
						for (i = 0; i < form.elements.length; i++) {
							if (form.elements[i].type == "text"
								|| form.elements[i]=="password"){
								form.elements[i].focus();
								break;
							}
						}
					}
			} else if (eventKeyCode == 112) {
				preventDefault();
				pressKey('@KEY:PF1');
			} else if (eventKeyCode == 113) {
				preventDefault();
				pressKey('@KEY:PF2');
			} else if (eventKeyCode == 114) {
				preventDefault();
				pressKey('@KEY:PF3');
			} else if (eventKeyCode == 115) {
				preventDefault();
				pressKey('@KEY:PF4');
			} else if (eventKeyCode == 116) {
				preventDefault();
				pressKey('@KEY:PF5');
			} else if (eventKeyCode == 117) {
				preventDefault();
				pressKey('@KEY:PF6');
			} else if (eventKeyCode == 118) {
				preventDefault();
				pressKey('@KEY:PF7');
			} else if (eventKeyCode == 119) {
				preventDefault();
				pressKey('@KEY:PF8');
			} else if (eventKeyCode == 120) {
				preventDefault();
				pressKey('@KEY:PF9');
			} else if (eventKeyCode == 121) {
				preventDefault();
				pressKey('@KEY:PF10');
			} else if (eventKeyCode == 122) {
				preventDefault();
				pressKey('@KEY:PF11');
			} else if (eventKeyCode == 123) {
				preventDefault();
				pressKey('@KEY:PF12');
			}
		}
	}
	return false;
}
function PFshift( eventKeyCode )
{
	if (eventKeyCode == 112) {
		preventDefault();
		pressKey('@KEY:PF13');
	} else if (eventKeyCode == 113) {
		preventDefault();
		pressKey('@KEY:PF14');
	} else if (eventKeyCode == 114) {
		preventDefault();
		pressKey('@KEY:PF15');
	} else if (eventKeyCode == 115) {
		preventDefault();
		pressKey('@KEY:PF16');
	} else if (eventKeyCode == 116) {
		preventDefault();
		pressKey('@KEY:PF17');
	} else if (eventKeyCode == 117) {
		preventDefault();
		pressKey('@KEY:PF18');
	} else if (eventKeyCode == 118) {
		preventDefault();
		pressKey('@KEY:PF19');
	} else if (eventKeyCode == 119) {
		preventDefault();
		pressKey('@KEY:PF20');
	} else if (eventKeyCode == 120) {
		preventDefault();
		pressKey('@KEY:PF21');
	} else if (eventKeyCode == 121) {
		preventDefault();
		pressKey('@KEY:PF22');
	} else if (eventKeyCode == 122) {
		preventDefault();
		pressKey('@KEY:PF23');
	} else if (eventKeyCode == 123) {
		preventDefault();
		pressKey('@KEY:PF24');
	}	
}
