function getListValues()
{
	// Only jQuery is currently supported.
	if( M$getAjaxLibrary().indexOf( "jquery" ) == -1 )
		return;

	jQuery(document).ready( function() {
	//
	// Has the main list been populated, if so, there is nothing to do!
	//
	if ( jQuery('#Golfer').children().length > 1 ) return;
	
	
	//
	// Send event 'getListValues' to server to get the Players and Courses with Ajax
	//
	setValue('INPUT_LINE','CONTROL:RESERVED_INFO-INPUT_LINE','getListValues');
	var $newScreen;
	$newScreen = jQuery( M$callAjax( M$getAjaxBody() ) );
	// Respond to detail screen in order to return to main screen. 
	M$callAjax( M$getAjaxBody( $newScreen ) );
	// Clear the event
	setValue('INPUT_LINE','CONTROL:RESERVED_INFO-INPUT_LINE', '');

	
	
	//
	// add up to date options into list
	//
	var $golfer = jQuery( '#Golfer' );
	jQuery( '[name^=PlayerName__]', $newScreen ).each( 
		function( i, element ) 
		{
		var $element = jQuery( element, $newScreen );
		if( $element.val() != '' ) {
			var $option = jQuery( '<option/>' ); 
			$option.attr( 'value', $element.val() );
			$option.text($element.val());
			$golfer.append( $option );
		} else {
			//stop iterations
			return false;
		}
		} );
	//
	// now do the Golf Courses
	//
	getCourses($newScreen);
	
	return;
});
}

function getCourses($newScreen)
{
	var $newScreen;
	//
	//get the  Golf Courses for the GolfCourse HTML select
	//
	// add options back into list
	//
	var $golfCourse = jQuery( '#GolfCourse' );
	jQuery( '[name^=CourseName__]', $newScreen ).each( 
		function( i, element ) 
		{
		var $element = jQuery( element );
		if( $element.val() != '' ) {
			var $option = jQuery( '<option/>' ); 
			$option.attr( 'value', $element.val() );
			$option.text($element.val());
			$golfCourse.append( $option );
			$element.empty();
		} else {
			//stop iterations
			return false;
		}
		} );
	
	return;
}
