// Browser Detection
var isAOL=false, isIE6=false, isIE55=false, isIE5=false, isIE4=false, isIE3=false, isIE=false
var isNN6=false, isNN5=false, isNN4=false, isNN3=false
var isMac=false, isWB5=false, isWB4=false, isWB3=false, isSafari=false
var browser_name = navigator.appName;
var browser_version = parseFloat(navigator.appVersion);
if (navigator.appVersion.indexOf('AOL') > -1) {
	isAOL = true;
}
if (navigator.appVersion.indexOf('Mac') > -1) {
	isMac = true;
}
if (navigator.appVersion.indexOf('Safari') > -1) {
	isSafari = true;
}
if (navigator.appName.indexOf('Netscape') > -1) {
	if(navigator.userAgent.indexOf('6.') > -1) {
		isNN6 = true;
	} else if (browser_version >= 5) {
		isNN5 = true;
	} else if (browser_version >= 4) {
		isNN4 = true;
	} else if (browser_version >= 3) {
		isNN3 = true;
	}
} else if (navigator.appName.indexOf('Microsoft Internet Explorer') > -1) {
	isIE = true;
	if (navigator.appVersion.indexOf('MSIE 6.0') > -1) {
		isIE6 = true;
	} else if (navigator.appVersion.indexOf('MSIE 5.5') > -1) {
		isIE55 = true;
	} else if (navigator.appVersion.indexOf('MSIE 5.0') > -1) {
		isIE5 = true;
	} else if (navigator.appVersion.indexOf('MSIE 4.') > -1) {
		isIE4 = true;
	} else {
		isIE3 = true;
	}
} else {
	if (browser_version >= 5) {
		isWB5 = true;
	} else if (browser_version >= 4) {
		isWB4 = true;
	} else if (browser_version >= 3) {
		isWB3 = true;
	}
}
