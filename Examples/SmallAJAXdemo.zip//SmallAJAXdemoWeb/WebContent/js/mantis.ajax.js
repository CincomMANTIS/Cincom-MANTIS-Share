<!--
/*
 * The MantisXML Software License, Version 1.0
 *
 *
 * Copyright (c) 2004-2010 Cincom Systems, Inc.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution,
 *    if any, must include the following acknowledgment:
 *       "This product includes software developed by
 *        Cincom Systems, Incorporated (http://www.cincom.com/)."
 *    Alternately, this acknowledgment may appear in the software itself,
 *    if and wherever such third-party acknowledgments normally appear.
 *
 * 4. The names "MANTIS" and "Cincom Systems, Incorporated" must
 *    not be used to endorse or promote products derived from this
 *    software without prior written permission. For written
 *    permission, please contact cincome@cincom.com.
 *
 * 5. Products derived from this software may not be called "Cincom",
 *    nor may "Cincom" appear in their name, without prior written
 *    permission of Cincom Systems, Incorporated.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL CINCOM SYSTEMS, INCOPORATED BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
 * OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
 * OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * =============================================================================
 */


// This file contains Javascript functions, both public and private, for use
// with Cincom's MantisXML product.  Customizations of this file should not be
// performed by the customer and are NOT supported by Cincom.  Problems or
// issues with this file should be reported to Cincom's Product Support Center.
// Additions and/or modifications should be placed in mantis.custom.js.
//
// Public functions are denoted by names beginning with M$ and are intended to
// be callable both by Mantis and by custom code.  They make use of whatever
// AJAX library is specified in the webapp.properties file (as of Apr'10 only
// jQuery is fully supported).  If no AJAX library has been specified then
// behavior reverts to original.
// List of public functions in this file:
//     M$getAjaxLibrary()         - get AjaxLibrary from webapp.properties
//     M$getMenuLibrary()         - get MenuLibrary from webapp.properties
//     M$getScrollItemsPerLoad()  - get ScrollItemsPerLoad from webapp.properties
//     M$showAjaxLibrary()        - alert popup M$getAjaxLibrary()
//     M$showMenuLibrary()        - alert popup M$getMenuLibrary()
//     M$showScrollItemsPerLoad() - alert popup M$getScrollItemsPerLoad()
//     M$setDirKey()              - set the dir key used by M$dirMore()
//     M$dirMore()                - initiates scrolling dir lists
//     M$addInputMouseover()      - adds a mouseover popup to all input fields
//     M$filter()                 - filters rows in a display list
//     M$showPopupMessage()       - displays a non-modal popup message
//     M$hidePopupMessage()       - hides the M$showPopupMessage()
//     M$getAjaxBody()            - gets AJAX string from <input> elements
//     M$callAjax()               - makes AJAX call and returns the result
//     M$openPopupFloat()         - popup dialog from id popupFloat
//     M$closePopupFloat()        - closes the M$openPopupFloat()
//     M$movePopupFloatToForm()   - append #popupFloat to <form>
//     M$getFormElements()        - gets elements from form with tagName
//     M$createTabs()             - creates facility selection tabs on screen
//     M$saveTabs()               - saves facility selection tab groupings
//     M$restoreTabs()            - restores facility selection tab groupings
//     M$createPlots()            - creates bar plots from div id="manBar"
//     M$createGrids()            - creates table grids table id="manGrid"
//     M$addPhotoMouseover()      - adds a mouseover popup to all photo links
//     M$addMusicMouseover()      - adds a mouseover popup to all music links
//     M$openPopupURL()           - creates modal popup dialog from url
//     M$getSelectList()          - retrieve option list for select box
//
// Private functions are members of the Mantis global namespace object __M$.
// These functions are considered internal/reserved and should NOT be invoked
// by external custom code.
// List of private functions in this file:
//     __M$.getXmlHttpObject()                 - helper for raw AJAX calls
//     __M$.getHTML()                          - helper for pressKey()
//     __M$.reportError()                      - alert popup AJAX errors
//     __M$.pageDone()                         - processes AJAX results
//     __M$.getNextScreen()                    - helper for M$dirMore()
//     __M$.processNextScreen()                - helper for M$dirMore()
//     __M$.addLoadButton()                    - helper for M$dirMore()
//     __M$.continueLoading()                  - helper for M$dirMore()
//     __M$.getDirScreen()                     - helper for M$dirMore()
//     __M$.pressKey()                         - helper for M$dirMore()
//     __M$.repositionServer()                 - helper for M$dirMore()
//     __M$.repositionServerUsingListposname() - helper for M$dirMore()
//     __M$.repositionServerUsingSelectbox()   - helper for M$dirMore()
//     __M$.repositionServerUsingBckkey()      - helper for M$dirMore()
//     __M$.updatePageTitle()                  - updates MANTIS page title

var __M$ = new Object(); // Mantis global namespace object
__M$.xmlHttp = null;
__M$.ajaxLibrary = "";
__M$.menuLibrary = "";
__M$.scrollItemsPerLoad = "";
__M$.ajaxLibraryRetrieved = false;
__M$.menuLibraryRetrieved = false;
__M$.scrollItemsPerLoadRetrieved = false;


/*------------------------------------------------------------------------------
 * public getAjaxLibrary()
 * Ask the server to read the AjaxLibrary value from the webapp.properties file.
 */
function M$getAjaxLibrary()
{
	if( ! __M$.ajaxLibraryRetrieved )
	{
		__M$.xmlHttp = __M$.getXmlHttpObject();
		if( __M$.xmlHttp == null )
			return __M$.ajaxLibrary;
	
		var url = "Resume";
		url += "?FUNCTION=" + "GetAjaxLibrary";
		url += "&sid=" + Math.random();
	
		__M$.xmlHttp.open( "GET", url, false ); // false -> Synchronous call
		__M$.xmlHttp.send( null );
		// Firefox doesn't call onreadystatechange method for synchronous calls.
		__M$.ajaxLibrary = __M$.xmlHttp.responseText;
		if( __M$.ajaxLibrary == null )
			__M$.ajaxLibrary = "";
		__M$.ajaxLibrary = __M$.ajaxLibrary.replace( /^\s+|\s+$/g, '' ); // trim

		__M$.ajaxLibraryRetrieved = true;
	}
	return __M$.ajaxLibrary;
}


/*------------------------------------------------------------------------------
 * public getMenuLibrary()
 * Ask the server to read the MenuLibrary value from the webapp.properties file.
 */
function M$getMenuLibrary()
{
	if( ! __M$.menuLibraryRetrieved )
	{
		__M$.xmlHttp = __M$.getXmlHttpObject();
		if( __M$.xmlHttp == null )
			return __M$.menuLibrary;

		var url = "Resume";
		url += "?FUNCTION=" + "GetMenuLibrary";
		url += "&sid=" + Math.random();

		__M$.xmlHttp.open( "GET", url, false ); // false -> Synchronous call
		__M$.xmlHttp.send( null );
		// Firefox doesn't call onreadystatechange method for synchronous calls.
		__M$.menuLibrary = __M$.xmlHttp.responseText;
		if( __M$.menuLibrary == null )
			__M$.menuLibrary = "";
		__M$.menuLibrary = __M$.menuLibrary.replace( /^\s+|\s+$/g, '' ); // trim

		__M$.menuLibraryRetrieved = true;
	}
	return __M$.menuLibrary;
}


/*------------------------------------------------------------------------------
 * public getScrollItemsPerLoad()
 * Ask server to read the ScrollItemsPerLoad value from webapp.properties file.
 */
function M$getScrollItemsPerLoad()
{
	if( ! __M$.scrollItemsPerLoadRetrieved )
	{
		__M$.xmlHttp = __M$.getXmlHttpObject();
		if( __M$.xmlHttp == null )
			return __M$.scrollItemsPerLoad;

		var url = "Resume";
		url += "?FUNCTION=" + "GetScrollItemsPerLoad";
		url += "&sid=" + Math.random();

		__M$.xmlHttp.open( "GET", url, false ); // false -> Synchronous call
		__M$.xmlHttp.send( null );
		// Firefox doesn't call onreadystatechange method for synchronous calls.
		__M$.scrollItemsPerLoad = __M$.xmlHttp.responseText;
		if( __M$.scrollItemsPerLoad == null )
			__M$.scrollItemsPerLoad = "";
		__M$.scrollItemsPerLoad = __M$.scrollItemsPerLoad.replace( /^\s+|\s+$/g, '' ); // trim

		__M$.scrollItemsPerLoadRetrieved = true;
	}
	return __M$.scrollItemsPerLoad;
}


/*------------------------------------------------------------------------------
 * private getXmlHttpObject()
 * Helper function for AJAX functions needing an XML HTTP object.
 */
__M$.getXmlHttpObject = function()
{
	var xmlHttp = null;
	try {
		// Firefox, Opera 8.0+, Safari
		xmlHttp = new XMLHttpRequest();
	} catch( ex1 ) {
		// Internet Explorer
		try {
			xmlHttp = new ActiveXObject( "Msxml2.XMLHTTP" );
		} catch( ex2 ) {
			try {
				xmlHttp = new ActiveXObject( "Microsoft.XMLHTTP" );
			} catch( ex3 ) {
				alert( "Your browser does not support AJAX!" );
	}	}	}
	return xmlHttp;
}


/*------------------------------------------------------------------------------
 * public M$showAjaxLibrary()
 * Show the currently selected AJAX library.
 */
function M$showAjaxLibrary()
{
	alert( "The current AjaxLibrary value in webapp.properties file is '" +
			M$getAjaxLibrary() + "'" );
}


/*------------------------------------------------------------------------------
 * public M$showMenuLibrary()
 * Show the currently selected menu library.
 */
function M$showMenuLibrary()
{
	alert( "The current MenuLibrary value in webapp.properties file is '" +
			M$getMenuLibrary() + "'" );
}


/*------------------------------------------------------------------------------
 * public M$showScrollItemsPerLoad()
 * Show the currently selected scroll items per load.
 */
function M$showScrollItemsPerLoad()
{
	alert( "The current ScrollItemsPerLoad value in webapp.properties file is '" +
			M$getScrollItemsPerLoad() + "'" );
}


/*------------------------------------------------------------------------------
 * private getHTML()
 * Helper function for pressKey() when an AJAX library is selected.
 */
__M$.getHTML = function()
{
	var url = 'Resume';
	// Build parm/value key pairs for post body or get parameters from DOM
	var parms = M$getFormElements( 'input', 'select', 'textarea' );
	var nodes;

	var ajaxLibrary = M$getAjaxLibrary();
	if( ajaxLibrary.indexOf( "prototype" ) == 0 )
		nodes = $A( parms );
	else if( ajaxLibrary.indexOf( "jquery" ) == 0 )
		nodes = jQuery.makeArray( parms );
	else
		nodes = new Array();

	var all = nodes.length;
	var body = "";

	for( var i = 0; i < all; i++ )
    {
		if( nodes[i].name != "" )
		{
			var nodeValue = nodes[i].value;
			nodeValue = nodeValue.replace(  /%/g, "%25" );// % before next lines
			nodeValue = nodeValue.replace(  /&/g, "%26" );
			nodeValue = nodeValue.replace(  /=/g, "%3D" );
			nodeValue = nodeValue.replace( /\+/g, "%2B" );
			if( body.length != 0 )
				body += '&';
			body += nodes[i].name + '=' + nodeValue;
		}
    }

	// After get parms from the screen form, before AJAX gets new screen.
	M$closePopupFloat();

	if( ajaxLibrary.indexOf( "prototype" ) == 0 ) {
		var myAjax = new Ajax.Updater(
				{success: 'manHtml'},
				url, 
				{
					method:       'post',
					asynchronous: true,
					postBody:     body,
					onFailure:    __M$.reportError,
					onComplete:   __M$.pageDone,
					evalScripts:  true
				} );
	} else if( ajaxLibrary.indexOf( "jquery" ) == 0 ) {
		jQuery.ajax(
				{
					url:      url,
					type:     "POST",
					async:    true,
					data:     body,
					error:    __M$.reportError,
					success:  __M$.pageDone,
					dataType: "html"
				} );
	}
}


/*------------------------------------------------------------------------------
 * private reportError()
 * Asynchronous function for AJAX call when an error occurs.
 */
__M$.reportError = function( request, textStatus, errorThrown )
{
	var message = 'Sorry, there was an AJAX error. - ';

	if( (request.statusText != null) && (request.statusText != '') )
		message += request.statusText;
	if( request.status != null )
		message += ' (status=' + request.status.toString() + ')';
	if( (request.responseText != null) && (request.responseText != '') )
		message += '\n' + request.responseText;

	if( (textStatus != null) && (textStatus != '') )
		message += '\n' + textStatus;

	if( (errorThrown != null) && (errorThrown != '') )
		message += '\n' + errorThrown;

	alert( message );
}


/*------------------------------------------------------------------------------
 * private pageDone()
 * Asynchronous function for AJAX call when it completes.
 */
__M$.pageDone = function( data, textStatus )
{
	var newHtml     = "";
	var ajaxLibrary = M$getAjaxLibrary();
	var menuLibrary = M$getMenuLibrary();

	// Replace screen page contents.
	if( ajaxLibrary.indexOf( "prototype" ) == 0 )
	{
		newHtml = data.responseText;
		jQuery('manHtml').value = newHtml;
	}
	else if( ajaxLibrary.indexOf( "jquery" ) == 0 )
	{
		// If ajax() dataType='xml' then convert the returned DOM to XML text.
		if( typeof data == 'object' )
			data = data.xml;

		// If the returned page is empty then there is no point to attempting
		// any further processing.
		if( (data == null) || (data == '') ) {
			var message = 'AJAX page done but no data returned!';
			if( (textStatus != null) && (textStatus != '') )
				message += '\nStatus = ' + textStatus;
			alert( message );
			return;
		}

		newHtml = data;
		var $data = jQuery( data );
		var newHead = jQuery( '#manHead', $data ).html();
		var newBody = jQuery( '#manBody', $data ).html();
		if( (newBody == null) || (newBody == '') || (newBody == 'null') )
			alert( 'Missing <div id="manBody">' );
		jQuery(document).ready( function() {
			// In some browsers using jQuery to load html containing <script>
			// results in a good page immediately followed by blank page. This
			// may be due to double execution of the scripts. The fix is to use
			// plain JavaScript and not jQuery to load the new html.
//			jQuery('div#manHtml').html( newHtml );

			// manHtml encloses the entire <html> page, header and all.
			// manHead encloses the <head> element within <html>.
			// manBody encloses the <body> element within <html>.
			// Either replace the entire <html> page, or the <head> and <body>,
			// or just <body> if <head> never changes.
			//     <div id="manHtml">
			//     <html>
			//         <div id="manHead">
			//         <head>
			//         </head></div>
			//         <div id="manBody">
			//         <body>
			//             --tabs-stuff--
			//             <form>
			//             </form>
			//             --menu-stuff--
			//         </body></div>
			//     </html></div>
//			var manHtml = document.getElementById( 'manHtml' );
//			if( manHtml != null )
//				manHtml.innerHTML = newHtml;
//			var manHead = document.getElementById( 'manHead' );
//			if( manHead != null )
//				manHead.innerHTML = newHead;
			var manBody = document.getElementById( 'manBody' );
			if( manBody != null )
				manBody.innerHTML = newBody;

			// blaw Jul'11 Find a <script> element within the <body> of the 
			// newHtml and if it does not contain 'document.write' then execute 
			// it.  Note eval('document.write') creates new blank document.
			var scriptFilename = jQuery( '#manBody script' ).attr( 'src' );
			if( (scriptFilename != null) && (scriptFilename.length > 0) ) {
				jQuery.get( scriptFilename, function( scriptContents ) {
					if( (scriptContents != null)    && 
						(scriptContents.length > 0) &&
						(scriptContents.indexOf('document.write') == -1) ) {
						eval( scriptContents );
			} } ); }
		} );
	}

	// Run the new screen page onload scripts.
	var onLoadIndexStart = newHtml.indexOf( 'onLoad="' );
	if( onLoadIndexStart == -1 )
		onLoadIndexStart = newHtml.indexOf( 'onload="' );
	if( onLoadIndexStart != -1 )
	{
		onLoadIndexStart += 8;
		var onLoadIndexEnd = newHtml.indexOf( '"', onLoadIndexStart );
		var strOnLoad = newHtml.substring( onLoadIndexStart, onLoadIndexEnd );
		eval( strOnLoad ); // This code will set cursor location
	}

	// Initialize the new screen page menus.
	if( menuLibrary.indexOf( "ddlevelsmenu" ) == 0 )
	{
		if( document.getElementById("ddtopmenubar") != null )
			ddlevelsmenu.init("ddtopmenubar", "topbar");
	}
	else if( menuLibrary.indexOf( "selectmenu" ) == 0 )
	{
		if( ajaxLibrary.indexOf( "jquery" ) == 0 )
		{
			jQuery(document).ready( function() {
				jQuery('#ddtopmenu').show();
				jQuery('select#ddsubmenu1').selectmenu( {style: 'dropdown'} );
				jQuery('select#ddsubmenu2').selectmenu( {style: 'dropdown'} );
				jQuery('select#ddsubmenu3').selectmenu( {style: 'dropdown'} );
				jQuery('select#ddsubmenu4').selectmenu( {style: 'dropdown'} );
				jQuery('select#ddsubmenu5').selectmenu( {style: 'dropdown'} );
				jQuery('select#ddsubmenu6').selectmenu( {style: 'dropdown'} );
				jQuery('select#ddsubmenu7').selectmenu( {style: 'dropdown'} );
				jQuery('select#ddsubmenu8').selectmenu( {style: 'dropdown'} );
			} );
		}
		else
			alert( "MenuLibrary=selectmenu requires AjaxLibrary=jQuery (not '" +
					ajaxLibrary + "')" );
	}

	// Add a mouseover popup to all <input> fields on the new screen page.
	M$addInputMouseover();

	// Update the page title since AJAX didn't.
	__M$.updatePageTitle();

	// Open popup dialog, if any on the page.
	M$openPopupFloat();

	// Add a mouseover popup to all photo & music links on the new screen page.
	M$addPhotoMouseover();
	M$addMusicMouseover();
}


/*------------------------------------------------------------------------------
 * public dirMore()
 * Retrieve more directory entries for display.
 */
// Some shared variables to be used by helper functions.
__M$.numRows          = 0;
__M$.$manDir          = null;
__M$.screenName       = "";
__M$.$nextScreen      = null;
__M$.ajaxBody         = "";
__M$.stopDirMore      = true;
__M$.dirMoreBusy      = false;
__M$.$manRow          = null;
__M$.continuing       = false;
__M$.screenCount      = 0;
__M$.usingListposname = false;
__M$.usingSelectbox   = false;
__M$.usingBckkey      = false;
__M$.startRowNum      = 0;

__M$.DIRKEY      = "";
__M$.BCKKEY      = null;
__M$.FWDKEY      = 'ENTER';
__M$.SNAME       = 'SEL__';
__M$.MAXROWS     = 0;
__M$.LISTPOSNAME = null;

// Global constants used in mantis.custom.js.
var M$DIRKEY      = 'DIRKEY';
var M$BCKKEY      = 'BCKKEY';
var M$FWDKEY      = 'FWDKEY';
var M$SNAME       = 'SNAME';
var M$MAXROWS     = 'MAXROWS';
var M$LISTPOSNAME = 'LISTPOSNAME';
var M$NOVALUE     = 'NOVALUE';
__M$.dirMoreValues = new Array();
__M$.dirMoreValues[M$DIRKEY]      = null;
__M$.dirMoreValues[M$BCKKEY]      = null;
__M$.dirMoreValues[M$FWDKEY]      = null;
__M$.dirMoreValues[M$SNAME]       = null;
__M$.dirMoreValues[M$MAXROWS]     = null;
__M$.dirMoreValues[M$LISTPOSNAME] = null;

function M$setDirKey( key ) { __M$.DIRKEY = key; }

function M$dirMore( screenName )
{
	__M$.screenName = screenName;

	// Set scroll info for each directory screen. All other screens just return.
	//   __M$.DIRKEY - key for dir screen from prev screen. Mutually exclusive.
	//   __M$.BCKKEY - key to go back to previous list.        "         "
	//   __M$.FWDKEY - key to go forward to next list.
	//   __M$.SNAME - Field name prefix for the S selection boxes.
	//   __M$.MAXROWS - how many rows are displayed / returned from server.
	//   __M$.LISTPOSNAME - screen field name used to position the list.
	//
	// Note do not set non-null values for both DIRKEY and BCKKEY.  DIRKEY is
	// used to return to start of listing when after the last list screen it
	// leaves the listing screen.  BCKKEY is used to return to start of listing
	// when after the last list screen it stays on the last screen.  This will
	// be enforced in code below with DIRKEY taking precedence.
	var isDirScreen = getDirMoreValues( screenName, __M$.dirMoreValues );

	// Use the values provided from getDirMoreValues().  If M$NOVALUE was
	// returned then don't set value, instead leave it for M$setDirKey().
	if( __M$.dirMoreValues[M$DIRKEY] != M$NOVALUE )
		__M$.DIRKEY  = __M$.dirMoreValues[M$DIRKEY];
	__M$.BCKKEY      = __M$.dirMoreValues[M$BCKKEY];
	__M$.FWDKEY      = __M$.dirMoreValues[M$FWDKEY];
	__M$.SNAME       = __M$.dirMoreValues[M$SNAME];
	__M$.MAXROWS     = __M$.dirMoreValues[M$MAXROWS];
	__M$.LISTPOSNAME = __M$.dirMoreValues[M$LISTPOSNAME];

	// Non dir list screens return early for good performance.
	// Note: this should come after setting the values for __M$.xxxx's in order
	// to assure that __M$.MAXROWS is reset for non dir screens.
	if( ! isDirScreen )
		return;

	// Cannot have both DIRKEY and BCKKEY.  DIRKEY has precedence.
	if( __M$.DIRKEY != null )
		__M$.BCKKEY = null;

	// Only jQuery is currently supported.
	var ajaxLibrary = M$getAjaxLibrary();
	if( ajaxLibrary.indexOf( "jquery" ) < 0 )
		return;

	// Wait until the first screen is ready and then begin adding more rows.
	jQuery(document).ready( function() {
		// If there are less than MAXROWS on the first screen then we are done.
		__M$.$manDir = jQuery( '#manDir' );
		__M$.numRows = jQuery( '[id^=manRow]', __M$.$manDir ).length;
		var $lastRow = jQuery( '#manRow' + __M$.MAXROWS, __M$.$manDir );
		var lastRowDisabled = jQuery( 'input:disabled', $lastRow ).length > 0;
		var lastRowBlank = true;
		var $lastRowLink = jQuery( 'a', $lastRow );
		var nameAttr = 'input[name$=' + __M$.SNAME + __M$.MAXROWS + ']';
		var $lastRowName = jQuery( nameAttr, $lastRow );
		if( $lastRowLink.length > 0 ) {
			var lastRowText = $lastRowLink.text();
			lastRowBlank = lastRowText.replace(/[^\x20-\x7E]/g,'').length == 0;
		} else if( $lastRowName.length > 0 ) {
			lastRowBlank = false;
		}
		if( (__M$.numRows < __M$.MAXROWS) || lastRowDisabled || 
				(lastRowBlank && ! lastRowMayBeBlank(screenName)) )
			return;

		// Set the PRESS_KEY element as having clicked SUBMIT.
		var $pressKey = jQuery( 'input[name=PRESS_KEY]' );
		$pressKey.attr( 'name',  '@KEY:' + __M$.FWDKEY );
		$pressKey.attr( 'value', 'aKey' );

		// Build the data for the ajax call.
		var parms = M$getFormElements( 'input', 'select', 'textarea' );
		var nodes = jQuery.makeArray( parms );
		__M$.ajaxBody = "";
		for( var i = 0; i < nodes.length; i++ ) {
			if( nodes[i].name != "" ) {
				if( __M$.ajaxBody != "" )
					__M$.ajaxBody += "&";
				__M$.ajaxBody += nodes[i].name + "=" + nodes[i].value;
			}
	    }

		// Since the entire display is not replaced then PRESS_KEY should be
		// restored for when it is needed again.
		$pressKey.attr( 'name', 'PRESS_KEY' );

		// Disable Submit button and change Cancel button to Stop.
		jQuery( 'input[name=ENTER]'  ).attr( 'disabled', 'disabled'    ).hide();
		jQuery( 'input[name=CANCEL]' ).attr( 'value',    'Stop loading');

		// Recurse thru more directory screens adding their rows to the display.
		__M$.stopDirMore = false;
		__M$.dirMoreBusy = true;
		M$showPopupMessage( 'Loading...' );
		__M$.screenCount = 1;
		__M$.getNextScreen();
	} );

	return;
}


/*------------------------------------------------------------------------------
 * private getNextScreen()
 * Helper function for M$dirMore().
 * Sends AJAX call for next screens worth of directory rows.
 * Calls __M$.processNextScreen() when finished.
 */
__M$.getNextScreen = function()
{
	// Get next dir screen from server but keep it to ourselves in
	// variable nextScreen instead of letting it display.
	jQuery.ajax( {
		url:      "Resume",
		type:     "POST",
		async:    true,
		data:     __M$.ajaxBody,
		dataType: "html",
		success:  __M$.processNextScreen,
		error:    __M$.reportError
	} );

	return;
}


/*------------------------------------------------------------------------------
 * private processNextScreen()
 * Helper function for M$dirMore().
 * Processes the next screens worth of directory rows to add to display.
 * Re-calls __M$.getNextScreen() to continue retrieving rows.
 * Calls __M$.getDirScreen() when finished.
 */
__M$.processNextScreen = function( nextScreen )
{
	// ScrollItemsPerLoad=nnn in webapp.properties file.
	var scrollItemsPerLoad = M$getScrollItemsPerLoad();
	if( scrollItemsPerLoad <  19 ) scrollItemsPerLoad =  19;
	if( scrollItemsPerLoad > 500 ) scrollItemsPerLoad = 500;

	var loadCanceled = false;
	var firstRowDup  = false;
	var startRowNum;

	if( __M$.continuing ) {
		startRowNum = __M$.startRowNum;
	} else {
		startRowNum = 1;
		__M$.screenCount++;
		__M$.$nextScreen = jQuery( nextScreen );
		var firstRowText = jQuery( '#manRow1', __M$.$nextScreen ).text();
		jQuery( '[id^=manRow]' ).each( function( index ) {
			if( firstRowText == jQuery(this).text() ) {
				firstRowDup = true;
			}
		} );
	}

	if( ! firstRowDup ) {
		// Loop thru each row on the next screen and add it to display.
		for( var i = startRowNum; i <= __M$.MAXROWS; i++ ) {
			var $manRow = jQuery( '#manRow' + i, __M$.$nextScreen );
			// Only use the row if it has an element <a href=...>.
			if( ($manRow.find('a, input').length > 0) &&
				(jQuery('input:disabled', $manRow).length == 0) )
			{
				__M$.numRows++;
				var continueLoading;
				if( (((__M$.numRows-1) % scrollItemsPerLoad) != 0) ||
					__M$.continuing )
				{
					__M$.continuing = false
					continueLoading = true;
				} else {
					continueLoading = confirm( (__M$.numRows-1) +
							' items loaded.  Continue loading?' );
				}
				if( continueLoading ) {
					// Change SEL__1 - SEL__19 to be SEL__20 - SEL__38, or
					// SEL__39 - SEL__57, or SEL__58 - SEL__76, or ....
					var regexp = new RegExp( "__" + i, "g" );
					var newStr = "__" + __M$.numRows;
					var newRow = $manRow.html().replace( regexp, newStr );
					// Change id="manRow1" to be id="manRow20", etc.
					var newId = 'id="manRow' + __M$.numRows + '"';
					var tagName = $manRow.attr( 'tagName' );
					newRow = '<'+tagName+' '+newId+'>'+newRow+'</'+tagName+'>';
					__M$.$manDir.append( newRow );
					__M$.startRowNum = i + 1; // Where to resume.
				} else {
					__M$.addLoadButton(); // Add new "Continue loading" button.
					__M$.numRows--; // The row was not added so don't count it.
					__M$.$manRow = $manRow; loadCanceled = true;
					__M$.startRowNum = i; // Where to resume.
					__M$.stopDirMore = true;
					__M$.pressKey( 'STOP' );
					M$hidePopupMessage();
					break;
				}
			}
		}
		__M$.continuing = false
	}

	// Set NOTE field to the latest value.
	var note = jQuery( '.message:eq(0)', __M$.$nextScreen ).text();
	if( note.replace( /[^\x20-\x7E]/g, '' ).length > 0 )
		jQuery( '.message:eq(0)' ).text( note );

	// When screen name changes, or when the last entry is disabled, then there
	// are no more dir screens.
	var nextName = jQuery('input[name="@NAME"]', __M$.$nextScreen).attr('value');
	var $lastRow = jQuery( '#manRow' + __M$.MAXROWS, __M$.$nextScreen );
	var lastRowDisabled = jQuery( 'input:disabled', $lastRow ).length > 0;
	var lastRowBlank = true;
	var $lastRowLink = jQuery( 'a', $lastRow );
	var nameAttr = 'input[name$=' + __M$.SNAME + __M$.MAXROWS + ']';
	var $lastRowName = jQuery( nameAttr, $lastRow );
	if( $lastRowLink.length > 0 ) {
		var lastRowText = $lastRowLink.text();
		lastRowBlank = lastRowText.replace(/[^\x20-\x7E]/g,'').length == 0;
	} else if( $lastRowName.length > 0 ) {
		lastRowBlank = false;
	}
	if( (nextName == __M$.screenName) && (! lastRowDisabled) &&
			((! lastRowBlank) || lastRowMayBeBlank(nextName) ) &&
			(! firstRowDup) ) {
		if( ! __M$.stopDirMore ) {
			__M$.getNextScreen();
		} else {
			__M$.addLoadButton(); // Add new "Continue loading" button.
			if( ! loadCanceled )
				__M$.$manRow = null;
			__M$.dirMoreBusy = false;
		}
	} else {
		if( __M$.DIRKEY != null )
			__M$.getDirScreen( __M$.$nextScreen );

		// Re-enable Submit button and change Stop button back to Cancel.
		jQuery( 'input[name=ENTER]'  ).removeAttr( 'disabled'  ).show();
		jQuery( 'input[name=CANCEL]' ).removeAttr( 'disabled'  );
		jQuery( 'input[name=CANCEL]' ).attr( 'value', 'Cancel' );

		M$hidePopupMessage();
		__M$.stopDirMore = true;
		__M$.dirMoreBusy = false;
	}

	return;
}


/*------------------------------------------------------------------------------
 * private addLoadButton()
 * Add a new "Continue loading" button to the MANTIS buttons ENTER and CANCEL.
 */
__M$.addLoadButton = function()
{
	var $loadButton = jQuery( 'input[name=LOAD]' );
	if( $loadButton.length == 0 ) {
		var loadButton = '<input name="LOAD" type="button" ' +
				'class="button" value="Continue loading" ' +
				'onclick="__M$.continueLoading();"/>';
		jQuery( 'input[name=ENTER]' ).parent().append( loadButton );
		$loadButton = jQuery( 'input[name=LOAD]' );
	}
	$loadButton.show();
}


/*------------------------------------------------------------------------------
 * private continueLoading()
 * Continue the looping processNextScreen() / getNextScreen() where it left off.
 */
__M$.continueLoading = function()
{
	// Remove the "Continue loading" button.
	jQuery( 'input[name=LOAD]' ).hide();

	// Disable Submit button and change Cancel button to Stop.
	jQuery( 'input[name=ENTER]'  ).attr( 'disabled', 'disabled'    ).hide();
	jQuery( 'input[name=CANCEL]' ).attr( 'value',    'Stop loading');

	// Recurse thru more directory screens adding their rows to the display.
	__M$.stopDirMore = false;
	__M$.dirMoreBusy = true;
	__M$.continuing = true;
	M$showPopupMessage( 'Loading...' );
	__M$.processNextScreen();
}


/*------------------------------------------------------------------------------
 * private getDirScreen()
 * Helper function for M$dirMore().
 * Re-gets the main menu screen in order to ask it to redo the dir screen.
 * This is necessary in order to have the MANTIS server in sync with display.
 */
__M$.getDirScreen = function( $mainScreen )
{
	// Set the PRESS_KEY element as having clicked the DIR key.
	var $pressKey = jQuery( 'input[name=PRESS_KEY]', $mainScreen );
	$pressKey.attr( 'name',  '@KEY:' + __M$.DIRKEY );
	$pressKey.attr( 'value', 'aKey' );

	// Build the data for the ajax call.
	var ajaxBody = "";
	jQuery( 'input', $mainScreen ).each( function( index ) {
		var $node = jQuery(this);
		if( $node.attr('name') != "" ) {
			if( ajaxBody != "" )
				ajaxBody += "&";
			ajaxBody += $node.attr('name') + "=" + $node.attr('value');
		}
	} );

	// Since the entire display is not replaced then PRESS_KEY should be
	// restored for when it is needed again.
	$pressKey.attr( 'name', 'PRESS_KEY' );

	// Send DIR key to the main menu screen in order to position the MANTIS
	// server on the DIR screen.
	jQuery.ajax( {
		url:      "Resume",
		type:     "POST",
		async:    false,
		data:     ajaxBody,
		dataType: "html",
		success:  function( data ) { return; },
		error:    __M$.reportError
	} );

	return;
}


/*------------------------------------------------------------------------------
 * private pressKey()
 * Helper function for M$dirMore().
 * This function is called from href's in the XSL file.
 */
__M$.pressKey = function( key, __num )
{
	M$hidePopupMessage();

	// Prevent double click.
	jQuery( 'input[name=CANCEL]' ).attr( 'disabled', 'disabled' );

	// Disable clicking on another link while waiting for dirMore() to stop.
	if( key != "STOP" ) {
		jQuery( 'a' ).attr( 'disabled', 'disabled' );
		jQuery( 'input' ).attr( 'disabled', 'disabled' );
	}

	// Set stop flag and wait until dirMore() has stopped its ajax() calls.
	// Javascript does not have a sleep() nor pause() nor waitFor(), so
	// repeatedly set timeout until dirMore() is not busy and then continue.
	__M$.stopDirMore = true;
	waitForDirMoreNotBusy();
	function waitForDirMoreNotBusy() {
		if( __M$.dirMoreBusy )
			setTimeout( waitForDirMoreNotBusy, 100 );
		else
			__M$.repositionServer( key, __num );
	};
}


/*------------------------------------------------------------------------------
 * private repositionServer()
 * Helper function for M$dirMore(), really a continuation of __M$.pressKey().
 * Repositions the MANTIS server and then calls pressKey().
 */
__M$.repositionServer = function( key, __num )
{
	// If STOP then we're done.
	if( key == "STOP" ) {
		// Re-enable Submit button and change Stop button back to Cancel.
		jQuery( 'input[name=ENTER]'  ).removeAttr( 'disabled' ).show();
		jQuery( 'input[name=CANCEL]' ).removeAttr( 'disabled' );
		jQuery( 'input[name=CANCEL]' ).attr( 'value', 'Cancel' );
		M$hidePopupMessage();
		return;
	}

	// Some screens apps can be repointed, some can move backwards,
	// others need the particular select box to be displayed.
	if( (__M$.LISTPOSNAME != null) && (__M$.LISTPOSNAME != '') ) {
		__M$.repositionServerUsingListposname( key, __num );
	} else if( __M$.BCKKEY != null ) {
		__M$.repositionServerUsingBckkey( key, __num );
	} else {
		__M$.repositionServerUsingSelectbox( key, __num );
	}
}


/*------------------------------------------------------------------------------
 * private repositionServerUsingListposname()
 * A continuation of __M$.repositionServer().
 * Repositions the MANTIS server and then calls pressKey().
 */
__M$.repositionServerUsingListposname = function( key, __num )
{
	if( __M$.usingListposname ) // Firefox might call twice when CR is used.
		return;
	__M$.usingListposname = true;

	// Get first & last screen names from map set.  E.g. get CONTROL-DIR_DISPLAY
	// and CONTROL-DIR_SELECT from CONTROL-DIR_DISPLAY.DIR_SELECT
	var dashPos     = __M$.screenName.indexOf( '-' );
	var firstDotPos = __M$.screenName.indexOf( '.' );
	var lastDotPos  = __M$.screenName.lastIndexOf( '.' );
	if( firstDotPos == -1 )
		firstDotPos = __M$.screenName.length;
	if( lastDotPos == -1 )
		lastDotPos = dashPos;
	var screenName1 = __M$.screenName.substring( 0,             dashPos + 1 );
	var screenName2 = __M$.screenName.substring( dashPos + 1,   firstDotPos );
	var screenName3 = __M$.screenName.substring( lastDotPos + 1             );
	var firstScreenName = screenName1 + screenName2;
	var lastScreenName  = screenName1 + screenName3;

	// Set the REPOINT element to the current item.
	var num = __num.substring( 2 ); // E.g. get '42' from '__42'.
	var repoint = jQuery( '#manRow' + num ).find( 'a[href]' ).text();
	repoint = repoint.replace( /[^\x20-\x7E]/g, '' ); // Remove invisible chars
	var $repoint;
	var newName;
	if( __M$.LISTPOSNAME.indexOf('-') == -1 ) {
		// E.g. mantis.custom.js contains the following style line:
		//   values[M$LISTPOSNAME] = 'INPUT_LINE';
		$repoint = jQuery( 'input[name=' + __M$.LISTPOSNAME + ']' );
		newName = firstScreenName.replace('-',':') + '-' + __M$.LISTPOSNAME;
	} else {
		// E.g. mantis.custom.js contains the following style line:
		//   values[M$LISTPOSNAME] = 'CONTROL-RESERVED_INFO-INPUT_LINE';
		var index = __M$.LISTPOSNAME.lastIndexOf( '-' );
		var fieldName = __M$.LISTPOSNAME.substring( index + 1 );
		$repoint = jQuery( 'input[name=' + fieldName + ']' );
		newName = __M$.LISTPOSNAME.replace('-',':');
	}
	$repoint.attr( 'name',  newName );
	$repoint.attr( 'value', repoint );

	// Clear all the select boxes.
	jQuery( 'input[name*=-' + __M$.SNAME + ']' ).attr( 'value', '' );

	// Set the PRESS_KEY element as having clicked the Submit button.
	var $pressKey = jQuery( 'input[name=PRESS_KEY]' );
	$pressKey.attr( 'name',  '@KEY:ENTER' );
	$pressKey.attr( 'value', 'aKey' );

	// Build the data for the ajax call.
	var ajaxBody = "";
	jQuery( 'input' ).each( function( index ) {
		var $node = jQuery(this);
		var name = $node.attr('name');
		if( name != "" ) {
			if( (name.substring(0,5) != __M$.SNAME  ) ||
				(name.substring(5)   <= __M$.MAXROWS) )
			{
				if( ajaxBody != "" )
					ajaxBody += "&";
				ajaxBody += name + "=" + $node.attr('value');
			}
		}
	} );

	// Since the entire display is not replaced then REPOINT and PRESS_KEY
	// should be restored for when needed again.
	$pressKey.attr( 'name', 'PRESS_KEY' );
	$repoint .attr( 'name', __M$.LISTPOSNAME ).attr( 'value', '' );

	// Send Submit to position the MANTIS server so the selected item is first
	// in the list.
	jQuery.ajax( {
		url:      "Resume",
		type:     "POST",
		async:    false,
		data:     ajaxBody,
		dataType: "html",
		success:  function( data ) { return; },
		error:    __M$.reportError
	} );

	// Put 'S' in first selection field and send Submit to the MANTIS server.
	jQuery( 'input[name*=-' + __M$.SNAME + ']' ).attr( 'value', '' );
	var fieldName = lastScreenName.replace('-',':') + '-' + __M$.SNAME + '1';
	setValue( __M$.SNAME + '1', fieldName, 'S' );
	pressKey( key );

	__M$.usingListposname = false;
	return;
}


/*------------------------------------------------------------------------------
 * private repositionServerUsingSelectbox()
 * A continuation of __M$.repositionServer().
 * Repositions the MANTIS server and then calls pressKey().
 */
__M$.repositionServerUsingSelectbox = function( key, __num )
{
	if( __M$.usingSelectbox ) // Firefox might call twice when CR is used.
		return;
	__M$.usingSelectbox = true;

	var fieldName;
	var itemName;
	var $pressKey;
	var ajaxBody;
	var newScreen;
	var $newScreen;

	// Remember the selected field and clear all select boxes.
	var $field = jQuery('input[name$=-' + __M$.SNAME+__num.substring(2) + ']');
	fieldName = $field.attr( 'name' );
	itemName = $field.parent().parent().text();
	jQuery( 'input[name*=-' + __M$.SNAME + ']' ).attr( 'value', '' );

	// Send Cancel to server to get it back to the menu screen.
	$pressKey = jQuery( 'input[name=PRESS_KEY]' );
	$pressKey.attr( 'name', '@KEY:CANCEL' ).attr( 'value', 'aKey' );
	ajaxBody = M$getAjaxBody();
	newScreen = M$callAjax( ajaxBody );
	$newScreen = jQuery( newScreen );
	$pressKey.attr( 'name', 'PRESS_KEY' ).attr( 'value', '' );

	// Send Dir key to server to get it to start dir list from beginning.
	$pressKey = jQuery( 'input[name=PRESS_KEY]', $newScreen );
	$pressKey.attr( 'name', '@KEY:' + __M$.DIRKEY ).attr( 'value', 'aKey' );
	ajaxBody = M$getAjaxBody( $newScreen );
	newScreen = M$callAjax( ajaxBody );
	$newScreen = jQuery( newScreen );
	$pressKey.attr( 'name', 'PRESS_KEY' ).attr( 'value', '' );

	// Repeat Submit until the selected field is on the screen.
	var oldName = jQuery( 'input[name="@NAME"]', $newScreen ).attr( 'value' );
	var itemNumber = 0;
	while( itemNumber == 0 ) {
		jQuery('input[name^='+__M$.SNAME+']', $newScreen).each(function(index) {
			if( jQuery(this).parent().parent().text() == itemName )
				itemNumber = index + 1;
		} );
		if( itemNumber == 0 ) {
			// Send Submit to server to get the next screen.
			$pressKey = jQuery( 'input[name=PRESS_KEY]', $newScreen );
			$pressKey.attr('name', '@KEY:' + __M$.FWDKEY).attr('value', 'aKey');
			ajaxBody = M$getAjaxBody( $newScreen );
			newScreen = M$callAjax( ajaxBody );
			$newScreen = jQuery( newScreen );
			$pressKey.attr( 'name', 'PRESS_KEY' ).attr( 'value', '' );

			// The screen name changing back to the menu screen without having
			// found the itemName is impossible.
			var newName = jQuery('input[name="@NAME"]', $newScreen).attr('value');
			if( newName != oldName ) {
				alert( 'ERROR: Logical inconsistency!\nFailed to find "' +
						itemName + '"' );
				break;
			}
		}
	}

	// Put 'S' in selected field box and send Submit to the MANTIS server.
	fieldName = fieldName.replace( '-', ':' );
	fieldName = fieldName.substring( 0, fieldName.indexOf(':' + __M$.SNAME) );
	fieldName += '-' + __M$.SNAME + itemNumber;
	setValue( __M$.SNAME + itemNumber, fieldName, 'S' );
	pressKey( key );

	__M$.usingSelectbox = false;
	return;
}


/*------------------------------------------------------------------------------
 * private repositionServerUsingBckkey()
 * A continuation of __M$.repositionServer().
 * Repositions the MANTIS server and then calls pressKey().
 */
__M$.repositionServerUsingBckkey = function( key, __num )
{
	if( __M$.usingBckkey ) // Firefox might call twice when CR is used.
		return;
	__M$.usingBckkey = true;

	var fieldName;
	var itemName;
	var $pressKey;
	var ajaxBody;
	var newScreen;
	var $newScreen;

	// Remember the selected field and clear all select boxes.
	var $field = jQuery('input[name$=-' + __M$.SNAME+__num.substring(2) + ']');
	fieldName = $field.attr( 'name' );
	itemName = $field.parent().text();
	jQuery( 'input[name*=-' + __M$.SNAME + ']' ).attr( 'value', '' );

	// Repeat back key until the selected field is on the screen.
	$newScreen = __M$.$nextScreen;
	var itemNumber = 0;
	while( itemNumber == 0 ) {
		jQuery('input[name^='+__M$.SNAME+']', $newScreen).each(function(index) {
			if( jQuery(this).parent().text() == itemName )
				itemNumber = index + 1;
		} );
		if( itemNumber == 0 ) {
			// Send back key to server to get the previous screen.
			$pressKey = jQuery( 'input[name=PRESS_KEY]', $newScreen );
			$pressKey.attr('name', '@KEY:' + __M$.BCKKEY).attr('value', 'aKey');
			ajaxBody = M$getAjaxBody( $newScreen );
			newScreen = M$callAjax( ajaxBody );
			$newScreen = jQuery( newScreen );
			$pressKey.attr( 'name', 'PRESS_KEY' ).attr( 'value', '' );

			// Getting all the way back to the first dir screen without having
			// found the itemName is impossible.
			__M$.screenCount--;
			if( __M$.screenCount <= 0 ) {
				alert( 'ERROR: Logical inconsistency!\nFailed to find "' +
						itemName + '"' );
				break;
			}
		}
	}

	// Put 'S' in selected field box and send Submit to the MANTIS server.
	fieldName = fieldName.replace( '-', ':' );
	fieldName = fieldName.substring( 0, fieldName.indexOf(':' + __M$.SNAME) );
	fieldName += '-' + __M$.SNAME + itemNumber;
	setValue( __M$.SNAME + itemNumber, fieldName, 'S' );
	pressKey( key );

	__M$.usingBckkey = false;
	return;
}


/*------------------------------------------------------------------------------
 * public addInputMouseover()
 * Globally invoked when loaded by a new page, and called by pageDone() when
 * AJAX replaces a web page.
 * Add a mouseover popup to all input fields. Useful when the displayed content
 * is truncated.
 */
function M$addInputMouseover()
{
	// Only jQuery is currently supported.
	if( M$getAjaxLibrary().indexOf( "jquery" ) < 0 )
		return;

	var popupHtml = '<div ' +
			'id="popupDiv" ' +
			'style="  position: absolute; ' +
				   '     color: black; ' +
				   'background: lightyellow; ' +
				   '    border: 1px solid grey; ' +
				   '   display: none;" ' +
			'></div>';
	jQuery(document).ready( function() {
		jQuery('input').mouseover( function( event ) {
			var $popupDiv = jQuery( '#popupDiv' );
			if( $popupDiv.length == 0 ) {
				jQuery( popupHtml ).appendTo( 'body' );
				$popupDiv = jQuery( '#popupDiv' );
			}
			var $this = jQuery( this );
			var popupText = $this.attr( 'value' );
			$popupDiv.text( popupText );
			// Move 1px right in order to not block mouseout event to left side
			leftPos = $this.position().left + 1 + 'px';
			topPos  = $this.position().top  + 1 + 'px';
			$popupDiv.css( {left:leftPos, top:topPos} );
			type = $this.attr( 'type' );
			if( ($popupDiv.width() > this.offsetWidth) &&
				(type != 'button')   && 
				(type != 'submit')   &&
				(type != 'checkbox') &&
				(type != 'password') )
			{
				$popupDiv.show();
				setTimeout( "jQuery('#popupDiv').fadeOut(500)", 5000 );
			}
		} );
		jQuery('input').mouseout( function( event ) {
			var $this = jQuery( this );
			var thisLeft  = $this.position().left;
			var thisRight = thisLeft + $this.width();
			var thisTop   = $this.position().top;
			var thisBot   = thisTop + $this.height();
			var withinX = (event.pageX > thisLeft) && (event.pageX < thisRight);
			var withinY = (event.pageY > thisTop)  && (event.pageY < thisBot);
			// There can be many mouseout/over's while moving within element,
			// so don't hide until move outside of element.
			if( ! withinX || ! withinY )
				jQuery( '#popupDiv' ).hide();
		} );
	} );
};
if( typeof jQuery != 'undefined' )
	M$addInputMouseover(); // Invoke globally before AJAX has ever been used.


/*------------------------------------------------------------------------------
 * private updatePageTitle()
 * Update the page title from the contents.
 */
__M$.updatePageTitle = function()
{
	// Only jQuery is currently supported.
	if( M$getAjaxLibrary().indexOf( "jquery" ) < 0 )
		return;

	jQuery(document).ready( function() {
		var name = jQuery( 'input[name="@NAME"]' ).attr( 'value' );
		var title = 'MANTIS ' + name;
		document.title = title;
	} );
}


/*------------------------------------------------------------------------------
 * public M$filter()
 * Filter a display list using the contents of the user entered FILTER field.
 */
function M$filter( value )
{
	// Only jQuery is currently supported.
	if( M$getAjaxLibrary().indexOf( "jquery" ) < 0 )
		return;

	value = value
			.replace( /[^\x21-\x7E]/g, '' ) // Remove invisible chars
			.replace( /^\s+|\s+$/g,    '' ) // trim
			.toUpperCase();
	jQuery( '[id^=manRow]' ).each( function( index ) {
		$manRow = jQuery(this);
		var name = $manRow.find('a').text()
				.replace( /[^\x21-\x7E]/g, '' ) // Remove invisible chars
				.replace( /^\s+|\s+$/g,    '' ) // trim
				.toUpperCase();
		if( name.indexOf( value ) != -1 )
			$manRow.show();
		else
			$manRow.hide();
	} );
}


/*------------------------------------------------------------------------------
 * public showPopupMessage()
 * Display a non-modal popup message.
 */
function M$showPopupMessage( message )
{
	// Only jQuery is currently supported.
	if( M$getAjaxLibrary().indexOf( "jquery" ) < 0 )
		return;

	var divId     = 'popupMessage';
	var messageId = 'popupMessageText';
	var popupMessage = createPopupMessageDiv( divId, messageId );
	jQuery(document).ready( function() {
		var $popupMessage = jQuery( '#' + divId );
		if( $popupMessage.length == 0 ) {
			jQuery( popupMessage ).appendTo( 'body' );
			$popupMessage = jQuery( '#' + divId );
		}
		jQuery( '#' + messageId, $popupMessage ).text( message );
		$popupMessage.show();
	} );
}


/*------------------------------------------------------------------------------
 * public hidePopupMessage()
 * Remove from the display (hide) a non-modal popup message.
 */
function M$hidePopupMessage()
{
	// Only jQuery is currently supported.
	if( M$getAjaxLibrary().indexOf( "jquery" ) < 0 )
		return;

	jQuery(document).ready( function() {
		jQuery( '#popupMessage' ).hide();
	} );
}


/*------------------------------------------------------------------------------
 * public getAjaxBody()
 * Get the AJAX data string from the screen <input> elements.
 */
function M$getAjaxBody( $screen )
{
	// Only jQuery is currently supported.
	if( M$getAjaxLibrary().indexOf( "jquery" ) < 0 )
		return;

	var $inputs;
	if( $screen != null )
		$inputs = jQuery( 'input', $screen );
	else
		$inputs = jQuery( 'input' );
	var ajaxBody = "";
	$inputs.each( function( index ) {
		var $node = jQuery(this);
		if( $node.attr('name') != "" ) {
			if( ajaxBody != "" )
				ajaxBody += "&";
			ajaxBody += $node.attr('name') + "=" + $node.attr('value');
		}
	} );
	return ajaxBody;
}


/*------------------------------------------------------------------------------
 * public callAjax()
 * Do the jQuery.ajax() call.
 */
function M$callAjax( ajaxBody )
{
	// Only jQuery is currently supported.
	if( M$getAjaxLibrary().indexOf( "jquery" ) < 0 )
		return;

	var newScreen = null;
	jQuery.ajax( {
		url:      "Resume",
		type:     "POST",
		async:    false,
		data:     ajaxBody,
		dataType: "html",
		success:  function( data ) { newScreen = data; },
		error:    __M$.reportError
	} );
	return newScreen;
}


/*------------------------------------------------------------------------------
 * public openPopupFloat()
 * Create either modal or non-modal popup dialog, if any on the page.
 * Called from __M$.pageDone() when loaded via AJAX, and from XSL files
 * MANTIS_BODY_ONLOAD.XSL when loaded by browser refresh.
 */
__M$.fromPopup = false;  // Flag indicating input is from a popup dialog.
__M$.$popupFloat = null; // The popup dialog object.
function M$openPopupFloat()
{
	// Only jQuery is currently supported.
	if( M$getAjaxLibrary().indexOf( "jquery" ) < 0 )
		return;

	var doModal = false;
	var newWidth = '330';
	jQuery(document).ready( function() {
		// Create new dialog if needed.
		if( (__M$.$popupFloat == null) || (__M$.$popupFloat.length == 0) )
			__M$.$popupFloat = jQuery( '#popupFloat' );
		if( (__M$.$popupFloat != null) && (__M$.$popupFloat.length > 0) ) {
			__M$.$popupFloat.removeClass( 'popupright' ); // Styles conflict
			var modal = __M$.$popupFloat.attr( 'modal' );
			if( modal != null ) {
				modal = modal.toLowerCase();
				doModal = (modal == 'yes') || (modal == 'true');
			}
			var width = __M$.$popupFloat.attr( 'width' );
			if( width != null )
				newWidth = width;
			__M$.$popupFloat.dialog( {
				modal: doModal,
				width: newWidth,
				close: function() {
					// If nothing selected then X button was clicked
					if( jQuery('input[name*=-' + __M$.SNAME + ']').length == 0){
						M$closePopupFloat();
						pressKey( '@KEY:CANCEL' );
					}
				}
			} );
			__M$.fromPopup = true;
		}
	} );
}


/*------------------------------------------------------------------------------
 * public closePopupFloat()
 * Close the popup dialog, if any on page.
 */
function M$closePopupFloat()
{
	// Only jQuery is currently supported.
	if( M$getAjaxLibrary().indexOf( "jquery" ) < 0 )
		return;

	__M$.fromPopup = false;
	jQuery(document).ready( function() {
		if( __M$.$popupFloat != null ) {
			__M$.$popupFloat.dialog( 'destroy' );
			__M$.$popupFloat = null;
			jQuery( '#popupFloat' ).remove();
		}
	} );
}


/*------------------------------------------------------------------------------
 * public movePopupFloatToForm()
 * Put the <div id="popupFloat"> into the <form> element if necessary.
 */
function M$movePopupFloatToForm()
{
	// Only jQuery is currently supported.
	if( M$getAjaxLibrary().indexOf( "jquery" ) < 0 )
		return;

	jQuery(document).ready( function() {
		if( __M$.$popupFloat != null ) {
			jQuery( 'form' ).append( __M$.$popupFloat );
		}
	} );
}


/*------------------------------------------------------------------------------
 * public getFormElements()
 * Get all elements from the document form with the specified tagName.
 * 
 * Note forms[0].elements does not return elements marked as unselectable and
 * jQuery UI dialog widget surrounds its div with a new unselectable div.  Thus
 * there are 2 major ways to call this function: with and without a tagName arg.
 * 
 * Usage:
 *   var x = M$getFormElements();
 *   var x = M$getFormElements( 'input' );
 *   var x = M$getFormElements( '????' ); // where ???? is some other tag name
 */
function M$getFormElements( tagName1, tagName2, tagName3 )
{
	var elements1, elements2, elements3;
	var elements = new Array();

	if( tagName1 == null ) {
		elements1 = document.forms[0].elements;
	} else {
		elements1 = document.getElementsByTagName( tagName1 );
	}
	for( var i = 0; i < elements1.length; i++ ) {
		elements[i] = elements1[i];
	}

	if( tagName2 != null ) {
		elements2 = document.getElementsByTagName( tagName2 );
		var len = elements.length;
		for( var i = 0; i < elements2.length; i++ ) {
			elements[len+i] = elements2[i];
		}
	}

	if( tagName3 != null ) {
		elements3 = document.getElementsByTagName( tagName3 );
		var len = elements.length;
		for( var i = 0; i < elements3.length; i++ ) {
			elements[len+i] = elements3[i];
		}
	}

	return elements;
}


/*------------------------------------------------------------------------------
 * public createTabs()
 * Create all of the 22 facility selection tabs.  For the Facility Selection
 * screen enable all tabs, for other screens disable the tabs but highlight the
 * selected tab.
 */
function M$createTabs( screenName, userName )
{
	// Only jQuery is currently supported.
	if( M$getAjaxLibrary().indexOf( "jquery" ) < 0 )
		return;

	var tabsId = getTabsId( screenName, userName );
	var tabfolder = "tabfolder";

	jQuery(document).ready( function() {
		var examplesScreen = (screenName == 'MASTER-EXAMPLES_FACILITY');
		var masterScreen   = (screenName == 'MASTER-FACILITY');

		// No user atribute == no tabs
		if( (userName == null) || (userName == '') ) {
			jQuery('.' + tabfolder).removeClass( tabfolder );
			return;
		}

		// No tabsId (from mantis.custom.js) == no tabs
		if( (tabsId == null) || (tabsId == '') ) {
			jQuery('.' + tabfolder).removeClass( tabfolder );
			return;
		}

		// Create the 22 facility tabs
		if( examplesScreen ) {
			jQuery( '#' + tabsId ).show();
		    jQuery( '#' + tabsId + '0' ).tabs( {selected: null} );
	        jQuery( '#' + tabsId + '1' ).tabs( {selected: null} );
	        jQuery( '#' + tabsId + '2' ).tabs( {selected: null} );
	        jQuery( '#' + tabsId + '3' ).tabs( {selected: null} );
	        jQuery( '#' + tabsId + '4' ).tabs( {selected: null} );
	        var $tabsId = jQuery( 'id^=' + tabsId );
	        $tabsId.draggable();
	        $tabsId.droppable();
	        var $tabsIdList = jQuery( '.' + tabsId + 'List' );
			$tabsIdList.sortable( {
				connectWith: $tabsIdList,
				update: function( event, ui ) {
					var handle = jQuery( ui.item ).find( 'a' );
					handle.unbind( "click" );
					handle.bind  ( "click", function() { 
						var $this = jQuery( this );
						var clickAction = $this.attr( 'clickAction' );
						$this.click( function() {
							eval( clickAction );
						} );
					} );
					if( jQuery.browser.msie || jQuery.browser.opera ) {
						var clickAction = handle.attr( 'clickAction' );
						handle.click( function() {
							eval( clickAction );
						} );
					}
					M$saveTabs( screenName, userName );
					if( jQuery.browser.opera )
						document.location.reload( true );
				}
			} );
			jQuery( 'li>a', $tabsIdList ).click( function() {
				var $this = jQuery( this );
				var clickAction = $this.attr( 'clickAction' );
				eval( clickAction );
			} );
		} else {
			jQuery('#' + tabsId).tabs( {selected: null} ).show();
		}

		// Remove the space that IE puts between the 2 vertically stacked div's
		// tabsId and tabfolder.  Move the tabfolder up 20 pixels.
		// Note can't use jQuery.support.boxModel (false in msie, true in opera)
		if( (jQuery.browser.msie && !examplesScreen) || jQuery.browser.opera ) {
			jQuery('.' + tabfolder).css( { 'margin-top': '-20px' } );
		}

		// The MANTIS Facility Selection screen is special; it is the screen
		// from which the tabs are derived and for which the tabs are active.
		if( examplesScreen || masterScreen )
			return;

		// Show all tabs as disabled except the selected tab.
		var tabsToDisable = [];
		jQuery('#' + tabsId + ' a').each( function(index) {
			if( jQuery(this).attr('screenName').indexOf( screenName ) == -1)
				tabsToDisable.push( index );
		} );
		jQuery('#' + tabsId).tabs( 'option', 'disabled', tabsToDisable );

		// Remove all onclick, click, and hover behaviors.
		jQuery('#' + tabsId + ' a').attr( 'onclick', '' );
		jQuery('#' + tabsId + ' a').click( function(){
			var $parent = jQuery(this).parent();
			$parent.removeClass( 'ui-state-active ui-tabs-selected' );
			$parent.addClass( 'ui-state-default' );
		} );
		jQuery('#' + tabsId + ' a').mouseenter( function() {
			jQuery(this).css( 'background', 'transparent' );
		} );
	} );
}


/*------------------------------------------------------------------------------
 * public saveTabs()
 * Save all of the 22 facility selection tab groupings.
 */
function M$saveTabs( screenName, userName )
{
	// Only jQuery is currently supported.
	if( M$getAjaxLibrary().indexOf( "jquery" ) < 0 )
		return;

	// Only the EXAMPLES user Facility Selection screen.
	if( screenName != 'MASTER-EXAMPLES_FACILITY' )
		return;

	// No user atribute == no tabs
	if( (userName == null) || (userName == '') )
		return;

	var tabsId = getTabsId( screenName, userName );

	jQuery(document).ready( function() {
		var tabsGroups = "";
		var $tabsId = jQuery( '#' + tabsId );
		jQuery( 'li', $tabsId ).each( function( index ) {
			var $this = jQuery( this );
			var liId  = $this.attr( 'id' );
			var divId = $this.parent().parent().attr( 'id' );
			tabsGroups += liId + ' ' + divId + ',';
		} );
		if( $tabsId.is( ':visible' ) )
			setCookie( 'tabsGroups', tabsGroups, 365 );
	} );
}


/*------------------------------------------------------------------------------
 * public restoreTabs()
 * Restore all of the 22 facility selection tab groupings.
 */
function M$restoreTabs( screenName, userName )
{
	// Only jQuery is currently supported.
	if( M$getAjaxLibrary().indexOf( "jquery" ) < 0 )
		return;

	// Only the EXAMPLES user Facility Selection screen.
	if( screenName != 'MASTER-EXAMPLES_FACILITY' )
		return;

	// No user atribute == no tabs
	if( (userName == null) || (userName == '') )
		return;

	var tabsId = getTabsId( screenName, userName );

	jQuery(document).ready( function() {
		var $tabsId = jQuery( '#' + tabsId );
		var tabsGroups = readCookie( 'tabsGroups' );
		while( (tabsGroups != null) && (tabsGroups != '') ) {
			var tabStart = 0;
			var tabEnd   = tabsGroups.indexOf( ' ' );
			var groupStart = tabEnd + 1;
			var groupEnd   = tabsGroups.indexOf( ',' );
			if( (tabEnd == -1) && (groupEnd == -1) )
				break;
			if( groupEnd == -1 )
				groupEnd = tabsGroup.length;
			var tabId   = tabsGroups.substring( tabStart,   tabEnd   );
			var groupId = tabsGroups.substring( groupStart, groupEnd );
			tabsGroups = tabsGroups.substring( groupEnd + 1 );
			var $tabId = jQuery( '#' + tabId, $tabsId );
//			$tabId.remove();
			$tabId.appendTo( '#' + groupId + ' ul' );
		}
	} );
}


/*------------------------------------------------------------------------------
 * public createPlots()
 * Create any bar plot specified using div id="manBar". Only bar plots are 
 * currently supported.
 */
function M$createPlots()
{
	// Only jQuery is currently supported.
	if( M$getAjaxLibrary().indexOf( "jquery" ) < 0 )
		return;

	jQuery(document).ready( function() {
		var $manBar = jQuery( '#manBar' );
		if( $manBar.length == 0 )
			return;
		var title = $manBar.attr( 'title' );
		var $manData = jQuery( '[id^=manData]', $manBar );
		var length = $manData.length;
		if( length == 0 ) { // non-IE might not find within $manBar
			$manData = jQuery( '[id^=manData]' );
			length = $manData.length;
		}
		var names  = new Array();
		var values = new Array();
		$manData.each( function( index ) {
			var $this = jQuery(this);
			var i = length - index - 1;
			names[i]  = $this.attr( 'name' );
			var text  = $this.text().replace( /[^\x20-\x7E]/g, '' );
			var value = parseFloat( text );
			if( isNaN(value) )
				value = 0.0;
			values[i] = [value, i+1];
		} );
		jQuery( '#manPlot' ).show(); // Must precede call to jqplot()
		jQuery.jqplot( 'manPlot', [values], {
		    legend: {show: true, location: 'se'},
			seriesDefaults: {
				renderer:        jQuery.jqplot.BarRenderer,
		        rendererOptions: {barDirection: 'horizontal', 
		    	                  barPadding: 6, barMargin: 15},
		        shadowAngle:     135
			},
		    series: [{label: title}],
		    seriesColors: ["#00c000"],
		    axes:{
				xaxis: {min: 0}, 
				yaxis: {
					renderer: jQuery.jqplot.CategoryAxisRenderer, 
					ticks:    names
				}
			}
		} );
	} );
}


/*------------------------------------------------------------------------------
 * public createGrids()
 * Create any table grid specified using table id="manTable", output goes into
 * table id="manGrid".
 */
//Some shared variables to be used by helper functions.
__M$.columns  = null;
__M$.hrefs    = null;
__M$.$manGrid = null;

function M$createGrids()
{
	// Only jQuery is currently supported.
	if( M$getAjaxLibrary().indexOf( "jquery" ) < 0 )
		return;

	jQuery(document).ready( function() {
		// Find all input id="manTRownn"'s (nn = 1 to n) within id="manTable".
		var $manTable = jQuery( '#manTable' );
		if( $manTable.length == 0 )
			return;
		var $manTRows = jQuery( '[id^=manTRow]', $manTable );
		var length = $manTRows.length;
		if( length == 0 ) { // non-IE might not find within $manTable
			$manTRows = jQuery( '[id^=manTRow]' );
			length = $manTRows.length;
		}
		if( length == 0 )
			return;
		__M$.$manGrid = jQuery( '#manGrid' );
		if( __M$.$manGrid.length == 0 )
			return;
		if( jQuery( '#manTable[hide="okay"]' ).length > 0 )
			$manTable.hide();

		// Setup output table id="manGrid". All input columns in all rows must
		// have attribute id="manTCol". The set of columns in the first row must
		// also have attributes title and width.
		//   <tr id="manTRow1">
		//     <td id="manTCol" title="Title1" width= "50">xxxx</td>
		//     <td id="manTCol" title="Title2" width="125">yyyy</td>
		//        |
		//   </tr>
		//   <tr id="manTRow2">
		//     <td id="manTCol">aaaa</td>
		//     <td id="manTCol">bbbb</td>
		//        |
		//   </tr>
		__M$.columns = new Array();
		var cellEdit = false;
		jQuery( '#manTCol', $manTRows[0] ).each( function( index ) {
			var $this = jQuery( this );
			var title = $this.attr( 'title' );
			var width = $this.attr( 'width' );
			// If the cell value is in percent then remove the % and multiply
			// by 10 resulting in 100% being 1000 pixels.
			if( width.indexOf('%') == (width.length - 1) )
				width = width.substring(0,width.length-1) * 10;
			var editable = jQuery( 'input', $this ).length > 0;
			if( editable )
				cellEdit = true; // true if any cell is editable
			var value = __M$.getTColValue( $this );
			var intValue = parseInt( value );
			var sorttype;
			if( isNaN( intValue ) )
				sorttype = 'text';
			else if( value.indexOf('.') != -1 )
				sorttype = 'float';
			else
				sorttype = 'int';
			__M$.columns[index] = {
					name:     title, 
					index:    title, 
					width:    width, 
					editable: editable,
					sorttype: sorttype
			};
		} );
		__M$.$manGrid.show();
		// http://www.trirand.com/jqgridwiki/doku.php?id=wiki:retrieving_data#array_data
		// "Despite the fact that the primary goal of jqGrid is to represent 
		// dynamic data returned from a database, jqGrid includes a wide range 
		// of methods to manipulate data at client side."
		__M$.hrefs = new Array();
		__M$.$manGrid.jqGrid( {
				datatype:     'clientSide',
				colModel:     __M$.columns,
				height:       'auto',
				cellEdit:     cellEdit,
				cellSubmit:   'clientArray',
				onCellSelect: function( rowId, colIndex, cellContent, event ) {
					var href = __M$.hrefs[cellContent];
					if( (href != null) && (href != '') )
						eval( href );
				}
		} );

		// For each row in the input table create a new row in the output table
		// containing all the columns with attribute id="manTCol". And then hide
		// the original input row.
		$manTRows.each( function( indexRow, thisRow ) {
			var $thisRow = jQuery( thisRow );
			var newRow = new Object();
			jQuery( '#manTCol', $thisRow ).each( function( indexCol, thisCol ) {
				var $thisCol = jQuery( thisCol );
				var value = __M$.getTColValue( $thisCol );
				var title = __M$.columns[indexCol]['index'];
				newRow[title] = value;
				// Save all href's for calling from onCellSelect function.
				var href = jQuery( '[href]', $thisCol ).attr( 'href' );
				if( (href != null) && (href != '') ) {
					__M$.hrefs[value] = href;
				} else {
					var onchange = jQuery( '[onchange]', $thisCol )
							.attr( 'onchange' );
					__M$.hrefs[value] = onchange;
				}
			} );
			__M$.$manGrid.jqGrid( 'addRowData', indexRow + 1, newRow );
			$thisRow.hide();
		} );

		// If the message contains "end of list" then we are done.
		var message = jQuery( 'span.message' ).text();
		message = message.replace( /[^\x20-\x7E]/g, ' ' );
		if( message.toLowerCase().indexOf( 'end of list' ) != -1 )
			return;

		// Set the PRESS_KEY element as having clicked SUBMIT.
		var $pressKey = jQuery( 'input[name=PRESS_KEY]' );
		$pressKey.attr( 'name',  '@KEY:PF1' );
		$pressKey.attr( 'value', 'aKey' );

		// Build the data for the ajax call.
		var parms = M$getFormElements( 'input', 'select', 'textarea' );
		var nodes = jQuery.makeArray( parms );
		__M$.ajaxBody = "";
		for( var i = 0; i < nodes.length; i++ ) {
			if( nodes[i].name != "" ) {
				if( __M$.ajaxBody != "" )
					__M$.ajaxBody += "&";
				__M$.ajaxBody += nodes[i].name + "=" + nodes[i].value;
			}
	    }

		// Since the entire display is not replaced then PRESS_KEY should be
		// restored for when it is needed again.
		$pressKey.attr( 'name', 'PRESS_KEY' );

		// Disable Submit button.
		jQuery( 'input[name=ENTER]'  ).attr( 'disabled', 'disabled'    ).hide();

		// Recurse thru more table screens adding their rows to the display.
		__M$.getNextTable();
	} );
}


__M$.getTColValue = function( $manTCol )
{
	// Hopefully the column cell has an <a> subelement.
	// Or an <input> subelement with a value.
	// If not then maybe it has a <span> subelement.
	// Otherwise use whatever text it contains in any subelements.
	var value = jQuery( 'a', $manTCol ).text();
	if( (value == null) || (value == '') )
		value = jQuery( 'input', $manTCol ).attr( 'value' );
	if( (value == null) || (value == '') )
		value = jQuery( 'span:first', $manTCol ).text();
	if( (value == null) || (value == '') )
		value = $manTCol.text();
	return value;
}


/*------------------------------------------------------------------------------
 * private getNextTable()
 * Helper function for M$createGrids().
 * Sends AJAX call for next screens worth of table rows.
 * Calls __M$.processNextTable() when finished.
 */
__M$.getNextTable = function()
{
	// Get next table screen from server but keep it to ourselves in
	// variable nextTable instead of letting it display.
	jQuery.ajax( {
		url:      "Resume",
		type:     "POST",
		async:    true,
		data:     __M$.ajaxBody,
		dataType: "html",
		success:  __M$.processNextTable,
		error:    __M$.reportError
	} );

	return;
}


/*------------------------------------------------------------------------------
 * private processNextTable()
 * Helper function for M$createGrids().
 * Processes the next screens worth of table rows to add to display.
 * Re-calls __M$.getNextTable() to continue retrieving rows.
 */
__M$.processNextTable = function( nextTable )
{
	__M$.$nextTable = jQuery( nextTable );

	// Loop thru each table row on the next screen and add it to display.
	var $manTable = jQuery( '#manTable', __M$.$nextTable );
	var $manTRows = jQuery( '[id^=manTRow]', $manTable );
	if( $manTRows.length == 0 ) // non-IE might not find within $manTable
		$manTRows = jQuery( '[id^=manTRow]', __M$.$nextTable );
	$manTRows.each( function( indexRow, thisRow ) {
		var $thisRow = jQuery( thisRow );
		var newRow = new Object();
		jQuery( '#manTCol', $thisRow ).each( function( indexCol, thisCol ) {
			var $thisCol = jQuery( thisCol );
			var value = __M$.getTColValue( $thisCol );
			var title = __M$.columns[indexCol]['index'];
			newRow[title] = value;
			// Save all href's for calling from onCellSelect function.
			var href = jQuery( '[href]', $thisCol ).attr( 'href' );
			if( (href != null) && (href != '') ) {
				__M$.hrefs[value] = href;
			} else {
				var onchange = jQuery( '[onchange]', $thisCol )
						.attr( 'onchange' );
				__M$.hrefs[value] = onchange;
			}
		} );
		__M$.$manGrid.jqGrid( 'addRowData', indexRow + 1, newRow );
		$thisRow.hide();
	} );

	// Set message field to the latest value.
	var note = jQuery( '.message:eq(0)', __M$.$nextTable ).text();
	if( note.replace( /[^\x20-\x7E]/g, '' ).length > 0 )
		jQuery( '.message:eq(0)' ).text( note );

	// If the message contains "end of list" then we are done.
	var message = jQuery( 'span.message' ).text();
	message = message.replace( /[^\x20-\x7E]/g, ' ' );
	if( message.toLowerCase().indexOf( 'end of list' ) != -1 )
		jQuery( 'input[name=ENTER]' ).removeAttr( 'disabled' ).show();
	else
		__M$.getNextTable();

	return;
}


/*------------------------------------------------------------------------------
 * public addPhotoMouseover()
 * Globally invoked when loaded by a new page, and called by pageDone() when
 * AJAX replaces a web page.
 * Add a mouseover popup to all photo links.
 *   <a href="..." photoPopup="photo.jpg">...</a>
 */
function M$addPhotoMouseover()
{
	// Only jQuery is currently supported.
	if( M$getAjaxLibrary().indexOf( "jquery" ) < 0 )
		return;

	var popupHtml = '<div ' +
			'id="photoDiv" ' +
			'style="position: absolute; ' +
				   '  border: 1px solid grey; ' +
				   ' display: none;"' +
			'><img src=""/></div>';
	jQuery(document).ready( function() {
		jQuery( '[photoPopup],[photoPopup=""]' ).mouseover( function( event ) {
			var $photoDiv = jQuery( '#photoDiv' );
			if( $photoDiv.length == 0 ) {
				jQuery( popupHtml ).appendTo( 'body' );
				$photoDiv = jQuery( '#photoDiv' );
			}
			var $this = jQuery( this );

			// Get the URL for the photo popup.  Search order:
			//   <a> has a photoPopup attribute nonblank value
			//   <a> has an href attribute not starting with 'javascript...'
			//   <a> has an href attribute starting with 'javascript...'
			//   <a> text value with spaces removed
			var photoPopup = $this.attr( 'photoPopup' );
			if( photoPopup == '' )
				photoPopup = $this.attr( 'href' );
			if( photoPopup.indexOf('javascript:') == 0 ) {
				var begin = photoPopup.indexOf(',') + 2;
				var end   = photoPopup.indexOf(',',begin) - 1;
				photoPopup = photoPopup.substring( begin, end );
			}
			if( (photoPopup.indexOf('.jpg') == -1) &&
				(photoPopup.indexOf('.bmp') == -1) &&
				(photoPopup.indexOf('.gif') == -1)  )
			{
				var photoText = $this.text();
				photoText = photoText.replace( /[^\x20-\x7E]/g, '' );
				photoPopup = 'images/' + photoText + '.jpg';
			}
			jQuery( 'img', $photoDiv ).attr( 'src', photoPopup );

			// Move 1px right in order to not block mouseout event to left side
			leftPos = $this.position().left + 1 + 'px';
			topPos  = $this.position().top  + 1 + 'px';
			$photoDiv.css( {left:leftPos, top:topPos} );
			$photoDiv.show();
			setTimeout( "jQuery('#photoDiv').fadeOut(500)", 5000 );
		} );
		jQuery( '[photoPopup],[photoPopup=""]' ).mouseout( function( event ) {
			var $this = jQuery( this );
			var thisLeft  = $this.position().left;
			var thisRight = thisLeft + $this.width();
			var thisTop   = $this.position().top;
			var thisBot   = thisTop + $this.height();
			var withinX = (event.pageX > thisLeft) && (event.pageX < thisRight);
			var withinY = (event.pageY > thisTop)  && (event.pageY < thisBot);
			// There can be many mouseout/over's while moving within element,
			// so don't hide until move outside of element.
			if( ! withinX || ! withinY )
				jQuery( '#photoDiv' ).hide();
		} );
	} );
};
if( typeof jQuery != 'undefined' )
	M$addPhotoMouseover(); // Invoke globally before AJAX has ever been used.


/*------------------------------------------------------------------------------
 * public addMusicMouseover()
 * Globally invoked when loaded by a new page, and called by pageDone() when
 * AJAX replaces a web page.
 * Add a mouseover popup to all music links.
 *   <a href="..." musicPopup="music.wma">...</a>
 */
function M$addMusicMouseover()
{
	// Only jQuery is currently supported.
	if( M$getAjaxLibrary().indexOf( "jquery" ) < 0 )
		return;

	var popupHtml = 
		'<div id="musicDiv" style="position: absolute; display: none;">' +
		'  <embed src="" width="150" height="50" autostart="true"/>' +
		'</div>';
	jQuery(document).ready( function() {
		jQuery( '[musicPopup],[musicPopup=""]' ).mouseover( function( event ) {
			// Non-IE browsers send a GET request to Resume servlet which causes
			// Mantis server to abort.  This happens with both the <embed> and
			// the <object> elements when they are appended to the <body>.
			// Note, IE demands that the <object> element have [type] attribute
			// with the proper mime setting, and that this attribute cannot be
			// set at runtime.
			if( ! jQuery.browser.msie && ! jQuery.browser.opera )
				return;

			var $musicDiv = jQuery( '#musicDiv' );
			if( $musicDiv.length == 0 ) {
				jQuery( popupHtml ).appendTo( 'body' );
				$musicDiv = jQuery( '#musicDiv' );
			}
			var $this = jQuery( this );
		
			// Get the URL for the music popup.  Search order:
			//   <a> has a musicPopup attribute nonblank value
			//   <a> has an href attribute not starting with 'javascript...'
			//   <a> has an href attribute starting with 'javascript...'
			//   <a> text value with spaces removed
			var musicPopup = $this.attr( 'musicPopup' );
			if( musicPopup == '' )
				musicPopup = $this.attr( 'href' );
			if( musicPopup.indexOf('javascript:') == 0 ) {
				var begin = musicPopup.indexOf(',') + 2;
				var end   = musicPopup.indexOf(',',begin) - 1;
				musicPopup = musicPopup.substring( begin, end );
			}
			if( (musicPopup.indexOf('.wma') == -1) &&
				(musicPopup.indexOf('.mp3') == -1)  )
			{
				var musicText = $this.text();
				musicText = musicText.replace( /[^\x20-\x7E]/g, '' );
				musicPopup = 'music/' + musicText + '.wma';
			}
			jQuery( 'object', $musicDiv ).attr( 'data', musicPopup );
			jQuery( 'embed',  $musicDiv ).attr( 'src',  musicPopup );
		
			// Move 1px right in order to not block mouseout event to left side
			leftPos = $this.position().left + 1 + 'px';
			topPos  = $this.position().top  + 1 + 'px';
			$musicDiv.css( {left:leftPos, top:topPos} );
			$musicDiv.show();
			setTimeout( "jQuery('#musicDiv').hide()", 5000 );
		} );
		jQuery( '[musicPopup],[musicPopup=""]' ).mouseout( function( event ) {
			var $this = jQuery( this );
			var thisLeft  = $this.position().left;
			var thisRight = thisLeft + $this.width();
			var thisTop   = $this.position().top;
			var thisBot   = thisTop + $this.height();
			var withinX = (event.pageX > thisLeft) && (event.pageX < thisRight);
			var withinY = (event.pageY > thisTop)  && (event.pageY < thisBot);
			// There can be many mouseout/over's while moving within element,
			// so don't hide until move outside of element.
			if( ! withinX || ! withinY )
				jQuery( '#musicDiv' ).hide();
		} );
	} );
};
if( typeof jQuery != 'undefined' )
	M$addMusicMouseover(); // Invoke globally before AJAX has ever been used.


/*------------------------------------------------------------------------------
 * public openPopupURL()
 * Create full window sized modal popup dialog with contents from url.
 * Called from openPDF() to display a PDF popup in IE.
 */
function M$openPopupURL( url, title, width, height, resize )
{
	// Only jQuery is currently supported.
	if( M$getAjaxLibrary().indexOf( "jquery" ) < 0 )
		return;

	jQuery(document).ready( function() {
		// Create new dialog if needed.
		var $popupURL = jQuery( '#popupURL' );
		if( $popupURL.length == 0 ) {
			var popupHtml = 
				'<div id="popupURL">' +
				'  <iframe id="popupURLIframe" ' +
				'      width="100%" height="100%" ' +
				'      marginWidth="0" marginHeight="0" ' +
				'      frameBorder="0" scrolling="auto">' +
				'    <p>Your browser does not support iframes.</p>' +
				'  </iframe>' +
				'</div>';
			jQuery( popupHtml ).appendTo( 'body' );
			$popupURL = jQuery( '#popupURL' );
		}
		$popupURL.dialog( {
			modal:     true,
			title:     title,
			width:     width,
			height:    height,
			resizable: resize,
			close:     function() {
				$popupURL.dialog( 'destroy' );
				jQuery( '#popupURL' ).remove();
			}
		} );
		jQuery( '#popupURLIframe' ).attr( 'src', url );
	} );
}


/*------------------------------------------------------------------------------
 * public getSelectList()
 * Retrieve option list for select box.
 */
function M$getSelectList( select )
{
	// Only jQuery is currently supported.
	if( M$getAjaxLibrary().indexOf( "jquery" ) == -1 )
		return;

	jQuery(document).ready( function() {
		var mainScreenName = jQuery('[NAME]').attr('value');
		var $select = jQuery( select );

		// If list already populated then nothing to do.
		if( jQuery('option',$select).length > 1 )
			return;

		// Send GETLIS command to main screen and get a list screen back.
		var $pressKey = jQuery( 'input[name=PRESS_KEY]' );
		$pressKey.attr( 'name', '@KEY:GETLIS' ).attr( 'value', 'aKey' );
		var listScreen = M$callAjax( M$getAjaxBody() );
		var $listScreen = jQuery( listScreen );
		$pressKey.attr( 'name', 'PRESS_KEY' ).attr( 'value', '' );
		var listScreenName = jQuery('[NAME]',$listScreen).attr('value');

		var emptyOptionFound = false;
		var optionCount = 0;
		var ajaxCallCount = 0;
		var ajaxCallLimit = 10000; // Guaranteed to stop eventually
		while( ! emptyOptionFound && (ajaxCallCount++ < ajaxCallLimit) ) {
			// Add any non-blank options to the dropdown select box.
			jQuery( '[name^=PGMNAME__]', $listScreen ).each( function() {
				var $this = jQuery( this );
				var optionName = $this.attr( 'value' );
				if( optionName != '' )
				{
					var $option = jQuery( '<option></option>' );
					$option.attr( 'value', optionName ).text( optionName );
					$select.append( $option );
					optionCount++;
				} else {
					emptyOptionFound = true; // Stops the while loop
					return false;            // Stops the jQuery.each loop.
				}
			} );

			// Send CANCEL to list screen in order to return to main screen,
			// or send ENTER to list screen to get more names.
			var key;
			if( emptyOptionFound || (ajaxCallCount >= ajaxCallLimit) ) {
				key = '@KEY:CANCEL';
			} else {
				// If no options were found and the screen stayed the same,
				// then there's a problem and CANCEL should be sent.
				if( (optionCount == 0) && (listScreenName == mainScreenName) )
					key = '@KEY:CANCEL';
				else
					key = '@KEY:ENTER';
			}
			$pressKey = jQuery( 'input[name=PRESS_KEY]', $listScreen );
			$pressKey.attr( 'name', '@KEY:' + key ).attr( 'value', 'aKey' );
			listScreen = M$callAjax( M$getAjaxBody( $listScreen ) );
			var $listScreen = jQuery( listScreen );
			$pressKey.attr( 'name', 'PRESS_KEY' ).attr( 'value', '' );
		}
	} );
}
//-->
