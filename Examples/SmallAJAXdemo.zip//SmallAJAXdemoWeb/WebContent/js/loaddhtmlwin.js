<!--
function loaddhtmlwin()
{
   var divCollection = document.getElementsByTagName("div");
   for (var i=0; i<divCollection.length; i++) 
   {
      if(divCollection[i].getAttribute("id") == "popupFloat") 
      {
         var wide = divCollection[i].getAttribute("offsetWidth");
         var high = divCollection[i].getAttribute("offsetHeight");
         var left = divCollection[i].getAttribute("offsetLeft");
         var top = divCollection[i].getAttribute("offsetTop");
         wide=wide+10;
         high=high+6;
         var popwin=dhtmlwindow.open("popbox", "div", "popupFloat", "Selection:", "width="+wide+",height="+high+",left="+left+",top="+top+",resize=1,scrolling=1,center=0", "recal")
         popwin.onclose=function()
         {
            pressKey("@KEY:CANCEL");
            return true;
         }
         document.forms[0].appendChild(popwin);  //enable new div in the FORM
         if ((top == null) || (wide > window.outerWidth))
         {
            popwin.moveTo(10,10);
            popwin.setSize(330,370);
         }
         popwin.focus();  
         i=divCollection.length;
      } 
   }
}
//-->
