<!--
/*
 * mantis.custom.js
 * A Javascript file for use in conjunction with the Cincom supplied files
 * mantis.base.js and mantis.ajax.js.  While the Cincom supplied files are NOT
 * to be altered by the customer, this file is the designated location for all
 * such customizations.  Functions may be added, altered, or deleted as desired.
 */


// Set scroll info for each directory screen. All other screens return false.
//   [M$DIRKEY]      - key for dir screen from prev screen. Mutually exclusive.
//   [M$BCKKEY]      - key to go back to previous list.        "         "
//   [M$FWDKEY]      - key to go forward to next list.
//   [M$SNAME]       - Field name prefix for the S selection boxes.
//   [M$MAXROWS]     - how many rows are displayed / returned from server.
//   [M$LISTPOSNAME] - screen field name used to position the list. 2 styles: 
//                       'fieldName' or 'MantisUser-screenName-fieldName'
//
// Note do not set non-null values for both M$DIRKEY and M$BCKKEY.  M$DIRKEY is
// used to return to start of listing when after the last list screen it
// leaves the listing screen.  M$BCKKEY is used to return to start of listing
// when after the last list screen it stays on the last screen.  This will
// be enforced in code with M$DIRKEY taking precedence.
function getDirMoreValues( screenName, values )
{
	switch( screenName ) {
	case 'CONTROL-P_D_DIRECTORY':
		values[M$DIRKEY]      = 'PF2';
		values[M$BCKKEY]      = null;
		values[M$FWDKEY]      = 'ENTER';
		values[M$SNAME]       = 'SEL__';
		values[M$MAXROWS]     = 19;
		values[M$LISTPOSNAME] = "REPOINT";
		break;
	case 'CONTROL-DIR_DISPLAY.DIR_SELECT':
		values[M$DIRKEY]      = M$NOVALUE; //Set at runtime by calling M$setDirKey().
		values[M$BCKKEY]      = null;
		values[M$FWDKEY]      = 'ENTER';
		values[M$SNAME]       = 'SEL__';
		values[M$MAXROWS]     = 19;
		values[M$LISTPOSNAME] = 'REPOINT';
		break;
	case 'EXAMPLES-HANDICAP_COURSE_SELECT':
		values[M$DIRKEY]      = 'PF2';
		values[M$BCKKEY]      = null;
		values[M$FWDKEY]      = 'ENTER';
		values[M$SNAME]       = 'SEL__';
		values[M$MAXROWS]     = 11;
		values[M$LISTPOSNAME] = null;
		break;
	case 'CASE-CASE_SELECT':
		values[M$DIRKEY]      = null;
		values[M$BCKKEY]      = 'PF7';
		values[M$FWDKEY]      = 'PF8';
		values[M$SNAME]       = 'AID__';
		values[M$MAXROWS]     = 90; //Must be mplconfig.dat MROWS value minus 10
		values[M$LISTPOSNAME] = null;
		break;
	case 'CONTROL-DIRSCRNS.DIRHEADR':
		values[M$DIRKEY]      = 'PF8';
		values[M$BCKKEY]      = null;
		values[M$FWDKEY]      = null;
		values[M$SNAME]       = null;
		values[M$MAXROWS]     = 251;
		values[M$LISTPOSNAME] = null;
		break;
	case 'CONTROL-DIRREGLR.DIRHEADR':
		values[M$DIRKEY]      = 'PF4';
		values[M$BCKKEY]      = null;
		values[M$FWDKEY]      = null;
		values[M$SNAME]       = null;
		values[M$MAXROWS]     = 251;
		values[M$LISTPOSNAME] = null;
		break;
	case 'CONTROL-DIRDLISG.DIRHEADR':
		values[M$DIRKEY]      = 'PF4';
		values[M$BCKKEY]      = null;
		values[M$FWDKEY]      = null;
		values[M$SNAME]       = 'SEL_COL__';
		values[M$MAXROWS]     = 40;
		values[M$LISTPOSNAME] = null;
		break;
	case 'CONTROL-DIRDLIPR.DIRHEADR':
		values[M$DIRKEY]      = 'PF6';
		values[M$BCKKEY]      = null;
		values[M$FWDKEY]      = null;
		values[M$SNAME]       = null;
		values[M$MAXROWS]     = 40;
		values[M$LISTPOSNAME] = null;
		break;
	case 'CONTROL-USER_DIRECTORY':
		values[M$DIRKEY]      = 'PF6';
		values[M$BCKKEY]      = null;
		values[M$FWDKEY]      = 'ENTER';
		values[M$SNAME]       = null;
		values[M$MAXROWS]     = 19;
		values[M$LISTPOSNAME] = 'REPOINT';
		break;
	case 'CONTROL-MSG_EDIT':
		values[M$DIRKEY]      = 'PF1';
		values[M$BCKKEY]      = null;
		values[M$FWDKEY]      = 'ENTER';
		values[M$SNAME]       = 'AID__';
		values[M$MAXROWS]     = 19;
		values[M$LISTPOSNAME] = 'REPOINT';
		break;
	case 'CONTROL-SHR_SAID.SHR_MAIN':
		values[M$DIRKEY]      = null;
		values[M$BCKKEY]      = 'PF8';
		values[M$FWDKEY]      = 'PF2';
		values[M$SNAME]       = 'SAID__';
		values[M$MAXROWS]     = 15;
		values[M$LISTPOSNAME] = null;
		break;
	case 'CONTROL-LICENSE_USER_LIST_UNIX':
		values[M$DIRKEY]      = null;
		values[M$BCKKEY]      = 'PF2';
		values[M$FWDKEY]      = 'PF1';
		values[M$SNAME]       = 'SEL_PID__';
		values[M$MAXROWS]     = 10;
		values[M$LISTPOSNAME] = null;
		break;
	case 'MGHIN-MGHIN_MEMBER_DIRECTORY':
		values[M$DIRKEY]      = null;
		values[M$BCKKEY]      = null;
		values[M$FWDKEY]      = 'ENTER';
		values[M$SNAME]       = 'SELECT_MEMBER__';
		values[M$MAXROWS]     = 25;
		values[M$LISTPOSNAME] = 'CONTROL-RESERVED_INFO-INPUT_LINE';
		break;
// Uncomment and add additional screen names here in the 'case' statement.
/*
	case '':
		values[M$DIRKEY]      = ;
		values[M$BCKKEY]      = ;
		values[M$FWDKEY]      = ;
		values[M$SNAME]       = ;
		values[M$MAXROWS]     = ;
		values[M$LISTPOSNAME] = ;
		break;
*/
	default:
		values[M$DIRKEY]      = null;
		values[M$BCKKEY]      = null;
		values[M$FWDKEY]      = null;
		values[M$SNAME]       = null;
		values[M$MAXROWS]     = null;
		values[M$LISTPOSNAME] = null;
		return false;
	}
	return true;
}


// Customize the creation of the popup non-modal message box used by Mantis
// during the loading of directory lists.
function createPopupMessageDiv( divId, messageId )
{
	var popupMessageDiv = '<div id="' + divId + '" ' +
			'style="           position: absolute; ' +
				   '                top: 300px; ' +
				   '               left: 46%; ' +
				   '             height: 60px; ' +
				   '        line-height: 4em; ' +
				   '           overflow: hidden; ' +
				   '              color: black; ' +
				   '         background: white; ' +
				   '             border: 2px solid gray; ' +
				   ' border-right-color: darkgreen; ' +
				   'border-bottom-color: darkgreen; ' +
				   '">' +
			'  <table>' +
			'    <tr><td valign="bottom">' +
			'      <span id="' + messageId + '"/>' +
			'    </td></tr>' +
			'    <tr><td align="center">' +
			'      <img width="30" src="images/aCinlogo.gif"/>' +
			'    </td></tr>' +
			'  </table>' +
			'</div>';
	return popupMessageDiv;
}


// Get div id to use for tabs based upon the screen name and/or the user name.
function getTabsId( screenName, userName )
{
	if( userName == null )
		userName = "";

	var tabsId = "";
	switch( userName )
	{
	case 'EXAMPLES':
		if( screenName == 'MASTER-EXAMPLES_FACILITY' )
			tabsId = 'examplestabsGroup';
		else {
			if( screenName.indexOf( "CONTROL" ) == 0 ) {
				tabsId = 'examplestabs';
				break;
			}
			break;
		}
		break;
	case 'MASTER': 
		tabsId = 'mastertabs';
		break;
	default: 
		tabsId = '';
		break;
	}
	return tabsId;
}

// List of screens for which the last row in the scrolling list may be blank
// and not hidden and not signal the end of the list.
function lastRowMayBeBlank( screenName )
{
	switch( screenName ) {
	case 'CONTROL-SHR_SAID.SHR_MAIN':
	case 'CONTROL-LICENSE_USER_LIST_UNIX':
// Uncomment and add additional screen names here in the 'case' statement.
//	case '':
//	case '':
		return false;
	default:
		return true;
	}
}
//-->
