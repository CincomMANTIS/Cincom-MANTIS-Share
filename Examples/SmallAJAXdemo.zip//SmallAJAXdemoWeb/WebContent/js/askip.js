<!--
var downStrokeField;
function askip(fieldName,nextFieldName)
{
var myForm=document.forms[document.forms.length - 1];
var myField=myForm.elements[fieldName];
if (myField != null) {
myField.nextField=myForm.elements[nextFieldName];
myField.onkeydown=askip_keyDown;
myField.onkeyup=askip_keyUp;
}
}
function askip_keyDown()
{
this.beforeLength=this.value.length;
downStrokeField=this;
}
function askip_keyUp()
{
if (
(this == downStrokeField) && 
(this.value.length >= this.beforeLength) && 
(this.value.length >= this.maxLength)
)
this.nextField.focus();
downStrokeField=null;
}
//-->
