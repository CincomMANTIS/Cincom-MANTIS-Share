<!--
/*
 * The MantisXML Software License, Version 1.0
 *
 *
 * Copyright (c) 2004-2010 Cincom Systems, Inc.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution,
 *    if any, must include the following acknowledgment:
 *       "This product includes software developed by
 *        Cincom Systems, Incorporated (http://www.cincom.com/)."
 *    Alternately, this acknowledgment may appear in the software itself,
 *    if and wherever such third-party acknowledgments normally appear.
 *
 * 4. The names "MANTIS" and "Cincom Systems, Incorporated" must
 *    not be used to endorse or promote products derived from this
 *    software without prior written permission. For written
 *    permission, please contact cincome@cincom.com.
 *
 * 5. Products derived from this software may not be called "Cincom",
 *    nor may "Cincom" appear in their name, without prior written
 *    permission of Cincom Systems, Incorporated.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL CINCOM SYSTEMS, INCOPORATED BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
 * OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
 * OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * =============================================================================
 */


/*
 * mantis.base.js (this file) contains the following functions:
 *     checksubmit()
 *     numeric( myfield, evt, name )
 *     modified( myfield, name )
 *     timeout()
 *     setValue( formObject, mantisName, value )
 *     setCursor( elementName )
 *     setFocus( formField, mantisName )
 *     _dom_trackActiveElement( evt )
 *     _dom_trackActiveElementLost( evt )
 *     pressKey( submitObject )
 *     setCheckboxYesNo( elementName )
 *     setCheckboxSelectUnselect( elementName )
 *     validate()
 *     openPrompter( url, width, height, resize, scroll )
 *     openPDF( url, width, height, resize, scroll )
 *     openScript( url, width, height )
 *     openHelp( windowName, url, width, height, resize, scroll )
 *     setCookie( name, value, days )
 *     readCookie( name )
 *     deleteCookie( name )
 *     setTextAreaLimit( field, maxlen )
 */


/*------------------------------------------------------------------------------
 * checksubmit.js
 */
var submitcount = 0;
var returnval = true;

function checksubmit()
{
	submitcount++;
	if( submitcount == 1 )
	{
	    returnval = true;
	}
	else
	{
		if( submitcount == 2 )
		{
			returnval = false;
		}
		else
		{
			alert( "Please wait, your request is being processed.  " + 
				   "You may need to press 'Enter' to proceed." );
			submitcount = 0;
			returnval = false;
		}
	}
	return returnval;
}


/*------------------------------------------------------------------------------
 * numeric.js
 */
function numeric( myfield, evt, name )
{
	var key;
	var keychar;

	if( window.event )
		key = window.event.keyCode;
	else if( evt )
		key = evt.which;
	else
	{
		myfield.name = name;
		return true;
	}
	keychar = String.fromCharCode( key );
	// control keys
	if( (key == null) || (key == 0)  || (key == 8)  || 
		(key == 9)    || (key == 13) || (key == 27) )
	{
		myfield.name = name;
		return true;
	}
	// numbers
	else if( ("0123456789.+-,").indexOf( keychar ) > -1 )
	{
		myfield.name = name;
		return true;
	}
	else
		return false;
}


/*------------------------------------------------------------------------------
 * modified.js
 */
function modified( myfield, name )
{
    myfield.name = name;
}


/*------------------------------------------------------------------------------
 * timeout.js
 */
var doSubmit = false;

function timeout()
{
	doSubmit = checksubmit();
	if( doSubmit )
		window.document.forms[0].submit();
}


/*------------------------------------------------------------------------------
 * setValue.js
 */
function setValue( formObject, mantisName, value )
{
	//Microsoft IE specific code:
	//var sourceObj = document.all.item(formObject);
	//if (sourceObj)
	//  {
	//    sourceObj.name=mantisName;
	//    sourceObj.value=value;
	//    sourceObj.onchange();
	//  }

	//Generic code, works for all browsers (but less efficient):
	var elems = M$getFormElements( 'input', 'select', 'textarea' );

	for( var i = 0; i < elems.length; i++ )
	{
		if( (elems[i].name == formObject) || (elems[i].name == mantisName) )
		{
			elems[i].name  = mantisName;
			if ( value != '' ) {
				elems[i].value = value;
			} else {
				if ( elems[i].type != 'select' ) {
					elems[i].value = value;
				}
			}
			if ( (elems[i].options != null) && (value == '') ) {
			value = elems[i].options[0].innerHTML;
			elems[i].options[0].innerHTML = "";
		    for ( var j = 1; j < elems[i].options.length; j++ ) {
		        if ( (elems[i].options[j].value == value) && (elems[i].options[j].innerText != '') ) {
		        	elems[i].options[j].selected = true;
		            j = elems[i].options.length;
		        }
		    }
			}
			if( elems[i].onchange != null )
				modified( this, mantisName );
			i = elems.length;
		}
	}
}


/*------------------------------------------------------------------------------
 * setCursor.js
 */
function setCursor( elementName )
{
	//Generic code, works for all browsers
	var elems = M$getFormElements();
	var all = elems.length;

	if( elementName != null )
	{
		var fieldFound = false;
		var index1 = elementName.indexOf( ',' );
		var index2 = elementName.lastIndexOf( ',' );
		var library = elementName.substring( 0, index1 );
		var page  = elementName.substring( index1 + 1, index2 );
		var field = elementName.substring( index2 + 1, elementName.length );

		for( var i = 0; i < all; i++ )
		{
			if( (elems[i].name == (library + ":" + page + "-" + field)) ||
				(elems[i].name == field) )
			{
				if( ((elems[i].type == "text") || (elems[i].type == "password"))
					&& (elems[i].disabled == false) )
				{
					elems[i].select();
				}
				if( (elems[i].type != "hidden") &&
					(elems[i].disabled == false))
				{
					elems[i].focus();
				}
				fieldFound = true;
				i = all;
			}
		}
		if( ! fieldFound )
		{
			var href = document.getElementById( field );

			if( href != null )
			{
				href.focus();
			} else {
	       		for (var i=0; i<all; i++)
    	   		{
       				if (this.document.forms[i].disabled != true)
       	     		{
       	        		M$getFormElements()[1].focus();
       	         		i=all;
       	    		}
       	  		}
       		}
		}
		elementName = field;
	}
	else
	{
		// always start at 1 because the NAME is always passed as hidden
		for( var i = 1; i < all; i++ ) 
		{
			if( (elems[i].type == "text") || (elems[i].type == "password") )
			{
				elems[i].select();
			}
			//if (((elems[i].isContentEditable) ||
			//     (elems[i].type == "select-one") ||
			//     (elems[i].type == "checkbox")) && elems[i].name != "")
			if( (elems[i].name != "")        && 
				(elems[i].type != "hidden")  && 
				(elems[i].disabled == false) )
			{
				elems[i].focus();
				elementName = elems[i].name;
				i = all;
			}
		}
	}
}

function setFocus( formField, mantisName )
//Generic code, works for all browsers
{
	var active = document.activeElement;

	if( active != null )
	{
		if( (active.type != "submit") && (formField != null) )
		{
			var target  = document.forms[0].elements[ formField.name ];
			var element = document.forms[0].elements[ "@CUR" ];

			if( element != null )
			{
				if( element.type == "hidden" )
				{
					element.value = mantisName;
					if( target != null )
					{
						if( target != active )
						{
							if( target.type == null ) {
								target[0].focus();
							} else {
								target.focus();
							}
						}
					}
				}
			}
		}
	}
}

//Firefox support below for activeElement and DOM compliant browsers
function _dom_trackActiveElement( evt ) 
{
	if( evt && evt.target ) 
	{
		document.activeElement = (evt.target == document) ? null : evt.target;
	}
}

function _dom_trackActiveElementLost( evt )
{
	document.activeElement = null;
} 

//determine if browser will allow events to be added
if( document.addEventListener ) 
{
	document.addEventListener( "focus", _dom_trackActiveElement,     true );
	document.addEventListener( "blur",  _dom_trackActiveElementLost, true );
}


/*------------------------------------------------------------------------------
 * pressKey.js
 */
function pressKey( submitObject )
{
	var ajaxLibrary = M$getAjaxLibrary();

	// Special case if dirMore() is running then send it a STOP.
	if( ! __M$.stopDirMore ) {
		__M$.pressKey( 'STOP' );
		return;
	}

	// Special case if SEL__ then simulate a click on a link.
	if( ajaxLibrary.indexOf( "jquery" ) != -1 ) {
		var itemNumber = 0;
		jQuery(document).ready( function() {
			// For each <input> element with '-SEL__' in its name attribute.
			jQuery( 'input[name*=-' + __M$.SNAME + ']' ).each( function() {
				var $item = jQuery( this );
				var itemValue = $item.attr( 'value' );
				// If the <input> SEL__nnn element is selected.
				if( itemValue.toUpperCase() == 'S' ) {
					// Only do the first selection
					if( itemNumber == 0 ) {
						// Extract nnn from ...-SEL__nnn.
						var itemName  = $item.attr( 'name'  );
						var index = itemName.indexOf( '-' + __M$.SNAME );
						itemNumber = itemName.substring( index + 6 );
					}
				}
			} );
		} );

		// When mantis.custom.js specifies values[M$LISTPOSNAME] = 'XXXX',
		// then the screen xsl files must contain 
		//   <span id="manRowNN">...<a href="...">repointname</a>...</span>.
		var repoint = jQuery( '#manRow' + itemNumber ).find( 'a[href]' ).text();
		repoint = repoint.replace( /[^\x20-\x7E]/g, '' );//Remove invisible char
		var missingRepoint = (__M$.LISTPOSNAME != null) && 
		                     (__M$.LISTPOSNAME != ''  ) &&
		                     (repoint == '');

		// Screen using dir scrolling must have an entry in mantis.custom.js.
		var missingCustom = (__M$.MAXROWS == null) || (__M$.MAXROWS == 0);

		// SEL__1 (and others) should get normal processing and skip this,
		// others must reposition the server through __M$.pressKey().
		if( ((itemNumber > 1) || ((itemNumber == 1) && (__M$.BCKKEY != null)))&&
			! __M$.usingSelectbox && ! __M$.fromPopup && ! __M$.usingBckkey   &&
			! missingRepoint && ! missingCustom )
		{
			__M$.pressKey( '@KEY:ENTER', '__' + itemNumber );
			return;
		}
	}

	var element = document.forms[0].elements[ "PRESS_KEY" ];
	if( (element != null) && (element.type == "hidden") && checksubmit() )
	{
		if( submitObject.indexOf( "@KEY:" ) == 0 )
			element.name = submitObject;
		else
			element.name = "@KEY:" + submitObject;
		element.value = "aKey";

		if( ajaxLibrary != "" ) {
			if( ajaxLibrary.indexOf( "jquery" ) == 0 ) {
				// Move #popupFloat input elements back into <form> element.
				M$movePopupFloatToForm();

				// If source page contains <input type="hidden" name="@RELOAD"/>
				// then use submit() to reload all button/link target pages.
				if( jQuery('input[name="@RELOAD"]').length == 0 ) {
					__M$.getHTML();
				} else {
					// <form onSubmit=""> not run with forms[0].submit()
					// So get the onSubmit attribute value and eval() it.
					var strOnSubmit = '' + jQuery('form').attr('onSubmit');
					if( (strOnSubmit == null) || (strOnSubmit == '') || (strOnSubmit == 'undefined') )
						strOnSubmit = '' + jQuery('form').attr('onsubmit');
					// IE returns "function onsubmit(){...}" for the attr.
					// Others return just the attr value string "...".
					// So make them all the same by adding "function" if needed.
					if( strOnSubmit.indexOf('function') == -1 )
						strOnSubmit = 'function onsubmit(){' + strOnSubmit + '}';
					strOnSubmit += ';onsubmit();';
					eval( strOnSubmit );
					document.forms[0].submit(); // original default behavior
				}
			} else {
				__M$.getHTML();
			}
		} else {
			document.forms[0].submit(); // original default behavior
		}

		submitcount = 0;
	}
}


/*------------------------------------------------------------------------------
 * setCheckboxYesNo.js
 */
function setCheckboxYesNo( elementName )
{
	//Generic code, works for all browsers
	var elems = M$getFormElements();

	if( elementName != null )
	{
		var index1 = elementName.indexOf( ':' );
		var index2 = elementName.lastIndexOf( '-' );
		var library = elementName.substring( 0, index1 );
		var page  = elementName.substring( index1 + 1, index2 );
		var field = elementName.substring( index2 + 1, elementName.length );
		var all = elems.length;

		for( var i = 0; i < all; i++ )
		{
			if( elems[i].name == field )
			{
				if( elems[i].checked ) {
					elems[i+1].value = "Y";
				} else {
					elems[i+1].value = "N";
				} 
				i = all;
			}
		}
	}
}


/*------------------------------------------------------------------------------
 * setCheckboxSelectUnselect.js
 */
function setCheckboxSelectUnselect( elementName )
{
	//Generic code, works for all browsers
	var elems = M$getFormElements();

	if( elementName != null )
	{
		var index1 = elementName.indexOf( ':' );
		var index2 = elementName.lastIndexOf( '-' );
		var library = elementName.substring( 0 , index1 );
		var page  = elementName.substring( index1 + 1, index2 );
		var field = elementName.substring( index2 + 1, elementName.length );
		var all = elems.length;

		for( var i = 0; i < all; i++ )
		{
			if( elems[i].name == field )
			{
				if( elems[i].checked ) {
					elems[i+1].value = "S";
				} else {
					elems[i+1].value = "";
				} 
				i = all;
			}
		}
	}
}


/*------------------------------------------------------------------------------
 * validate.js
 */
function validate()
{
	var element = document.forms[0].elements[ "@VALIDATE" ];

	if( element.type == "hidden" )
	{
		element.value = "Y";
		pressKey( '@KEY:ENTER' );  
	}
}


/*------------------------------------------------------------------------------
 * openPrompter.js
 */
function openPrompter( url, width, height, resize, scroll )
{
	var Win = window.open( url, "MANTISPrompterWindow", 'top=1, left=1' + 
			', width='+width + ',height='+height + ',resizable='+resize + 
			',scrollbars='+scroll + ',menubar=no,status=no' );
//moves opening document on top of newly opened window
//  if (top.location != location) {
//    top.location.href = document.location.href ;
//  }
}


/*------------------------------------------------------------------------------
 * openPDF.js
 */
function openPDF( url, width, height, resize, scroll )
{
	// Create a unique URL so that we never get a cached copy.
	var uniqueURL = url + '&sid=' + Math.random();

	if( navigator.appName.indexOf('Microsoft Internet Explorer') > -1 ) {
// Aug'10 IE8 displays a blank popup when trying to use jQuery popup for PDF. 
//		if( M$getAjaxLibrary() != '' ) {
//			var title = 'OUTPUT PRINTER PDF';
//			M$openPopupURL( uniqueURL, title, width, height, resize );
//		} else {
			// IE will not display PDF in a popup window so use current window
			window.location = uniqueURL;
//		}
	} else {
		var pdfwin = window.open( uniqueURL, 'OutputPrinterPDF', 
				'top=1, ' + 
				'left=1, ' +
				'width=' + width + ', ' +
				'height=' + height + ', ' +
				'resizable=' + resize + ', ' +
				'scrollbars=' + scroll + ', ' +
				'menubar=no, ' +
				'status=no, ' +
				'toolbar=no, ' +
				'location=no, ' +
				'directories=no'
		);
		pdfwin.document.title = 'OUTPUT PRINTER PDF';
	}
}


/*------------------------------------------------------------------------------
 * openScript.js
 */
function openScript( url, width, height )
{
	var Win = window.open( url, "MainMANTISWindow", 'width='+width +
			',height='+height + ',directories=no,resizable=yes,scrollbars=yes' +
			',menubar=no,toolbar=no,status=yes' );
}

//  if (top.location != location) {
//    top.location.href = document.location.href ;
//  }


/*------------------------------------------------------------------------------
 * openHelp.js
 */
function openHelp( windowName, url, width, height, resize, scroll )
{
	var Doc = window.open( url, windowName, 'top=1, left=1, width='+width + 
			',height='+height + ',resizable='+resize + ',scrollbars='+scroll +
			',menubar=no,status=no' );
//moves opening document on top of newly opened window
//  if (top.location != location) {
//    top.location.href = document.location.href ;
//  }
}


/*------------------------------------------------------------------------------
 * setCookie.js
 */
function setCookie( name, value, days )
{
	if( days )
	{
		var date = new Date();
		date.setTime( date.getTime() + (days*24*60*60*1000) );
		var expires = "; expires=" + date.toGMTString();
	}
	else
		var expires = "";
	document.cookie = name + "=" + value + expires + '; path=/';
}


/*------------------------------------------------------------------------------
 * readCookie.js
 */
function readCookie( name )
{
	var nameEQ = name + "=";
	var ca = document.cookie.split(';');

	for( var i = 0; i < ca.length; i++ )
	{
		var c = ca[i];
		while( c.charAt(0) == ' ' )
			c = c.substring( 1, c.length );
		if( c.indexOf(nameEQ) == 0 )
			return c.substring( nameEQ.length, c.length );
	}
	return null;
}


/*------------------------------------------------------------------------------
 * deleteCookie.js
 */
function deleteCookie( name )
{
	setCookie( name, "", -1 );
}


/*------------------------------------------------------------------------------
 * setTextAreaLimit.js
 */
function setTextAreaLimit( field, maxlen )
{
	if( field.value.length > maxlen + 1 )
		alert( 'Your input has been truncated to ' + maxlen + ' characters, ' +
			   'the maximum length allowed for this field.' );
	if( field.value.length > maxlen )
		field.value = field.value.substring( 0, maxlen );
}
//-->
