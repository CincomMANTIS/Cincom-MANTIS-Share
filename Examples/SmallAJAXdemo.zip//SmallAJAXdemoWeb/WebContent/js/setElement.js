<!--
function setElement(item, value)
{
var elems = document.forms[0].elements;
  elems[item].value=value;
  elems[item].onchange();
}
//-->
