/*
  ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
  ::                                                              ::
  ::                         DESCRIPTION                          ::
  ::  ---------------------------------------------------------   ::
  ::          Source for MANTIS XML Web Page Menus                ::
  ::                                                              ::
  ::                       MAINTENANCE LOG                        ::
  ::  ---Date--- ------Name------ -----------Description-------   ::
  ::                                                              ::
  ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
*/  
function ShowPage(pageName)
{
	window.location = pageName;
	return false;
}

//Menu object creation
oCMenu=new makeCM("oCMenu") //Making the menu object. Argument: menuname

oCMenu.frames = 0

//Menu properties   
oCMenu.pxBetween=0
oCMenu.fromTop=53
oCMenu.fromLeft=10
oCMenu.rows=1 
oCMenu.menuPlacement=0
                                                             
oCMenu.offlineRoot="" 
oCMenu.onlineRoot="" 
//    /pages/
oCMenu.resizeCheck=1 
oCMenu.wait=500
oCMenu.fillImg=""
oCMenu.zIndex=10

//Background bar properties
oCMenu.useBar=0
oCMenu.barWidth="100%"
oCMenu.barHeight="menu" 
oCMenu.barClass="clBar"
oCMenu.barX=0 
oCMenu.barY=0
oCMenu.barBorderX=0
oCMenu.barBorderY=0
oCMenu.barBorderClass="clbarborder"

//Level properties - ALL properties have to be spesified in level 0
oCMenu.level[0]=new cm_makeLevel() //Add this for each new level
oCMenu.level[0].width=406
oCMenu.level[0].height=18
oCMenu.level[0].regClass="clLevel0"
oCMenu.level[0].overClass="clLevel0over"
oCMenu.level[0].borderX=1
oCMenu.level[0].borderY=0
oCMenu.level[0].borderClass="clLevel0border"
oCMenu.level[0].offsetX=0
oCMenu.level[0].offsetY=16
oCMenu.level[0].rows=0
oCMenu.level[0].arrow=0
oCMenu.level[0].arrowWidth=10
oCMenu.level[0].arrowHeight=10
oCMenu.level[0].align="middle"


// SUB LEVEL[1] PROPERTIES - You have to specify the properties you want different from LEVEL[0] 
//                         - If you want all items to look the same just remove this
oCMenu.level[1]=new cm_makeLevel() //Add this for each new level (adding one to the number)
oCMenu.level[1].width=160
oCMenu.level[1].height=18
oCMenu.level[1].regClass="clLevel1"
oCMenu.level[1].overClass="clLevel1over"
oCMenu.level[1].borderX=1
oCMenu.level[1].borderY=1
oCMenu.level[1].align="right" 
oCMenu.level[1].offsetX=0
oCMenu.level[1].offsetY=0
oCMenu.level[1].borderClass="clLevel1border"
oCMenu.level[1].arrow="images/arrows.gif"
oCMenu.level[1].arrowWidth=12
oCMenu.level[1].arrowHeight=12


// SUB LEVEL[2] PROPERTIES - You have to specify the properties you want different from LEVEL[1] OR LEVEL[0]
//                         - If you want all items to look the same just remove this
oCMenu.level[2]=new cm_makeLevel() //Add this for each new level (adding one to the number)
oCMenu.level[2].width=40
oCMenu.level[2].height=18
oCMenu.level[2].offsetX=0
oCMenu.level[2].offsetY=0
oCMenu.level[2].regClass="clLevel2"
oCMenu.level[2].overClass="clLevel2over"
oCMenu.level[2].borderClass="clLevel2border"


/******************************************

myCoolMenu.makeMenu(name, parent_name, text, link, target, width, height, 
regImage, overImage, regClass, overClass, align, rows, nolink, onclick, onmouseover, onmouseout) 

*************************************/
	
oCMenu.makeMenu('top0','','Action','','','55','14','','')
 oCMenu.makeMenu('sub02','top0','Cancel','javascript:pressKey("@KEY:CANCEL");','','')
   oCMenu.makeMenu('sub021','sub02','Submit','javascript:pressKey("@KEY:ENTER");','','100')
 oCMenu.makeMenu('sub00','top0','Main Menu','javascript:setValue("KEYSIM", "CONTROL:RESERVED_INFO-KEYSIM", "KILL");pressKey("@KEY:ENTER");','','')
 oCMenu.makeMenu('sub01','top0','Program Functions (PF Key)','','','')
   oCMenu.makeMenu('sub011','sub01','1','javascript:pressKey("@KEY:PF1");','','')
   oCMenu.makeMenu('sub012','sub01','2','javascript:pressKey("@KEY:PF2");','','')
   oCMenu.makeMenu('sub013','sub01','3','javascript:pressKey("@KEY:PF3");','','')
   oCMenu.makeMenu('sub014','sub01','4','javascript:pressKey("@KEY:PF4");','','')
   oCMenu.makeMenu('sub015','sub01','5','javascript:pressKey("@KEY:PF5");','','')
   oCMenu.makeMenu('sub016','sub01','6','javascript:pressKey("@KEY:PF6");','','')
   oCMenu.makeMenu('sub017','sub01','7','javascript:pressKey("@KEY:PF7");','','')
   oCMenu.makeMenu('sub018','sub01','8','javascript:pressKey("@KEY:PF8");','','')
   oCMenu.makeMenu('sub019','sub01','9','javascript:pressKey("@KEY:PF9");','','')
   oCMenu.makeMenu('sub0110','sub01','10','javascript:pressKey("@KEY:PF10");','','')
   oCMenu.makeMenu('sub0111','sub01','11','javascript:pressKey("@KEY:PF11");','','')
   oCMenu.makeMenu('sub0112','sub01','12','javascript:pressKey("@KEY:PF12");','','')
   oCMenu.makeMenu('sub0113','sub01','13','javascript:pressKey("@KEY:PF13");','','')
   oCMenu.makeMenu('sub0114','sub01','14','javascript:pressKey("@KEY:PF14");','','')
   oCMenu.makeMenu('sub0115','sub01','15','javascript:pressKey("@KEY:PF15");','','')
   oCMenu.makeMenu('sub0116','sub01','16','javascript:pressKey("@KEY:PF16");','','')
   oCMenu.makeMenu('sub0117','sub01','17','javascript:pressKey("@KEY:PF17");','','')
   oCMenu.makeMenu('sub0118','sub01','18','javascript:pressKey("@KEY:PF18");','','')
   oCMenu.makeMenu('sub0119','sub01','19','javascript:pressKey("@KEY:PF19");','','')
   oCMenu.makeMenu('sub0120','sub01','20','javascript:pressKey("@KEY:PF20");','','')
   oCMenu.makeMenu('sub0121','sub01','21','javascript:pressKey("@KEY:PF21");','','')
   oCMenu.makeMenu('sub0122','sub01','22','javascript:pressKey("@KEY:PF22");','','')
   oCMenu.makeMenu('sub0123','sub01','23','javascript:pressKey("@KEY:PF23");','','')
   oCMenu.makeMenu('sub0124','sub01','24','javascript:pressKey("@KEY:PF24");','','')
 oCMenu.makeMenu('sub03','top0','Exit & Logoff','javascript:setValue("KEYSIM", "CONTROL:RESERVED_INFO-KEYSIM", "LOGOFF");pressKey("@KEY:ENTER");','','')

oCMenu.makeMenu('top1','','Function','','','55','14','','')
 oCMenu.makeMenu('sub11','top1','1','javascript:pressKey("@KEY:PF1");','','55')
 oCMenu.makeMenu('sub12','top1','2','javascript:pressKey("@KEY:PF2");','','55')
 oCMenu.makeMenu('sub13','top1','3','javascript:pressKey("@KEY:PF3");','','55')
 oCMenu.makeMenu('sub14','top1','4','javascript:pressKey("@KEY:PF4");','','55')
 oCMenu.makeMenu('sub15','top1','5','javascript:pressKey("@KEY:PF5");','','55')
 oCMenu.makeMenu('sub16','top1','6','javascript:pressKey("@KEY:PF6");','','55')
 oCMenu.makeMenu('sub17','top1','7','javascript:pressKey("@KEY:PF7");','','55')
 oCMenu.makeMenu('sub18','top1','8','javascript:pressKey("@KEY:PF8");','','55')
 oCMenu.makeMenu('sub19','top1','9','javascript:pressKey("@KEY:PF9");','','55')
 oCMenu.makeMenu('sub110','top1','10','javascript:pressKey("@KEY:PF10");','','55')
 oCMenu.makeMenu('sub111','top1','11','javascript:pressKey("@KEY:PF11");','','55')
 oCMenu.makeMenu('sub112','top1','12','javascript:pressKey("@KEY:PF12");','','55')
 oCMenu.makeMenu('sub113','top1','13','javascript:pressKey("@KEY:PF13");','','55')
 oCMenu.makeMenu('sub114','top1','14','javascript:pressKey("@KEY:PF14");','','55')
 oCMenu.makeMenu('sub115','top1','15','javascript:pressKey("@KEY:PF15");','','55')
 oCMenu.makeMenu('sub116','top1','16','javascript:pressKey("@KEY:PF16");','','55')
 oCMenu.makeMenu('sub117','top1','17','javascript:pressKey("@KEY:PF17");','','55')
 oCMenu.makeMenu('sub118','top1','18','javascript:pressKey("@KEY:PF18");','','55')
 oCMenu.makeMenu('sub119','top1','19','javascript:pressKey("@KEY:PF19");','','55')
 oCMenu.makeMenu('sub120','top1','20','javascript:pressKey("@KEY:PF20");','','55')
 oCMenu.makeMenu('sub121','top1','21','javascript:pressKey("@KEY:PF21");','','55')
 oCMenu.makeMenu('sub122','top1','22','javascript:pressKey("@KEY:PF22");','','55')
 oCMenu.makeMenu('sub123','top1','23','javascript:pressKey("@KEY:PF23");','','55')
 oCMenu.makeMenu('sub124','top1','24','javascript:pressKey("@KEY:PF24");','','55')
 
//This next line constructs the menu but by convention with MANTIS, the MANTIS-COMMON-MENU.js does the construct
//MANTIS-COMMON-MENU is invoked out of the MANTIS-END inculde
//oCMenu.construct()

