var days = new Array(7);

days[3] = "Wed";
days[4] = "Thu";
days[5] = "Fri";
days[6] = "Sat";
days[0] = "Sun";
days[1] = "Mon";
days[2] = "Tue";

var checkOutSelectedByUser = false;
 
var formObject = document.myform;
var todaysDate = new Date(2005, 10, 1, 0,0,0);

var tomorrowsDate = new Date(2005, 10, 2, 0,0,0);


function selectCheckinWithCalendar() {
    window.status='Calendar';
    openCalWindowDo('/popCalendar.do', 'in', 'calendarArea', 2005, (10 + 1), 1);
}

function selectCheckoutWithCalendar() {
    window.status='Calendar';
    openCalWindowDo('/popCalendar.do', 'out', 'calendarArea', 2005, (10 + 1), 1);
}


if (document.captureEvents) document.captureEvents(Event.KEYPRESS);
document.onkeypress = handleKeypress;


function handleKeypress(e) {
    var keycode;
    if (window.event) {
        e = window.event;
        keycode = e.keyCode;
        }
    else if (e) {
        keycode = e.which;
    }
    if (keycode == 13) {
        var tg = (e.target) ? e.target : e.srcElement;
        if (tg && tg.form == formObject && tg.type != "select-one" && tg.type != "select-multiple") {
            formObject.submit();
            return false;
        }
    }
    return true;
};