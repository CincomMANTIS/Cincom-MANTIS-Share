//
function selectWithCalendar() {
    //var selYear = new Date().getFullYear();
    //var selMonth = new Date().getMonth()+1;
    //var selDay = new Date().getUTCDate();
    var selYear = document.myform.CYear.value;
    var selMonth = document.myform.CMonth.value;
    var selDay = document.myform.CDay.value;
    window.status='Calendar';
    openCalWindowDo('popCalendar.html', 'calendarArea', selYear, selMonth, selDay);
}

function getMousePos(e) {
    xPos = 0;
    yPos = 0;
    if (!e) var e = window.event;
    if (e.pageX || e.pageY)
    {
        xPos = e.screenX;
        yPos = e.screenY;
    }
    else if (e.clientX || e.clientY)
    {
        xPos = e.screenX;
        yPos = e.screenY;
    }
}

function openCalWindow(thisPage, CalLocation) {

	winStats='toolbar=no,location=no,directories=no,menubar=no,'

	//IE/NS
	if (navigator.appName.indexOf("Microsoft")>=0) {winStats+='scrollbars=no,width=160,height=180'}
	else {winStats+='scrollbars=no,width=160,height=170'}

	//IE leftnav area
	if (navigator.appName.indexOf("Microsoft")>=0) {
			if(CalLocation == 'leftNavArea')
				{winStats+=',left=' + (xPos) + ',top=' + (yPos)
				 }//IE content area
			else if (CalLocation == 'contentArea')
				{winStats+=',left=' + (-200 + xPos) + ',top=' + (-160 + yPos)
				}
			else if (CalLocation == 'calendarArea')
				{winStats+=',left=' + (-150 + xPos) + ',top=' + (yPos + 20)
				}	
    } else {
		//Netscape leftnav area
		if(CalLocation == 'leftNavArea')
				{winStats+=',screenX='+ (xPos) + ',screenY=' + (yPos)
				 }//Netscape content area
			else if (CalLocation == 'contentArea')
				{winStats+=',screenX='+ (-150 + xPos) + ',screenY=' + (-230 + yPos)
				}
			else if (CalLocation == 'calendarArea')
				{winStats+=',screenX='+ (-150 + xPos) + ',screenY=' + (yPos + 20)
				}	
    }
	floater=window.open(thisPage,"myform",winStats)
	if (floater!=null) { if (floater.focus) { floater.focus() } };
}

function openCalWindowDo(thisPage, CalLocation, year, month, day) {

    var formDay = day;
    var formMonth = month;
    var formYear = year;

    var currDay = day;
    var currMonth = month;
    if (currMonth < 1 || currDay < 1) {
        currDay = day;
        currMonth = month;
        formYear = year;
    }
    else {
        var monthText = formMonth;
        if (monthText.length > 5 && monthText.charAt(monthText.length - 5) == ' ') {
            formYear = monthText.substr(monthText.length - 4);
        }
    }
    thisPage = thisPage 
        + '?' + currMonth // cal month
        + ',' + formYear  // cal year
        + ',' + formYear  // form year (or today)
        + ',' + currMonth // form month (or today)
        + ',' + currDay   // form day (or today)

    winStats='status=no,toolbar=no,location=no,directories=no,menubar=no,'

    //IE/NS
    if (navigator.appName.indexOf("Microsoft")>=0) {winStats+='scrollbars=no,width=160,height=180'}
    else {winStats+='scrollbars=no,width=160,height=170'}

    //IE leftnav area
    if (navigator.appName.indexOf("Microsoft")>=0) {
            if(CalLocation == 'leftNavArea')
                {winStats+=',left=' + (xPos) + ',top=' + (yPos)
                 }//IE content area
            else if (CalLocation == 'contentArea')
                {winStats+=',left=' + (-200 + xPos) + ',top=' + (-160 + yPos)
                }
            else if (CalLocation == 'calendarArea')
                {winStats+=',left=' + (-150 + xPos) + ',top=' + (yPos + 20)
                }   
    } else {
        //Netscape leftnav area
        if(CalLocation == 'leftNavArea')
                {winStats+=',screenX='+ (xPos) + ',screenY=' + (yPos)
                 }//Netscape content area
            else if (CalLocation == 'contentArea')
                {winStats+=',screenX='+ (-150 + xPos) + ',screenY=' + (-230 + yPos)
                }
            else if (CalLocation == 'calendarArea')
                {winStats+=',screenX='+ (-150 + xPos) + ',screenY=' + (yPos + 20)
                }   
    }
    floater=window.open(thisPage,"myform",winStats)
    if (floater!=null) { if (floater.focus) { floater.focus() } };
}