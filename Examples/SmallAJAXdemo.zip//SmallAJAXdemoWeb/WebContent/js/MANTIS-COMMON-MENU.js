/*
  ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
  ::                                                              ::
  ::                         DESCRIPTION                          ::
  ::  ---------------------------------------------------------   ::
  ::          Source for MANTIS XML Web Page Menus                ::
  ::                                                              ::
  ::                       MAINTENANCE LOG                        ::
  ::  ---Date--- ------Name------ -----------Description-------   ::
  ::                                                              ::
  ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
*/  
//This line constructs the menu
var ajaxLibrary = M$getAjaxLibrary();
if( ajaxLibrary == "" )
	oCMenu.construct();
else
	; //ddlevelsmenu

