<!--
function terminate()
{
    window.close();
}
//-->
