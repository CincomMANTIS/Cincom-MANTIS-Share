<!--
function runMWC()
{
location.href = "file:///C:/Program Files/Cincom Systems, Inc/MANTIS Windows Client for IBM MANTIS/gOOiRun.exe";
}
//-->
