window.resizeTo(1024,768);
askip('SIGNNAME','SIGNPASS');
askip('SIGNPASS','SIGNNAME');