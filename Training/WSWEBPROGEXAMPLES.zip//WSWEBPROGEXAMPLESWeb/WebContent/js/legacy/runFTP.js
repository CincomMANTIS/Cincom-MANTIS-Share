function runFTP()
{
location.href = "javascript:openHelp('FTP','ftp://username@location-of-MantisServer',790,590)";
}
