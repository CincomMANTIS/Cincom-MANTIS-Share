/*
  ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
  ::                                                              ::
  ::                         DESCRIPTION                          ::
  ::  ---------------------------------------------------------   ::
  ::          Source for MANTIS XML Web Page Menus                ::
  ::                                                              ::
  ::                       MAINTENANCE LOG                        ::
  ::  ---Date--- ------Name------ -----------Description-------   ::
  ::                                                              ::
  ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
*/  
/******************************************

myCoolMenu.makeMenu(name, parent_name, text, link, target, width, height, 
regImage, overImage, regClass, overClass, align, rows, nolink, onclick, onmouseover, onmouseout) 

*************************************/
oCMenu.makeMenu('top2','','Design','','','80','14','','')
 oCMenu.makeMenu('sub21','top2','External File View','javascript:pressKey("@KEY:PF10");','','')
 oCMenu.makeMenu('sub22','top2','Interface','javascript:pressKey("@KEY:PF8");','','')
 oCMenu.makeMenu('sub23','top2','MANTIS File View','javascript:pressKey("@KEY:PF5");','','')
 oCMenu.makeMenu('sub24','top2','Program','javascript:pressKey("@KEY:PF3");','','')
 oCMenu.makeMenu('sub25','top2','Prompter','javascript:pressKey("@KEY:PF6");','','')
 oCMenu.makeMenu('sub26','top2','TOTAL/ULTRA View','javascript:pressKey("@KEY:PF9");','','')
 
oCMenu.makeMenu('top3','','Utilities','','','80','14','','')
 oCMenu.makeMenu('sub31','top3','Search','javascript:pressKey("@KEY:PF20");','','')
 oCMenu.makeMenu('sub32','top3','Directory Facility','javascript:pressKey("@KEY:PF14");','','')
 oCMenu.makeMenu('sub33','top3','Universal Export (UEF)','javascript:pressKey("@KEY:PF15");','','')
 oCMenu.makeMenu('sub34','top3','Transfer','javascript:pressKey("@KEY:PF12");','','')
 oCMenu.makeMenu('sub35','top3','FTP','javascript:runFTP();','','')

oCMenu.makeMenu('top4','','Miscellaneous','','','90','14','','')
 oCMenu.makeMenu('sub41','top4','Run a Program','javascript:pressKey("@KEY:PF1");','','')
 oCMenu.makeMenu('sub42','top4','Display a Prompter','javascript:pressKey("@KEY:PF2");','','')
 oCMenu.makeMenu('sub43','top4','Security Patch Information','javascript:pressKey("@KEY:PF22");','','')
 oCMenu.makeMenu('sub44','top4','Sign On as Another User','javascript:pressKey("@KEY:PF11");','','')

oCMenu.makeMenu('top5','','Administration','','','80','14','','')
 oCMenu.makeMenu('sub51','top5','Design a User Profile','javascript:pressKey("@KEY:PF7");','','')
 oCMenu.makeMenu('sub52','top5','Edit MANTIS Messages','javascript:pressKey("@KEY:PF13");','','')
 oCMenu.makeMenu('sub53','top5','Update Shared Entity List','javascript:pressKey("@KEY:PF16");','','')
 oCMenu.makeMenu('sub54','top5','Update Language Codes','javascript:pressKey("@KEY:PF17");','','')
 oCMenu.makeMenu('sub55','top5','MANTIS Maintenance','javascript:pressKey("@KEY:PF18");','','')
 oCMenu.makeMenu('sub56','top5','Cluster Locking Facility','javascript:pressKey("@KEY:PF19");','','')
 oCMenu.makeMenu('sub57','top5','List Current Users','javascript:pressKey("@KEY:PF21");','','')
 oCMenu.makeMenu('sub58','top5','Broadcast Message','javascript:pressKey("@KEY:PF23");','','')
 oCMenu.makeMenu('sub59','top5','Statistics Facility','javascript:pressKey("@KEY:PF24");','','')


//This line constructs the menu but don't construct it here, by convention MANTIS constructs it
//oCMenu.construct()

