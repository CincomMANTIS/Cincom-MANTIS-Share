loginButtons = function()
{
submitButtonImages = new Array(5);
submitButtonImagesOver = new Array(5);
agt=navigator.userAgent.toLowerCase();
is_ie = ((agt.indexOf("msie") != -1) && (agt.indexOf("opera") == -1));
changeBtn();

submitButtonImages[1] = new Image();
submitButtonImages[1].src = 'images/Submit.png';
submitButtonImagesOver[1] = new Image();
submitButtonImagesOver[1].src = 'images/SubmitOVER.png';
submitButtonImages[2] = new Image();
submitButtonImages[2].src = 'images/Cancel.png';
submitButtonImagesOver[2] = new Image();
submitButtonImagesOver[2].src = 'images/CancelOVER.png';
submitButtonImages[3] = new Image();
submitButtonImages[3].src = 'images/Reset.png';
submitButtonImagesOver[3] = new Image();
submitButtonImagesOver[3].src = 'images/ResetOVER.png';
}

function showSubmitButton(index)
{
	var obj = null;
	obj = document.getElementById("submitButton" + index);
	if (obj)
	{
		if (is_ie)
			obj.style.filter = "progid:DXImageTransform.Microsoft.AlphaImageLoader(src='" + submitButtonImages[index].src + "', sizingMethod='image')";
		else
			obj.src = submitButtonImages[index].src;
	}
}
	
function showSubmitButtonOver(index)
{
	var obj = null;
	obj = document.getElementById("submitButton" + index);
	if (obj)
	{
		if (is_ie)
			obj.style.filter = "progid:DXImageTransform.Microsoft.AlphaImageLoader(src='" + submitButtonImagesOver[index].src + "', sizingMethod='image')";
		else
			obj.src = submitButtonImagesOver[index].src;
	}
}

function changeBtn()
{
			if (!is_ie)
			{
				var btn = document.getElementById('submitButton1');
				if(btn)
					btn.src = 'images/Submit.png';
				btn = document.getElementById('submitButton2');
				if(btn)
					btn.src = 'images/Cancel.png';
				btn = document.getElementById('submitButton3');
				if(btn)
					btn.src = 'images/Reset.png';
			}
}
