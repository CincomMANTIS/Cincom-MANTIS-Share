/*
 * The MantisWeb Software License, Version 1.0
 *
 *
 * Copyright (c) 2004-2013 Cincom Systems, Inc.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution,
 *    if any, must include the following acknowledgment:
 *       "This product includes software developed by
 *        Cincom Systems, Incorporated (http://www.cincom.com/)."
 *    Alternately, this acknowledgment may appear in the software itself,
 *    if and wherever such third-party acknowledgments normally appear.
 *
 * 4. The names "MANTIS" and "Cincom Systems, Incorporated" must
 *    not be used to endorse or promote products derived from this
 *    software without prior written permission. For written
 *    permission, please contact cincome@cincom.com.
 *
 * 5. Products derived from this software may not be called "Cincom",
 *    nor may "Cincom" appear in their name, without prior written
 *    permission of Cincom Systems, Incorporated.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL CINCOM SYSTEMS, INCOPORATED BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
 * OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
 * OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * =============================================================================
 *
 *
 * mantis.base.js (this file) contains the following functions:
 *     checksubmit()
 *     numeric( myfield, evt, name )
 *     modified( myfield, name )
 *     timeout()
 *     setValue( formObject, mantisName, value )
 *     setCursor( elementName )
 *     setFocus( formField, mantisName )
 *     _dom_trackActiveElement( evt )
 *     _dom_trackActiveElementLost( evt )
 *     setCookie( name, value, days )
 *	   readCookie( name )
 *	   deleteCookie( name )
 *     pressKeyCancel()
 *     pressKey( submitObject, getData )
 *     validate()
 *     setTextAreaLimit( field, maxlen )
 *     Resume()
 *     Start( doLogin )
 *     iosObjcManager 
 */
/*************AJAX METHODS***********************************************************/
//
//This file contains Javascript functions, both public and private, for use
//with Cincom's MantisWeb product.  Customizations of this file should not be
//performed by the customer and are NOT supported by Cincom.  Problems or
//issues with this file should be reported to Cincom's Product Support Center.
//Additions and/or modifications should be placed in mantis.custom.js.
//
//Public functions are denoted by names beginning with M$ and are intended to
//be callable both by Mantis and by custom code.  They make use of the jQuery 
//library.
//List of public functions in this file:
//  M$getMenuLibrary()         - get MenuLibrary from webapp.properties
//  M$getDynamicLess()		   - get DynamicLess from webapp.properties
//  M$getLegacy()		  	   - get Legacy from webapp.properties
//	M$showDynamicLess()		   - alert popup M$getDynamicLess()
//  M$showMenuLibrary()        - alert popup M$getMenuLibrary()
//	M$showLegacy()			   - alert popup M$getLegacy()
//  M$getAjaxBody()            - gets AJAX string from <input> elements
//  M$callAjax()               - makes AJAX call and returns the result
//  M$getFormElements()        - gets elements from form with tagName
//
//Private functions are members of the Mantis global namespace object __M$.
//These functions are considered internal/reserved and should NOT be invoked
//by external custom code.
//List of private functions in this file:
//  __M$.getHTML()                          - helper for pressKey()
//  __M$.getMobileUrl()                     - builds localhost URL
//  __M$.getMobilePort()                    - get MantisServer port
//  __M$.getMobileSoap()                    - key/value pairs -> XML string
//  __M$.convertResponseToHtml()            - XML -> HTML
//  __M$.convertRequestToXml()              - key/value pairs to XML
//  __M$.processElement()                   - helper for convertRequestToXml()
//  __M$.convertToDom()                     - helper for convertRequestToXml()
//  __M$.isNull()                           - check null/empty/spaces 
//  __M$.reportError()                      - alert popup AJAX errors
//  __M$.pageDone()                         - processes AJAX results 
//  __M$.pageDoneNoRefresh()                - do not processes AJAX results
//  __M$.getXmlHttpObject()                 - helper for raw AJAX calls
//  __M$.updatePageTitle()                  - updates MANTIS page title
//  __M$.callAnotherMantis()                - WS-RPC M2M ala WebUtils.java
//  __M$.sendToOriginalMantis()             -   "     "  part 2

// Some shared variables to be used by helper functions.
var __M$ = new Object(); // Mantis global namespace object
__M$.stopListMore   = true;
__M$.usingSelectbox = false;
__M$.usingBckkey    = false;
__M$.BCKKEY      = null;
__M$.SNAME       = 'SEL__';
__M$.MAXROWS     = 0;
__M$.LISTPOSNAME = null;
__M$.xmlHttp = null;
__M$.menuLibrary = "";
__M$.dynamicLess = "";
__M$.legacy = "";
__M$.scrollItemsPerLoad = "";
__M$.menuLibraryRetrieved = false;
__M$.dynamicLessRetrieved = false;
__M$.legacyRetrieved = false;
__M$.scrollItemsPerLoadRetrieved = false;
__M$.myAjax = null;
__M$.COOKIE_ACCESS_ID = 'MantisAccessId';
__M$.MOBILE_PORT = null;
__M$.mobileDevice = 'UNKNOWN';
__M$.userAgent = navigator.userAgent.toLowerCase();
if( __M$.userAgent.indexOf('playbook') != -1 ) __M$.mobileDevice = "PLAYBOOK";
if( __M$.userAgent.indexOf('android' ) != -1 ) __M$.mobileDevice = "ANDROID";
if( __M$.userAgent.indexOf('mac os x') != -1 &&
 __M$.userAgent.indexOf('mobile'  ) != -1 ) __M$.mobileDevice = "IOS";
__M$.isMobile = (__M$.mobileDevice != 'UNKNOWN');
__M$.isMobile &= (window.location.protocol === 'file:');
__M$.ajaxReloadCount = 0;
__M$.manxmlScreenName = null;
// Chrome windows error check
if(navigator.platform == 'Win32'){__M$.isMobile = false;}
if (!__M$.isMobile)__M$.mobileDevice = 'UNKNOWN'
// Code to record the App State (page location)
var appState = 0;
var pathname = window.location.pathname;
if(pathname.indexOf('Start') < 0 && pathname.indexOf('home.html') < 0) {
	var mantURL = document.URL;
	if(location.hash === '' && mantURL.indexOf('#') == -1) {
		setCookie( 'manState', '0' );
	}
	appState = readCookie( 'manState' );
	$(document).ready(location.hash = 'mp'+appState+'s');
}
window.onhashchange = function () {
	var hashState = location.hash.substr(location.hash.indexOf("mp") + 2);
	hashState = hashState.replace('s','');
	if (hashState !== '' && hashState < appState) {
		pressKey('@KEY:CANCEL');
		setCookie( 'manState', appState );
	}
}

/*------------------------------------------------------------------------------
 * checksubmit.js
 */
var submitcount = 0;
var returnval = true;

function checksubmit()
{
	submitcount++;
	if( submitcount == 1 )
	{
	    returnval = true;
	}
	else
	{
		if( submitcount == 2 )
		{
			returnval = false;
		}
		else
		{
			alert( "Please wait, your request is being processed.  " + 
				   "You may need to press 'Enter' to proceed." );
			submitcount = 0;
			returnval = false;
		}
	}
	return returnval;
}


/*------------------------------------------------------------------------------
 * numeric.js
 */
function numeric( myfield, evt, name )
{
	var key;
	var keychar;

	if( window.event )
		key = window.event.keyCode;
	else if( evt )
		key = evt.which;
	else
	{
		myfield.name = name;
		return true;
	}
	keychar = String.fromCharCode( key );
	// control keys
	if( (key == null) || (key == 0)  || (key == 8)  || 
		(key == 9)    || (key == 13) || (key == 27) )
	{
		myfield.name = name;
		return true;
	}
	// numbers
	else if( ("0123456789.+-,").indexOf( keychar ) > -1 )
	{
		myfield.name = name;
		return true;
	}
	else
		return false;
}


/*------------------------------------------------------------------------------
 * modified.js
 */
function modified( myfield, name )
{
    myfield.name = name;
}


/*------------------------------------------------------------------------------
 * timeout.js
 */
var doSubmit = false;

function timeout()
{
	if( __M$.isMobile ) {
		pressKey( 'ENTER' );
	} else {
		window.document.forms[0].submit();
	}
}


/*------------------------------------------------------------------------------
 * setValue.js
 */
function setValue( formObject, mantisName, value )
{
	//Microsoft IE specific code:
	//var sourceObj = document.all.item(formObject);
	//if (sourceObj)
	//  {
	//    sourceObj.name=mantisName;
	//    sourceObj.value=value;
	//    sourceObj.onchange();
	//  }

	//Generic code, works for all browsers (but less efficient):
	var elems = M$getFormElements( 'input', 'select', 'textarea' );
	
	for( var i = 0; i < elems.length; i++ )
	{
		if( (elems[i].name == formObject) || (elems[i].name == mantisName) )
		{
			elems[i].name  = mantisName;
			if ( value != '' ) {
				elems[i].value = value;
			} else {
				if ( elems[i].type != 'select' ) {
					elems[i].value = value;
				}
			}
			if ( (elems[i].options != null) && (value == '') ) {
				value = elems[i].options[0].innerHTML;
				elems[i].options[0].innerHTML = "";
			    for ( var j = 1; j < elems[i].options.length; j++ ) {
			        if ( (elems[i].options[j].value == value) && (elems[i].options[j].innerText != '') ) {
			        	elems[i].options[j].selected = true;
			            j = elems[i].options.length;
			        }
			    }
			}
			if( elems[i].onchange != null )
				modified( this, mantisName );
			i = elems.length;
		}
	}
}


/*------------------------------------------------------------------------------
 * setCursor.js
 * Set the starting point of a cursor.
 */
function setCursor( elementName )
{
	//Generic code, works for all browsers
	var elems = M$getFormElements();
	var all = elems.length;
	if( elementName != null && elementName !='')
	{
		var fieldFound = false;
		var index1 = elementName.indexOf( ',' );
		var index2 = elementName.lastIndexOf( ',' );
		var library = elementName.substring( 0, index1 );
		var page  = elementName.substring( index1 + 1, index2 );
		var field = elementName.substring( index2 + 1, elementName.length );

		for( var i = 0; i < all; i++ )
		{
			if( (elems[i].name == (library + ":" + page + "-" + field)) ||
				(elems[i].name == field) )
			{
				if( ((elems[i].type == "text") || (elems[i].type == "password"))
					&& (elems[i].disabled == false) )
				{
					elems[i].select();
				}
				if( (elems[i].type != "hidden") &&
					(elems[i].disabled == false))
				{
					elems[i].focus();
				}
				fieldFound = true;
				i = all;
			}
		}
		if( ! fieldFound )
		{
			var href = document.getElementById( field );

			if( href != null )
			{
				href.focus();
			} else {
	       		for (var i=0; i<all; i++)
    	   		{
       				if (this.document.forms[i].disabled != true)
       	     		{
       	        		M$getFormElements()[1].focus();
       	         		i=all;
       	    		}
       	  		}
       		}
		}
		elementName = field;
	}
	else
	{
		// always start at 1 because the NAME is always passed as hidden
		for( var i = 1; i < all; i++ ) 
		{
			if( (elems[i].type == "text") || (elems[i].type == "password") )
			{
				elems[i].select();
			}
			//if (((elems[i].isContentEditable) ||
			//     (elems[i].type == "select-one") ||
			//     (elems[i].type == "checkbox")) && elems[i].name != "")
			if( (elems[i].name != "")        && 
				(elems[i].type != "hidden")  && 
				(elems[i].disabled == false) )
			{
				elems[i].focus();
				elementName = elems[i].name;
				i = all;
			}
		}
	}
}
/*
 * setFocus.js
 * Set the mouse focus.
 */
function setFocus( formField, mantisName )
//Generic code, works for all browsers
{
	var active = document.activeElement;
	if( active != null )
	{
		if( (active.type != "submit") && (formField != null) &&
			(formField != '') )
		{
			var target  = document.forms[0].elements[ formField.name ];
			var element = document.forms[0].elements[ "@CUR" ];
			
			if( element != null )
			{
				if( element.type == "hidden" )
				{
					element.value = mantisName;
					if( target != null )
					{
						if( target != active )
						{
							if( target.type == null ) {
								target[0].focus();
							} else {
								target.focus();
							}
						}
					}
				}
			}
		}
	}
}

//Firefox support below for activeElement and DOM compliant browsers
function _dom_trackActiveElement( evt ) 
{
	if( evt && evt.target ) 
	{
		document.activeElement = (evt.target == document) ? null : evt.target;
	}
}

function _dom_trackActiveElementLost( evt )
{
	document.activeElement = null;
} 

//determine if browser will allow events to be added
if( document.addEventListener ) 
{
	document.addEventListener( "focus", _dom_trackActiveElement,     true );
	document.addEventListener( "blur",  _dom_trackActiveElementLost, true );
}

/*------------------------------------------------------------------------------
 * setCookie.js
 */
function setCookie( name, value, days )
{
	if( (__M$.mobileDevice == "ANDROID") &&
			(typeof androidCookieManager != 'undefined') &&
			(androidCookieManager != null) ) {
		androidCookieManager.setCookie( name, value, days );
	} else {
		var expires
		if( days )
		{
			var date = new Date();
			date.setTime( date.getTime() + (days*24*60*60*1000) );
			expires = "; expires=" + date.toGMTString();
		}
		else
			expires = "";
		document.cookie = name + "=" + value + expires + '; path=/';
	}
}


/*------------------------------------------------------------------------------
 * readCookie.js
 */
function readCookie( name )
{
	if( (__M$.mobileDevice == "ANDROID") &&
			(typeof androidCookieManager != 'undefined') &&
			(androidCookieManager != null) ) {
		return androidCookieManager.readCookie( name );
	} else {
		var nameEQ = name + "=";
		var ca = document.cookie.split(';');
	
		for( var i = 0; i < ca.length; i++ )
		{
			var c = ca[i];
			while( c.charAt(0) == ' ' )
				c = c.substring( 1, c.length );
			if( c.indexOf(nameEQ) == 0 )
				return c.substring( nameEQ.length, c.length );
		}
		return null;
	}
}


/*------------------------------------------------------------------------------
 * deleteCookie.js
 */
function deleteCookie( name )
{
	if( (__M$.mobileDevice == "ANDROID") &&
			(typeof androidCookieManager != 'undefined') &&
			(androidCookieManager != null) ) {
		androidCookieManager.deleteCookie( name );
	} else {
		setCookie( name, "", -1 );
	}
}

/*------------------------------------------------------------------------------
 * pressKeyCancel() tries to send Cancel operation even from a bad screen.
 */
function pressKeyCancel()
{
	appState = appState-1;
	setCookie('manState',appState)
	
	// Cancel.html will onload call javascript:pressKeyCancel().
	// pressKeyCancel() will call Java getScreenName().
	// Non-null screenName will cause __M$.getHTML() to send CANCEL.
    if( __M$.mobileDevice == 'ANDROID' ) {
	__M$.manxmlScreenName = androidJavaManager.getScreenName();
    } else if( __M$.mobileDevice == 'IOS' ) {
        __M$.manxmlScreenName = iosObjcManager.getScreenName();
        setCookie( 'M$fromOpenHelp', 'false' );
    }
	pressKey( '@KEY:CANCEL' );
}


/*------------------------------------------------------------------------------
 * pressKey.js
 */
function pressKey( submitObject, getData)
{
	if(submitObject == '@KEY:CANCEL' || submitObject == 'CANCEL' || 
			submitObject == 'Cancel' || submitObject == 'cancel') {
		pathname = window.location.pathname;
	    if(pathname.indexOf('Start') < 0){
	    	appState = readCookie('manState')-1;
	    	location.hash = 'mp'+appState+'s';
	     }  
	} else {
		appState++;
		setCookie('manState',appState);
	}
		
	
	// Special case if listMore() is running then send it a STOP.
	if( ! __M$.stopListMore ) {
		if( __M$.mobileDevice == "ANDROID" )
			androidJavaManager.logCat( 'D', "__M$.pressKey('STOP')" );
		else if( __M$.mobileDevice == "IOS" )
			iosObjcManager.nslog( 'D', "__M$.pressKey('STOP')" );
		// STOP after delay for display thread to complete.
		setTimeout( function(){ __M$.pressKey('STOP'); }, 100 );
		return;
	}

	// Special case if SEL__ then simulate a click on a link.
	var itemNumber = 0;
	$(document).ready( function() {
		// For each <input> element with '-SEL__' in its name attribute.
		var $input = $( 'input[name*=-' + __M$.SNAME + ']' );
		var $inputLength = $input.length;
		for (var i = 0, len = $inputLength; i < len; i++) {
			var $item = $input.eq(i);
			var itemValue = $item.val();
			// If the <input> SEL__nnn element is selected.
			if( itemValue.toUpperCase() == 'S' ) {
				// Only do the first selection
				if( itemNumber == 0 ) {
					// Extract nnn from ...-SEL__nnn.
					var itemName  = $item.attr( 'name'  );
					itemNumber = itemName.substring( itemName.lastIndexOf('__')+2);
				}
			}
		}
	} );

	// When mantis.custom.js specifies values[M$LISTPOSNAME] = 'XXXX',
	// then the screen xsl files must contain 
	//   <span id="manRowNN">...<a href="...">repointname</a>...</span>.
	var repoint = $( '#manRow' + itemNumber ).find( 'a[href]' ).text();
	repoint = repoint.replace( /[^\x20-\x7E]/g, '' );//Remove invisible char
	var missingRepoint = (__M$.LISTPOSNAME != null) && 
	                     (__M$.LISTPOSNAME != ''  ) &&
	                     (repoint == '');

	// Screen using list scrolling must have an entry in mantis.custom.js.
	var missingCustom = (__M$.MAXROWS == null) || (__M$.MAXROWS == 0);

	// SEL__1 (and others) should get normal processing and skip this,
	// others must reposition the server through __M$.pressKey().
	if( ((itemNumber > 1) || ((itemNumber == 1) && ((__M$.BCKKEY != null) || (__M$.TOPKEY != null))))&&
		! __M$.usingSelectbox && ! __M$.fromPopup && ! __M$.usingBckkey && ! __M$.usingTopkey &&
		! missingRepoint && ! missingCustom )
	{
		__M$.pressKey( '@KEY:ENTER', '__' + itemNumber );
			return;
	}

	var element = document.forms[0].elements[ "PRESS_KEY" ];
	//if( element.length > 1 )
	//    alert( 'Error on page!' +
	//        '\nMust be only one element with name="PRESS_KEY"' );
	if( (element != null) && (element.type == "hidden") && checksubmit() )
	{
		if( submitObject.indexOf( "@KEY:" ) == 0 )
			element.name = submitObject;
		else
			element.name = "@KEY:" + submitObject;
		element.value = "aKey";

		// Move #popupFloat input elements back into <form> element.
		if(typeof M$movePopupFloatToForm == 'function')
			M$movePopupFloatToForm();

		// If source page contains <input type="hidden" name="@RELOAD"/>
		// then use submit() to reload all button/link target pages.
		if( ($('input[name="@RELOAD"]').length == 0) ||
			(__M$.isMobile) )
		{
			__M$.getHTML(getData);
		} else {
			// <form onSubmit=""> not run with forms[0].submit()
			// So get the onSubmit attribute value and eval() it.
			var strOnSubmit = '' + $('form').attr('onSubmit');
			if( (strOnSubmit == null) || (strOnSubmit == '') || (strOnSubmit == 'undefined') )
				strOnSubmit = '' + $('form').attr('onsubmit');
			// IE returns "function onsubmit(){...}" for the attr.
			// Others return just the attr value string "...".
			// So make them all the same by adding "function" if needed.
			if( strOnSubmit.indexOf('function') == -1 )
				strOnSubmit = 'function onsubmit(){' + strOnSubmit + '}';
			strOnSubmit += ';onsubmit();';
			eval( strOnSubmit );
			document.forms[0].submit(); // original default behavior
		}
		submitcount = 0;
	}
}


/*------------------------------------------------------------------------------
 * validate.js
 * Provides support for Field Sensitive Validation (FSV). 
 */
function validate()
{
	var element = document.forms[0].elements[ "@VALIDATE" ];

	if( element.type == "hidden" )
	{
		element.value = "Y";
		pressKey( '@KEY:ENTER' );  
	}
}

//  if (top.location != location) {
//    top.location.href = document.location.href ;
//  }




/*------------------------------------------------------------------------------
 * setTextAreaLimit.js
 * Control max length of text input field
 */
function setTextAreaLimit( field, maxlen )
{
	if( field.value.length > maxlen + 1 )
		alert( 'Your input has been truncated to ' + maxlen + ' characters, ' +
			   'the maximum length allowed for this field.' );
	if( field.value.length > maxlen )
		field.value = field.value.substring( 0, maxlen );
}


/*------------------------------------------------------------------------------
 * Resume() implements <form action="Resume" ...> which has been replaced by
 * <form action="javascript:Resume();" ...>
 */
function Resume()
{
	//alert('Resume')
	if( __M$.isMobile && (__M$.mobileDevice != 'IOS') ) {
		;
	} else {
		__M$.getHTML();
	}
}


/*------------------------------------------------------------------------------
 * Start() implements <form action="Start" ...> which has been replaced by
 * <form action="javascript:Start();" ...>
 */
function Start( doLogin )
{
	if( (doLogin == null) || (doLogin == false) ) {
		if( __M$.isMobile ) {
			;
		} else {
			window.location = 'Start';
		}
	} else {
		if( __M$.isMobile ) {
			window.location.href='Start.html';
		} else {
			if( document.forms.length > 0 )
				document.forms[0].submit();
			else
				window.location = 'Start';
		}
	}
}

/*------------------------------------------------------------------------------
 * A global object for managing access to the iOS Objective-C API.
 */
var iosObjcManager = new Object();
iosObjcManager.separator = '::::'; // MUST = MNViewController.m UIWebView separator
iosObjcManager.returnValue = '';
iosObjcManager.callObjc = function( functionName ) {
    iosObjcManager.returnValue = '';
    var iframe = document.createElement( 'IFRAME' );
    iframe.setAttribute( 'src', 'jscall' + iosObjcManager.separator + functionName );
    document.documentElement.appendChild( iframe );
    iframe.parentNode.removeChild( iframe );
    iframe = null;
}
iosObjcManager.setReturnValue = function( returnValue ) {
    iosObjcManager.returnValue = returnValue;
}


iosObjcManager.terminateApp = function() {
    iosObjcManager.callObjc( 'terminateApp' );
    return;
}
iosObjcManager.playAudio = function( audioFilename ) {
    iosObjcManager.callObjc( 'playAudio' + iosObjcManager.separator + audioFilename );
    return;
}
iosObjcManager.getMantisPort = function() {
    iosObjcManager.callObjc( 'getMantisPort' );
    return iosObjcManager.returnValue;
}
iosObjcManager.getScreenName = function() {
    iosObjcManager.callObjc( 'getScreenName' );
    return iosObjcManager.returnValue;
}
iosObjcManager.setDirKey  = function( listKey ) { return iosObjcManager.setListKey(listKey); } 
iosObjcManager.setListKey = function( listKey ) {
    iosObjcManager.callObjc( 'setListKey' + iosObjcManager.separator + listKey );
    return;
}
iosObjcManager.getDirKey  = function() { return iosObjcManager.getListKey(); }
iosObjcManager.getListKey = function() {
    iosObjcManager.callObjc( 'getListKey' );
    return iosObjcManager.returnValue;
}
iosObjcManager.movePrompterFile = function( url ) {
    iosObjcManager.callObjc( 'movePrompterFile' + iosObjcManager.separator + url );
    return iosObjcManager.returnValue;
}
iosObjcManager.xmlToHtml = function( xml ) {
    iosObjcManager.callObjc( 'xmlToHtml' + iosObjcManager.separator + xml );
    return iosObjcManager.returnValue;
}
iosObjcManager.nslog = function( severity, message ) {
    iosObjcManager.callObjc( 'nslog' + iosObjcManager.separator + severity + iosObjcManager.separator + message );
    return;
}
iosObjcManager.getManxml = function() {
    iosObjcManager.callObjc( 'getManxml' );
    return iosObjcManager.returnValue;
}
iosObjcManager.converseXml = function( URLString, xmlSend ) {
    iosObjcManager.callObjc( 'converseXml' + iosObjcManager.separator + URLString + iosObjcManager.separator + xmlSend );
    return iosObjcManager.returnValue;
}
iosObjcManager.getSavedExceptionMessage = function() {
    iosObjcManager.callObjc( 'getSavedExceptionMessage' );
    return iosObjcManager.returnValue;
}


/*------------------------------------------------------------------------------
* public getMenuLibrary()
* Ask the server to read the MenuLibrary value from the webapp.properties file.
*/
function M$getMenuLibrary()
{
	if( __M$.isMobile ) {
		// Hardcoded value for file system (no middleware) access.
		__M$.menuLibrary = 'mantismenu';
		__M$.menuLibraryRetrieved = true;
	}

	if( ! __M$.menuLibraryRetrieved )
	{
		__M$.xmlHttp = __M$.getXmlHttpObject();
		if( __M$.xmlHttp == null )
			return __M$.menuLibrary;

		var url = "Resume";
		url += "?FUNCTION=" + "GetMenuLibrary";
		url += "&sid=" + Math.random();

		__M$.xmlHttp.open( "GET", url, false ); // false -> Synchronous call
		__M$.xmlHttp.send( null );
		// Firefox doesn't call onreadystatechange method for synchronous calls.
		__M$.menuLibrary = __M$.xmlHttp.responseText;
		if( __M$.menuLibrary == null )
			__M$.menuLibrary = "";
		__M$.menuLibrary = __M$.menuLibrary.replace( /^\s+|\s+$/g, '' ); // trim

		__M$.menuLibraryRetrieved = true;
	}
	return __M$.menuLibrary;
}

function M$getDynamicLess()
{
	if( __M$.isMobile ) {
		// Hardcoded value for file system (no middleware) access.
		__M$.dynamicLess = 'no';
		__M$.dynamicLessRetrieved = true;
	}

	if( ! __M$.dynamicLessRetrieved )
	{
		__M$.xmlHttp = __M$.getXmlHttpObject();
		if( __M$.xmlHttp == null )
			return __M$.dynamicLess;

		var url = "Resume";
		url += "?FUNCTION=" + "GetDynamicLess";
		url += "&sid=" + Math.random();

		__M$.xmlHttp.open( "GET", url, false ); // false -> Synchronous call
		__M$.xmlHttp.send( null );
		// Firefox doesn't call onreadystatechange method for synchronous calls.
		__M$.dynamicLess = __M$.xmlHttp.responseText;
		if( __M$.dynamicLess == null )
			__M$.dynamicLess = "";
		__M$.dynamicLess = __M$.dynamicLess.replace( /^\s+|\s+$/g, '' ); // trim

		__M$.dynamicLessRetrieved = true;
	}
	return __M$.dynamicLess;
}

function M$getLegacy()
{
	if( __M$.isMobile ) {
		// Hardcoded value for file system (no middleware) access.
		__M$.legacy = 'no';
		__M$.legacyRetrieved = true;
	}

	if( ! __M$.legacyRetrieved )
	{
		__M$.xmlHttp = __M$.getXmlHttpObject();
		if( __M$.xmlHttp == null )
			return __M$.legacy;

		var url = "Resume";
		url += "?FUNCTION=" + "GetLegacy";
		url += "&sid=" + Math.random();

		__M$.xmlHttp.open( "GET", url, false ); // false -> Synchronous call
		__M$.xmlHttp.send( null );
		// Firefox doesn't call onreadystatechange method for synchronous calls.
		__M$.legacy = __M$.xmlHttp.responseText;
		if( __M$.legacy == null )
			__M$.legacy = "";
		__M$.legacy = __M$.legacy.replace( /^\s+|\s+$/g, '' ); // trim

		__M$.legacyRetrieved = true;
	}
	return __M$.legacy;
}

/*------------------------------------------------------------------------------
 * public M$showMenuLibrary()
 * Show the currently selected menu library.
 */
function M$showMenuLibrary()
{
	alert( "The current MenuLibrary value in webapp.properties file is '" +
			M$getMenuLibrary() + "'" );
}

function M$showDynamicLess()
{
	alert( "The current DynamicLess value in webapp.properties file is '" +
			M$getDynamicLess() + "'" );
}

function M$showLegacy()
{
	alert( "The current Legacy value in webapp.properties file is '" +
			M$getLegacy() + "'" );
}

//Mobile apps need to auto signon and run their respective program. That can be
//specified either here or in the MASTER:SIGN_ON program. If done here then
//take care to only specify it in the app's private mantis.custom.js file.
//For example:
//M$mobileName      = 'EXAMPLES';
//M$mobileClearance = 'CASINO';
//M$mobileParameter = 'BUZZ_PHRASES';
function getMobileSignon()
{
	M$mobileName      = 'EXAMPLES';
	M$mobileClearance = 'CASINO';
	M$mobileParameter = '';
}

/*------------------------------------------------------------------------------
 * private getHTML()
 * Helper function for pressKey() when an AJAX library is selected.
 */
__M$.getHTML = function(getData)
{
	var body;
	var url;
	// Build parm/value key pairs for post body with parameters from DOM
	var parms = M$getFormElements( 'input', 'select', 'textarea' );
	var nodes;
	nodes = jQuery.makeArray( parms );
	body = "";
	for( var i = 0; i < nodes.length; i++ )
	{
		var nodeName = nodes[i].name;
		if( nodeName != "" )
		{
			var nodeValue = nodes[i].value;

			// Some chars interfere with later parsing.
			nodeValue = nodeValue.replace(  /%/g, "%25" )// % before next lines
								 .replace(  /&/g, "%26" )
								 .replace(  /=/g, "%3D" )
								 .replace( /\+/g, "%2B" );

			if( body.length != 0 )
				body += '&';
			body += nodeName + '=' + nodeValue;
		}
	}
	
	// Build url for AJAX call.
	// This should come after build nodes.
	if( __M$.isMobile ) {
		var accessId;
		if( nodes.length > 1 ) {
			accessId = readCookie( __M$.COOKIE_ACCESS_ID );
			if( (accessId == null) || (accessId == '') )
				accessId = '0';
		} else {
			deleteCookie( __M$.COOKIE_ACCESS_ID );
			accessId = '0';
		}
		url  = 'http://localhost:' + __M$.getMobilePort() + '/MantisServer';
		url += '?ACCESS=' + accessId;
		url += '&HOST=127.0.0.1&USER=null&PASSWORD=null';
	} else {
		url = 'Resume';
	}

	if( __M$.isMobile ) {
		// Build XML body including attribute MOBILE="..."
		if( nodes.length <= 1 ) {
			// XML start page at startup of the mobile app.
			if( __M$.manxmlScreenName == null ) {
				body =
					'<ns1:FORMDATA NAME="CONTROL-XMLSTART" MOBILE="' + __M$.mobileDevice + '"\n' + 
					'                  xmlns:ns1="http://appdev.cincom.com/MantisServer">\n' +
					'      <CONTROL-XMLSTART>\n';
				if( (typeof M$mobileName == 'undefined') || (M$mobileName === '') )
					getMobileSignon();
				if( M$mobileName != '' )
					body += '<NAME>' + M$mobileName + '</NAME>\n';
				if( M$mobileClearance != '' )
					body += '<CLEARANCE>' + M$mobileClearance +'</CLEARANCE>\n';
				if( M$mobileParameter != '' )
					body += '<PARAMETER>' + M$mobileParameter +'</PARAMETER>\n';
		        body += '      </CONTROL-XMLSTART>';
			} else {
				// Cancel.html will onload call javascript:pressKeyCancel().
				// pressKeyCancel() will call Java getScreenName().
				// Non-null screenName will cause __M$.getHTML() to send CANCEL.
				body =
					'<ns1:FORMDATA NAME="' + __M$.manxmlScreenName + '" MOBILE="' + __M$.mobileDevice + '"\n' + 
					'                  xmlns:ns1="http://appdev.cincom.com/MantisServer">\n' +
					'      <CONTROL-RESERVED_INFO>\n' +
					'        <KEYSIM PRO="N">CANCEL</KEYSIM>\n' +
					'      </CONTROL-RESERVED_INFO>';
				__M$.manxmlScreenName = null;
			}
			body +=	'</ns1:FORMDATA>\n';
		} else {
			// Key/value pairs -> XML Document -> XML string
			var xmldoc = __M$.convertRequestToXml( body );
			xmldoc.documentElement.setAttribute( 'MOBILE', __M$.mobileDevice );
			try {
				body = (new XMLSerializer()).serializeToString( xmldoc );
			} catch( ex ) {
				body = xmldoc.xml; // IE technique
			}

			// Restore original chars. Necessary for Program Design editor.
			body = body.replace( /%2B/g, "+" )
					   .replace( /%3D/g, "=" )
					   .replace( /%26/g, "&" )
					   .replace( /%25/g, "%" );// % after prev lines
		}
		body = body.replace( /></g, '>\n    <' );
		if( body.substring(body.length - 1) != '\n' )
			body += '\n';
		
		// Wrap the XML string in a SOAP envelope.
		body =
			'<?xml version="1.0" encoding="UTF-8"?>\n' +
			'<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"\n' +
			'                  xmlns:xsd="http://www.w3.org/2001/XMLSchema"\n' +
			'                  xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">\n' +
			'  <soapenv:Body>\n' +
			'    ' + body +
			'  </soapenv:Body>\n' +
			'</soapenv:Envelope>\n';
	}

	// This should come after get parms from the screen form, and before the 
	// AJAX call gets a new screen.
	if(typeof M$closePopupFloat == 'function')
		M$closePopupFloat();
	// Make the AJAX call using body and url built above.
		var datatype;
		if( __M$.isMobile )
			datatype = 'text';
		else
			datatype = 'html';
		__M$.ajaxReloadCount = 0;
		if(getData=='noRefresh') {
			loadAnime('start');
			__M$.myAjax = jQuery.ajax(
					{
						url:      url,
						type:     "POST",
						async:    true,
						data:     body,
						error:    __M$.reportError,
						success:  __M$.pageDoneNoRefresh,
						dataType: datatype
					} );
			getData = '';
		} else {
			loadAnime('start');
			__M$.myAjax = jQuery.ajax(
					{
						url:      url,
						type:     "POST",
						async:    true,
						data:     body,
						error:    __M$.reportError,
						success:  __M$.pageDone,
						dataType: datatype
					} );
		}
};

/*------------------------------------------------------------------------------
 * private getMobileUrl()
 * Mobile devices like Android will be using a Mantis server on the same device
 * and not a URL from webapp.properties.
 */
__M$.getMobileUrl = function()
{
	var accessId;
	accessId = readCookie( __M$.COOKIE_ACCESS_ID );
	if( (accessId == null) || (accessId == '') )
		accessId = '0';
	var url = 'http://localhost:' + __M$.getMobilePort() + '/MantisServer';
	url += '?ACCESS=' + accessId;
	url += '&HOST=127.0.0.1&USER=null&PASSWORD=null';
	return url;
};


/*------------------------------------------------------------------------------
 * private getMobilePort()
 */
__M$.getMobilePort = function()
{
	if( __M$.MOBILE_PORT == null ) {
		if( (__M$.mobileDevice == "ANDROID") &&
            (typeof androidJavaManager != 'undefined') &&
            (androidJavaManager != null) ) {
			__M$.MOBILE_PORT = androidJavaManager.getMantisPort();
        } else if( __M$.mobileDevice == "IOS" ) {
            __M$.MOBILE_PORT = iosObjcManager.getMantisPort();
		} else {
			__M$.MOBILE_PORT = 8091;
		}
	}
	return __M$.MOBILE_PORT;
};


/*------------------------------------------------------------------------------
 * private getMobileSoap()
 */
__M$.getMobileSoap = function( body )
{
	// Build XML body including attribute MOBILE="..."
	// Key/value pairs -> XML Document -> XML string
	var xmldoc = __M$.convertRequestToXml( body );
	xmldoc.documentElement.setAttribute( 'MOBILE', __M$.mobileDevice );
	xmldoc.documentElement.setAttribute( 'XMLCONTENT', 'FULL' );
	var xmlstr;
	try {
		xmlstr = (new XMLSerializer()).serializeToString( xmldoc );
	} catch( ex ) {
		xmlstr = xmldoc.xml; // IE technique
	}
	xmlstr = xmlstr.replace( /></g, '>\n    <' );
	if( xmlstr.substring(xmlstr.length - 1) != '\n' )
		xmlstr += '\n';

	// Wrap the XML string in a SOAP envelope.
	var soap =
		'<?xml version="1.0" encoding="UTF-8"?>\n' +
		'<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"\n' +
		'                  xmlns:xsd="http://www.w3.org/2001/XMLSchema"\n' +
		'                  xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">\n' +
		'  <soapenv:Body>\n' +
		'    ' + xmlstr +
		'  </soapenv:Body>\n' +
		'</soapenv:Envelope>\n';

	return soap;
};


/*------------------------------------------------------------------------------
 * private convertResponseToHtml()
 */
__M$.convertResponseToHtml = function( data )
{
	var html;

	if( (__M$.mobileDevice == "ANDROID") &&
			(typeof androidJavaManager != 'undefined') &&
			(androidJavaManager != null) ) {
		html = androidJavaManager.xmlToHtml( data );
    } else if( __M$.mobileDevice == "IOS" ) {
//		html = iosObjcManager.xmlToHtml( data );
        var xmldom = new DOMParser().parseFromString( data, "text/xml" );

        var xslnamestart = data.indexOf( 'href="' ) + 6;
        var xslnameend   = data.indexOf( '"', xslnamestart );
        var xslname = data.substring( xslnamestart, xslnameend );
        var xhttp = new XMLHttpRequest();
        xhttp.open( "GET", xslname, false );
        xhttp.send( "" );
        var xsldom = xhttp.responseXML;

        var processor = new XSLTProcessor();
        processor.importStylesheet( xsldom );
        html = processor.transformToDocument( xmldom );
	} else {
		if( window.ActiveXObject ) {
			var xmldom = new ActiveXObject( "Microsoft.XMLDOM" );
			html = xmldom.transformNode( data );
		} else {
			var xmldom = new DOMParser().parseFromString( data, "text/xml" );

			var xslnamestart = data.indexOf( 'href="' ) + 6;
			var xslnameend   = data.indexOf( '"', xslnamestart );
			var xslname = data.substring( xslnamestart, xslnameend );
			var xsldom  = document.implementation.createDocument( "","",null );
			xsldom.load( xslname ); // undefined on Android!

			var processor = new XSLTProcessor();
			processor.importStylesheet( xsldom );
			html = processor.transformToDocument( xmldom );
		}
	}

	return html;
};

/*------------------------------------------------------------------------------
 * private convertRequestToXml()
 * Convert key/value pairs to XML. This is a two-step process.
 * First, we create nested hashtables to hold the values of the xml elements.
 * This allows us to assign attributes belonging to the same element to
 * the same hashtable.
 * Second, we create a DOM document from all the nested hashtables.
 * See middleware file XmlRequest.java method convertRequestToXml().
 */
__M$.convertRequestToXml = function( keyValuePairs )
{
	// Root ht will contain 'FORMDATA' root element whose value is a ht 
	// representing its children.
	var hXml = new Array();

	// Create a new DOM document for the final XML
	var nsuri = "http://appdev.cincom.com/MantisServer";
	var xmldoc = null;
	if( document.implementation && document.implementation.createDocument ) {
		xmldoc = document.implementation.createDocument( nsuri, "ns1:FORMDATA", null );
	} else if( window.ActiveXObject ) {
		xmldoc = new ActiveXObject( "Microsoft.XMLDOM" );
		xmldoc.documentElement = xmldoc.createElement( "ns1:FORMDATA" );
	} else {
		alert( "Browser cannot create new DOM document!" );
	}
	var docelem = xmldoc.documentElement;
	docelem.setAttribute( "xmlns:ns1", nsuri );

	// Enumerate through all request parameters (form members)
	var enum1 = keyValuePairs.split( '&' );
	for( var i = 0; i < enum1.length; i++ )
	{
		var enum2 = enum1[i].split( '=' );
		var paramName  = enum2[0];
		var paramValue = enum2[1];
		var elemName   = paramName;
		if( paramName.indexOf('@') == -1 )
			elemName = paramName + "-PCDATA";
		if( (paramName.indexOf(':')  > 0) ||
		    (paramName.indexOf('@') == 0) ||
		    (paramName.indexOf('_') == 0) )
		{
			__M$.processElement( hXml, elemName, paramValue );
		}
	}

	var hXmlLength = 0;
	for( i in hXml )
		hXmlLength++;
	if( hXmlLength > 0 )
	{
		__M$.convertToDom( enum1, hXml, docelem, xmldoc );
		var nodeCount = docelem.getElementsByTagName('*').length;
		if( nodeCount == 0 )
		{
			var txt = xmldoc.createTextNode( "NODATA" );
			docelem.appendChild( txt );
		}
	}

	return xmldoc;
};


/*------------------------------------------------------------------------------
 * private processElement()
 * Helper function for __M$.convertRequestToXml().
 * Recursive function that pulls each element name from the form's parameter 
 * name. It builds a recursive hashtable (hashtable within another hashtable)
 * that represents the elements and maintains their hierarchy and values.
 */
__M$.processElement = function( hash, key, value )
{
	var elemName = null;
	var index = key.indexOf( '-' );
	if( index > -1 ) {
		// There are more '-', so we need to recurse more
		elemName = key.substring( 0, index );

		// Convert all numbers to 3 digits so that 002 comes before 010,
		// otherwise 2 comes AFTER 10.
		var l = parseInt( elemName );
		if( ! isNaN(l) )
			elemName = ('00' + l.toString()).slice(-3);

		var loc = elemName.indexOf( ':' );
		if( (loc > -1)  && (loc < 17) )
			elemName = elemName.replace( ':', '-' );

		if( hash[elemName] != undefined ) {
			// We already have a element of this elemName, so we will add to it
			__M$.processElement( hash[elemName], key.substring(index+1), value);
		} else {
			// This is a new element, so we need to create a ht to hold its 
			// children/attrs.
			var newHash = new Array();
			__M$.processElement( newHash, key.substring(index+1), value );
			hash[elemName] = newHash;
		}
	} else {
		// No more '-' characters
		// We have the name of an element/attribute to associate with its
		// value, therefore store in ht and return.
		hash[key] = value;
	}
};

/*------------------------------------------------------------------------------
 * private convertToDom()
 * Helper function for __M$.convertRequestToXml().
 * Convert our nested hashtables to a DOM document. This is a recursive function
 * that will process one hashtable at a time, then call itself to process any
 * hashtables in the current hashtable.
 */
__M$.convertToDom = function( req, hash, xmlelem, xmldoc )
{
	var b_keySet = false;
	var vElems = new Array();
	var htIndexReference = new Array();

	// Convert all keys to a vector, so that they can be sorted. Therefore any
	// integer keys will be sorted in order allowing us to specify some 
	// sequence to items on the web page.
	for( var elemName in hash ) {
		var lElemName = parseInt( elemName );
		if( isNaN(lElemName) ) {
			// Not a number - put it in the hashtable as itself, that way we can
			// always pull from the hashtable.
			htIndexReference[elemName] = elemName;
		} else {
			// OK, so you thought you understood that elements numerically named
			// indicated the sequence...now we get to
			// change that. What we will do is for every piece of content (form
			// elements named FORMDATA_1_Content_<whatever>),
			// we will have an element to indicate its index, named
			// Content_Index_1. The '1's need to match between the index
			// and the piece of content. The value of this new field is the
			// index that we will sort upon. Got it?
			var sIndex = null;
			for( var j in req ) {
				var reqSplit = req[j].split( '=' );
				if( reqSplit[0] == "Content_Index_" + lElemName.toString() )
					sIndex = reqSplit[1];
			}
			sIndex = req.getParameter( "Content_Index_" + lElemName.toString());
			if( sIndex != null ) {
				var lIndex = parseInt( sIndex );
				if( isNaN(lIndex) ) {
					htIndexReference[elemName] = elemName;
				} else {
					sIndex = ('00' + lIndex.toString()).slice(-3);
					htIndexReference[sIndex] = elemName;
					// We want the index to be added to the vector, so that the
					// vector sorts indexes, not element names.
					elemName = sIndex;
				}
			} else {
				htIndexReference[elemName] = elemName;
			}
		}

		if( elemName != null )
			vElems.push( elemName );
	}
	vElems.sort();

	// Process all keys from hashtable that are now ordered in our vector.
	for( var i in vElems ) {
		var paramName = htIndexReference[vElems[i]];
		// Any key beginning with '@' is an attribute
		if( paramName.indexOf('@') == 0 ) {
			// Attribute
			// Don't keep null (empty) attributes
			if( ! __M$.isNull( hash[paramName] ) ) {
				if( paramName.indexOf('@KEY:') == 0 ) {
					var iColon = paramName.lastIndexOf( ':' );
					// See if KEY value contains a '.' added by HTML
					// Images
					var iPeriod = paramName.indexOf( '.', iColon );
					if( iPeriod > iColon ) {
						xmlelem.setAttribute( "KEY", paramName.substring(iColon + 1, iPeriod) );
					} else {
						xmlelem.setAttribute( "KEY", paramName.substring(iColon + 1) );
					}
					b_keySet = true;
				} else {
					xmlelem.setAttribute( paramName.substring(1), hash[paramName] );
				}
			}
		} else {
			// Child element
			var uParamName;
			var charCodeAt0 = paramName.charCodeAt( 0 );
			if( (charCodeAt0 >= '0'.charCodeAt(0)) && 
				(charCodeAt0 <= '9'.charCodeAt(0))  ) {
				// This code is to handle MANTIS User names that begin with
				// numeric values!
				// XML does not allow nodes to begin with numeric values, so we
				// prefix with 'u' when MANTIS User name begins with numerics.
	        	uParamName = "u" + paramName;
	        } else {
	        	uParamName = null;
	        }
			// If this is a numeric key, ignore it and pass the current
			// element instead of creating a new element for this key. 
			// This is what allows us to sequence items from the webpage.
			var intParamName = parseInt( paramName );
			if( ! isNaN( intParamName ) ) {
				if( intParamName > 0 )
					__M$.convertToDom( req, hash[paramName], xmlelem, xmldoc );
			} else {
				// This key is not numeric, therefore create a new element for
				// it. PCDATA is the text data for an element.
				if( 'PCDATA' == paramName ) {
					var text = xmldoc.createTextNode( hash[paramName] );
					// Don't keep null (empty) text fields
					xmlelem.appendChild( text );
				} else {
					// Since 'FORMDATA' is the root element, we do not need to
					// create a new element for it.
					if( paramName == "ns1:FORMDATA" ) {
						__M$.convertToDom( req, hash[paramName], xmlelem, xmldoc );
					} else {
						// Create a new element and process its children/attrs
						var newElement;
						if( uParamName == null ) {
							newElement = xmldoc.createElement( paramName );
						} else {
							newElement = xmldoc.createElement( uParamName );
						}
						__M$.convertToDom( req, hash[paramName], newElement, xmldoc );
						// Do not keep empty elements
						if( (newElement.attributes.length > 0) || 
							(newElement.childNodes.length > 0) )
							xmlelem.appendChild( newElement );
					}
				} // endif
			} // endif
		} // endif
	} // for
	if( ! b_keySet ) {
		// No KEY= value set, assume a timeout occurred, set
		// 'TIMOUT' as KEY value.
		if( xmlelem.tagName == "ns1:FORMDATA" )
			xmlelem.setAttribute( 'KEY', 'TIMOUT' );
	}
};


/*------------------------------------------------------------------------------
 * Check for null in the string passed in. this includes empty string("") and 
 * strings of all spaces.
 */
__M$.isNull = function( paramName )
{
	if( (paramName == null) || 
		(paramName == '')   || 
		(paramName.replace(' ','\0') == '') )
	{
		return true;
	} else {
		return false;
	}
};

/*------------------------------------------------------------------------------
 * private reportError()
 * Asynchronous function for AJAX call when an error occurs.
 */
__M$.reportError = function( request, textStatus, errorThrown )
{
	loadAnime('stop');
	var message = 'Sorry, there was an AJAX error. - ';

	if( (request.statusText != null) && (request.statusText != '') )
		message += request.statusText;
	if( request.status != null )
		message += ' (status=' + request.status.toString() + ')';
	if( (request.responseText != null) && (request.responseText != '') )
		message += '\n' + request.responseText;

	if( (textStatus != null) && (textStatus != '') )
		message += '\n' + textStatus;

	if( (errorThrown != null) && (errorThrown != '') )
		message += '\n' + errorThrown;

	if( (request.status != null) && (request.status == 0) && __M$.isMobile ) {
        alert( message + '\n\n' +
              'An unrecoverable fatal error has occurred\n' +
              'and this app must now terminate.' );
		if( __M$.mobileDevice == "ANDROID" ) {
            androidJavaManager.logCat( 'D', 'Javascript ' + (new Error()).stack );
            androidJavaManager.terminateApp();
        } else if( __M$.mobileDevice == "IOS" ) {
            iosObjcManager.nslog( 'D', 'Javascript ' + (new Error()).stack );
            iosObjcManager.terminateApp();
        }
	} else {
		alert( message );
	}
};


/*------------------------------------------------------------------------------
 * private pageDone()
 * Asynchronous function for AJAX call when it completes.
 */
__M$.pageDone = function( data, textStatus )
{
	var pathname = window.location.pathname;
	if(appState<0) {
		appState=0;
		setCookie('manState', appState);
	}
    if(pathname.indexOf('Start') < 0) 
    	location.hash = 'mp'+appState+'s';
	
	loadAnime('stop');
	
	var newHtml     = "";
	//var menuLibrary = M$getMenuLibrary();

	// If ajax() dataType='xml' then convert the returned DOM to XML text.
	if( typeof data == 'object' )
		data = data.xml;
	// If the returned page is empty then there is no point to attempting
	// any further processing.
	if( (data == null) || (data == '') ) {
		if( __M$.ajaxReloadCount <= 10 ) {
			__M$.ajaxReloadCount++;
			window.location.reload();
		} else {
			var message = 'AJAX page done but no data returned!';
			if( (textStatus != null) && (textStatus != '') )
				message += '\nStatus = ' + textStatus;
			alert( message );
		}
		return false;
	}
	newHtml = data;
	
	// This is to prevent blank lines and nulls at the start
	// Creates an array in order to remove the first line
	if(newHtml.charAt(0) != '<') {
		var dataLines = data.split('\n');
		dataLines.splice(0,1);
		var data = dataLines.join('\n');
	}
	
	// replace the `HTML` tags with `NOTHTML` tags
    // and the `BODY` tags with `NOTBODY` tags
	
	if( __M$.isMobile ) {
		data = data.replace(/(<\/?)html( .+?)?>/gi,'$1NOTHTML$2>',data);
		data = data.replace(/(<\/?)body/gi,'$1NOTBODY',data);
		var newBody = $(data).find('NOTBODY').html();
	} else {
		data = data.match(/<body\s*[^>]*>([\S\s]*?)<\/body>/m)[1];
		var newBody = data;
	}
    
	var $data = $( data );
	
	var loadNewPage = function() {
		
		if( __M$.isMobile ) {
			// Look for the access id number nnnn in the HTTP status.
			//     (statusText looks like "OK ACCESS=nnnn")
			// If not found then look in XML element FORMDATA.
			//     (<ns1:FORMDATA ACCESS="nnnn"...>...</ns1:FORMDATA>)
			var accessId = null;
			var index = __M$.myAjax.statusText.indexOf( 'ACCESS=' );
			if( index != -1 ) {
				accessId = __M$.myAjax.statusText.substring( index + 7 );
			} else {
				// Sometimes $data.find('ns1:FORMDATA') fails with and w/o
				// the "ns1:".  But we can always find the ACCESS attribute
				// and then compare its elements tag name.
				var $dataAccess = $data.find('[ACCESS]');
				var $dataAccessLength = $dataAccess.length;
				for (var i = 0, len = $dataAccessLength; i < len; i++) {
					if( (this.tagName.toLowerCase() == 'ns1:formdata') ||
						(this.tagName.toLowerCase() == 'formdata')     )
						accessId = $dataAccess.eq(i).attr('ACCESS');
				}
			}
			// Save access ID number in a cookie for next AJAX call to use.
			if( (accessId != null) && (accessId != '') )
				setCookie( __M$.COOKIE_ACCESS_ID, accessId, 1 );
			else
				deleteCookie( __M$.COOKIE_ACCESS_ID );

			// Get the new screen name. Special actions for XMLSHUTDOWN and
			// XMLSTART.
			var screenName = $data.find('[NAME]').attr('NAME');
			if( screenName.indexOf('CONTROL-XMLSHUTDOWN') != -1 )
				deleteCookie( __M$.COOKIE_ACCESS_ID );
			if( screenName.indexOf('CONTROL-XMLSTART') == 0 ) {
				if( __M$.mobileDevice == "ANDROID" )
					androidJavaManager.logCat('D','Calling another MANTIS');
                if( __M$.mobileDevice == "IOS" )
                    iosObjcManager.nslog('D','Calling another MANTIS');
				var receiverData = __M$.callAnotherMantis( data );
				__M$.sendToOriginalMantis( receiverData );
			}

			// Get the XML filename from FILE attribute (or use screenName)
			// and load the XML file as the next web page.
			var fileName = $data.find('[FILE]').attr('FILE');
			if( (fileName == null) || (fileName == '') )
				fileName = screenName + '.xml';
			window.location.href = fileName;
		} else {
			var manBody = $( 'body' )[0];
			if( manBody != null ) {
				if( (newBody == null) || (newBody == '') )
					alert( 'Missing <body>' );
				else
					$('body').html(newBody)
			}
		}

		// blaw Jul'11 Find a <script> element within the <body> of the 
		// newHtml and if it does not contain 'document.write' then execute 
		// it.  Note eval('document.write') creates new blank document.
		var scriptFilename = $( 'body' ).find('script').attr( 'src' );
		if( (scriptFilename != null) && (scriptFilename.length > 0) ) {
			jQuery.get( scriptFilename, function( scriptContents ) {
				if( (scriptContents != null)    && 
					(scriptContents.length > 0) &&
					(scriptContents.indexOf('document.write') == -1) ) {
					eval( scriptContents );
		} } ); }
	};
    if( __M$.mobileDevice == "IOS" )
        loadNewPage();
    else
        $(document).ready( loadNewPage );

	// Run the new screen page onload scripts.
	
	var onLoadIndexStart = newHtml.indexOf( 'onLoad="' );
	if( onLoadIndexStart == -1 )
		onLoadIndexStart = newHtml.indexOf( 'onload="' );
	if( onLoadIndexStart != -1 )
	{
		onLoadIndexStart += 8;
		var onLoadIndexEnd = newHtml.indexOf( '"', onLoadIndexStart );
		var strOnLoad = newHtml.substring( onLoadIndexStart, onLoadIndexEnd );
		eval( strOnLoad ); // This code will set cursor location
	}
	
	// Add a mouseover popup to all <input> fields on the new screen page.
	// blaw Nov'13 Note on iOS this causes <input> elements to require two taps.
    if( ! __M$.isMobile && typeof M$addInputMouseover == 'function' && __M$.mobileDevice == 'UNKNOWN')
    	M$addInputMouseover();
	// Update the page title since AJAX didn't.
	__M$.updatePageTitle();

	// Open popup dialog, if any on the page.
	if(typeof M$openPopupFloat == 'function')
		M$openPopupFloat();

	// Add a mouseover popup to all photo & music links on the new screen page.
	if( ! __M$.isMobile && __M$.mobileDevice == 'UNKNOWN')
		if(typeof M$addPhotoMouseover == 'function')
			M$addPhotoMouseover();
	
};


/*------------------------------------------------------------------------------
 * private pageDoneNoRefresh()
 * Function which ignores message from AJAX call when it completes.
 */
__M$.pageDoneNoRefresh = function( data, textStatus )
{
	loadAnime('stop');
	var $data = $( data );
	//check for faults/errors
	if ($( 'title', $data ).html() == 'MANTIS Fault') {
		__M$.pageDone(data,textStatus);
	} else if ($('#mantisMsg', $data ).html() == 'mantisRefresh&nbsp;') {
		__M$.pageDone(data,textStatus);
		$('#mantisMsg').html('');
	} else {
		$('input[value="aKey"]').attr('name','PRESS_KEY');
	}
};


/*------------------------------------------------------------------------------
 * private getXmlHttpObject()
 * Helper function for AJAX functions needing an XML HTTP object.
 */
__M$.getXmlHttpObject = function()
{
	var xmlHttp = null;
	try {
		// Firefox, Opera 8.0+, Safari
		xmlHttp = new XMLHttpRequest();
	} catch( ex1 ) {
		// Internet Explorer
		try {
			xmlHttp = new ActiveXObject( "Msxml2.XMLHTTP" );
		} catch( ex2 ) {
			try {
				xmlHttp = new ActiveXObject( "Microsoft.XMLHTTP" );
			} catch( ex3 ) {
				alert( "Your browser does not support AJAX!" );
	}	}	}
	return xmlHttp;
};

/*------------------------------------------------------------------------------
 * private updatePageTitle()
 * Update the page title from the contents.
 */
__M$.updatePageTitle = function()
{
	$(document).ready( function() {
		var name = $( 'input[name="@NAME"]' ).attr( 'value' );
		var title = 'MANTIS ' + name;
		document.title = title;
	} );
};

/*------------------------------------------------------------------------------
 * public getAjaxBody()
 * Get the AJAX data string from the screen <input> elements.
 */
function M$getAjaxBody( $screen )
{

	var $inputs;
	if( $screen != null )
		$inputs = $( 'input', $screen );
	else
		$inputs = $( 'input' );
	var ajaxBody = "";
	var $inputLength = $inputs.length;
	for (var i = 0, len = $inputLength; i < len; i++) {
		var $node = $inputs.eq(i);
		if( $node.attr('name') != "" ) {
			if( ajaxBody != "" )
				ajaxBody += "&";
			ajaxBody += $node.attr('name') + "=" + $node.attr('value');
		}
	}
	return ajaxBody;
}


/*------------------------------------------------------------------------------
 * public callAjax()
 * Do the jQuery.ajax() call.
 */
function M$callAjax( ajaxBody )
{
	var newScreen = null;
	var url;
	var data;
	if( __M$.isMobile ) {
		url  = __M$.getMobileUrl();
		data = __M$.getMobileSoap( ajaxBody );
	} else {
		url  = "Resume";
		data = ajaxBody;
	}
	jQuery.ajax( {
		url:      url,
		type:     "POST",
		async:    false,
		data:     data,
		dataType: "html",
		success:  function( data ) {
			if( __M$.isMobile )
				newScreen = __M$.convertResponseToHtml( data );
			else
				newScreen = data;
		},
		error: function(data) {
			loadAnime('stop');
			__M$.reportError
		}
	} );
	return newScreen;
}

/*------------------------------------------------------------------------------
 * public getFormElements()
 * Get all elements from the document form with the specified tagName.
 * 
 * Note forms[0].elements does not return elements marked as unselectable and
 * jQuery UI dialog widget surrounds its div with a new unselectable div.  Thus
 * there are 2 major ways to call this function: with and without a tagName arg.
 * 
 * Usage:
 *   var x = M$getFormElements();
 *   var x = M$getFormElements( 'input' );
 *   var x = M$getFormElements( '????' ); // where ???? is some other tag name
 */
function M$getFormElements( tagName1, tagName2, tagName3 )
{
	var elements1, elements2, elements3;
	var elements = new Array();

	if( tagName1 == null ) {
		elements1 = document.forms[0].elements;
	} else {
		elements1 = document.getElementsByTagName( tagName1 );
	}
	for( var i = 0; i < elements1.length; i++ ) {
		elements[i] = elements1[i];
	}

	if( tagName2 != null ) {
		elements2 = document.getElementsByTagName( tagName2 );
		var len = elements.length;
		for( var i = 0; i < elements2.length; i++ ) {
			elements[len+i] = elements2[i];
		}
	}

	if( tagName3 != null ) {
		elements3 = document.getElementsByTagName( tagName3 );
		var len = elements.length;
		for( var i = 0; i < elements3.length; i++ ) {
			elements[len+i] = elements3[i];
		}
	}

	return elements;
}

/*------------------------------------------------------------------------------
 * private callAnotherMantis()
 * Helper function for pageDone() when doing M2M.
 * Parse out the URLString and forward the data to it.
 */
__M$.callAnotherMantis = function( data )
{
	var xmlstr = data;
	var receiverData = null;

	// Parse out the URLString from the XML element <URL>.
	var URLString = $(xmlstr).find( 'URL' ).text();
	if( (URLString == null) || (URLString == '') ) {
		if( __M$.isMobile ) {
			// Read all of the XML data from file man00000000.xml.
            if( __M$.mobileDevice == "ANDROID" )
                xmlstr = androidJavaManager.getManxml();
            else if( __M$.mobileDevice == "IOS" )
                xmlstr = iosObjcManager.getManxml();
			URLString = $(xmlstr).find( 'URL' ).text();
		}
	}
	if( (URLString == null) || (URLString == '') ) {
		alert( 'Missing <URL> element in data:\n' + xmlstr );
		return null;
	}
	if( __M$.mobileDevice == "ANDROID" )
		androidJavaManager.logCat( 'D', '...URLString="' + URLString + '"' );
	if( __M$.mobileDevice == "IOS" )
		iosObjcManager.nslog( 'D', '...URLString="' + URLString + '"' );

	// Pass the XML data to the URL specified in URLString.
	// Note that going to another site or a different protocol (e.g. file:// vs
	// http://) is forbidden in Javascript by the browser security. The result
	// is NETWORK_ERR: XMLHttpRequest exception 101.
	// In Android we'll call Java to do it.
	// In iOS we'll call Objective-C to do it.
	if( __M$.isMobile ) {
		// Add SOAP envelop XML elements.
		while( xmlstr.indexOf('<?') == 0 ) {
			var indexOfNextLine = xmlstr.indexOf( '<', 2 );
			xmlstr = xmlstr.substring( indexOfNextLine );
		}
		var soap =
			'<?xml version="1.0" encoding="UTF-8"?>\n' +
			'<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"\n' +
			'                  xmlns:xsd="http://www.w3.org/2001/XMLSchema"\n' +
			'                  xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">\n' +
			'  <soapenv:Body>\n' +
			'    ' + xmlstr +
			'  </soapenv:Body>\n' +
			'</soapenv:Envelope>\n';

		// Ask Java/ObjC to send and receive SOAP message.
		var receiverSoap = null;
        if( __M$.mobileDevice == "ANDROID" )
            receiverSoap = androidJavaManager.converseXml( URLString, soap );
        else if( __M$.mobileDevice == "IOS" )
            receiverSoap = iosObjcManager.converseXml( URLString, soap );
		if( (receiverSoap != null) && (receiverSoap != '') ) {
			// Remove SOAP envelop XML elements.
			var begin = receiverSoap.lastIndexOf( '<soapenv:'  );
			var end   = receiverSoap.indexOf    ( '</soapenv:' );
            if( (begin != -1) && (end != -1) ) {
                begin = receiverSoap.indexOf( '<', begin + 1 );
                receiverData = receiverSoap.substring( begin, end );
                receiverData = '<?xml version="1.0" encoding="UTF-8"?>\n' +
                        receiverData;
            }
		}
	}

	return receiverData;
};


/*------------------------------------------------------------------------------
 * private sendToOriginalMantis()
 * Helper function for pageDone() when doing M2M.
 * Forward the M2M receiver data along to the original Mantis.
 */
__M$.sendToOriginalMantis = function( receiverData )
{
	if( (receiverData == null) || (receiverData == '') ) {
		// Read all of the XML data from file man00000000.xml.
        if( __M$.mobileDevice == 'ANDROID' )
            receiverData = androidJavaManager.getManxml();
        else if( __M$.mobileDevice == 'IOS' )
            receiverData = iosObjcManager.getManxml();

		// Put "ERROR" in <KEYSIM> element.
		// Note no jQuery since it loses case and $.parseXML() fails on Android.
		var beginKeysim = receiverData.indexOf( '<KEYSIM' );
		var endKeysim   = receiverData.indexOf( '/KEYSIM>' ) + 8;
		if( endKeysim == (8 -1) )
			endKeysim   = receiverData.indexOf( '/>' ) + 2;
		var part1 = receiverData.substring( 0, beginKeysim );
		var part2 = receiverData.substring( endKeysim );
		receiverData = part1 + '<KEYSIM>ERROR</KEYSIM>' + part2;

		// Put exception message in <ERRMSG1> element.
		var msg = null;
        if( __M$.mobileDevice == 'ANDROID' )
            msg = androidJavaManager.getSavedExceptionMessage();
        else if( __M$.mobileDevice == 'IOS' )
            msg = iosObjcManager.getSavedExceptionMessage();
		if( (msg == null) || (msg == 'null') || (msg == '(null)') || (msg == '') )
            msg = 'Unknown error - null returned - possible Mantis server error';
        var beginErrmsg1 = receiverData.indexOf( '<ERRMSG1' );
        var endErrmsg1   = receiverData.indexOf( '/ERRMSG1>' ) + 9;
        if( endErrmsg1 == (9 -1) )
            endErrmsg1   = receiverData.indexOf( '/>' ) + 2;
        var part1 = receiverData.substring( 0, beginErrmsg1 );
        var part2 = receiverData.substring( endErrmsg1 );
        receiverData = part1 + '<ERRMSG1>' + msg + '</ERRMSG1>' + part2;
	}

	var url = __M$.getMobileUrl();
	var xmlstr = receiverData;
	while( xmlstr.indexOf('<?') == 0 ) {
		var indexOfNextLine = xmlstr.indexOf( '<', 2 );
		xmlstr = xmlstr.substring( indexOfNextLine );
	}
	var data =
		'<?xml version="1.0" encoding="UTF-8"?>\n' +
		'<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"\n' +
		'                  xmlns:xsd="http://www.w3.org/2001/XMLSchema"\n' +
		'                  xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">\n' +
		'  <soapenv:Body>\n' +
		'    ' + xmlstr +
		'  </soapenv:Body>\n' +
		'</soapenv:Envelope>\n';
	loadAnime('start');
	jQuery.ajax( {
		url:      url,
		type:     "POST",
		async:    false,
		data:     data,
		dataType: "html",
		success:  __M$.pageDone,
		error:    __M$.reportError
	} );
};

/*-------------------------------------------------------------------------------------
* Animation Timout and control for loading
*/
function loadAnime(action) {
	if (action == "start") {
		$('#circularG').delay(450).show('fast');
	} else {
		$('#circularG').stop().hide();
	}
}
$( document ).ajaxStop(function(e) {
	$('#circularG').stop().hide();
});